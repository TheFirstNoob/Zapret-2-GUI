@echo off
setlocal
cd /d "%~dp0"

echo Creating shortcuts...
powershell -NoProfile -Command ^
  "$ws = New-Object -ComObject WScript.Shell;" ^
  "$icon = '%~dp0app\frontend\logo.ico';" ^
  "$desktop = [Environment]::GetFolderPath('Desktop');" ^
  "$start = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs';" ^
  "foreach ($dir in @($desktop, $start)) {" ^
  "  $s = $ws.CreateShortcut((Join-Path $dir 'Zapret 2 GUI.lnk'));" ^
  "  $s.TargetPath = '%~dp0python\pythonw.exe';" ^
  "  $s.Arguments = 'main.pyw';" ^
  "  $s.WorkingDirectory = '%~dp0app';" ^
  "  $s.IconLocation = $icon;" ^
  "  $s.Save();" ^
  "}"

echo Done. Shortcuts 'Zapret 2 GUI' created on Desktop and in Start Menu.
pause
