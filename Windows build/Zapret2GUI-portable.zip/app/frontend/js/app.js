/**
 * Zapret2 Manager - frontend.
 * Vanilla JS, single script. Backend contract: /api/* polling.
 */

'use strict';

const APP_TOKEN = window.APP_TOKEN || '__APP_TOKEN__';
const SCORE_OK = 80;
const SCORE_MID = 40;

// QUIC-класс хостов (синхронно с core.tester QUIC_QUIRK_DOMAINS):
// браузер идёт через QUIC, TCP-проба curl-ом под десинком не показательная -
// вне «доступности» и нейтральный серый статус вместо красного креста.
const QUIRK_HOSTS = new Set([
  'www.youtube.com', 'youtu.be', 'i.ytimg.com',
  'redirector.googlevideo.com', 'storage.googleapis.com',
]);

let PROFILES = [];

// token-инъекция для /api/*
const _origFetch = window.fetch;
window.fetch = function (url, opts) {
  opts = opts || {};
  if (typeof url === 'string' && url.startsWith('/api/')) {
    opts.headers = Object.assign({ 'X-App-Token': APP_TOKEN }, opts.headers || {});
  }
  return _origFetch(url, opts);
};

window.onerror = function (msg, url, line) {
  console.error('JS ERROR line ' + line + ': ' + msg);
  frontendLog('JS ERROR line ' + line + ': ' + msg);
};

// fire-and-forget лог ошибок на сервер (виден в probe_debug.log)
function frontendLog(msg) {
  try {
    fetch('/api/frontend-log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ msg: msg })
    }).catch(() => {});
  } catch (e) { /* noop */ }
}

// ── utils ──

function $(id) { return document.getElementById(id); }

function escapeHtml(s) {
  if (s == null) return '';
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function formatTime(ms) {
  const n = parseFloat(ms) || 0;
  return n < 1000 ? n.toFixed(0) + 'ms' : (n / 1000).toFixed(1) + 's';
}

// Локальный backend может задуматься (запуск winws2, sc query) - но не навсегда.
const API_TIMEOUT_MS = 30000;

async function apiGet(path) {
  const r = await fetch('/api' + path, { signal: AbortSignal.timeout(API_TIMEOUT_MS) });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}

async function apiPost(path, body) {
  const r = await fetch('/api' + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
    signal: AbortSignal.timeout(API_TIMEOUT_MS),
  });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}

let _toastTimer = null, _toastHideTimer = null;
function showToast(msg, type, action) {
  const t = $('toast');
  // action: {label, onClick} - кнопка внутри тоста (например «Перезапустить сейчас»)
  t.textContent = '';
  const span = document.createElement('span');
  span.textContent = msg;
  t.appendChild(span);
  if (action && action.label) {
    const btn = document.createElement('button');
    btn.className = 'btn btn-sm';
    btn.textContent = action.label;
    btn.addEventListener('click', () => { hideToast(); action.onClick(); });
    t.appendChild(btn);
  }
  t.className = 'toast' + (type ? ' ' + type : '');
  t.hidden = false;
  clearTimeout(_toastHideTimer);
  requestAnimationFrame(() => { t.style.opacity = '1'; });
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(hideToast, 3600);
}

function hideToast() {
  const t = $('toast');
  t.style.opacity = '0';
  clearTimeout(_toastHideTimer);
  _toastHideTimer = setTimeout(() => { t.hidden = true; }, 250);
}

function rateClass(v) {
  return v >= SCORE_OK ? 'st-ok' : v >= SCORE_MID ? 'st-warn' : 'st-err';
}

// ── глобальный статус (чип в сайдбаре + Главная) ──

const Status = {
  timer: null,
  svcTimer: null,
  last: null,          // /api/status ответ
  svc: null,           // /api/service/status ответ

  start() {
    this.refresh();
    this.refreshService();
    this.timer = setInterval(() => this.refresh(), 4000);
    this.svcTimer = setInterval(() => this.refreshService(), 9000);
  },

  async refresh() {
    try {
      const data = await apiGet('/status');
      this.last = data;
      this.render();
    } catch (e) {
      $('protDot').className = 'dot dot-unknown';
      $('protText').textContent = 'нет связи…';
    }
  },

  async refreshService() {
    try { this.svc = await apiGet('/service/status'); }
    catch (e) { this.svc = null; }
    this.render();
    if (App.currentPage === 'main') MainPage.renderServiceLine();
  },

  render() {
    const d = this.last;
    if (!d) return;
    const z2 = d.zapret || {}, z1 = d.zapret1 || {}, svc = this.svc;
    const dot = $('protDot'), txt = $('protText'), sub = $('protSub');

    let state; // 'ok' | 'off' | 'warn' | 'err'
    if (z2.running && z1.running) state = 'err';
    else if (z2.running) state = 'ok';
    else if (z1.running) state = 'warn';
    else state = 'off';

    dot.className = 'dot dot-' + state;
    const chip = $('protChip');
    chip.className = 'prot-chip state-' + state;
    if (state === 'ok') {
      txt.textContent = 'Обход работает';
      sub.textContent = (svc && svc.running) ? 'через службу' : 'PID ' + (z2.pid || '-');
    } else if (state === 'warn') {
      txt.textContent = 'Работает Zapret 1';
      sub.textContent = 'Zapret 2 остановлен';
    } else if (state === 'err') {
      txt.textContent = 'Конфликт Z1 + Z2';
      sub.textContent = 'обход может не работать';
    } else {
      txt.textContent = 'Обход выключен';
      sub.textContent = (svc && svc.installed && !svc.running) ? 'служба остановлена' : '';
    }
    MainPage.renderStatus(d);
  },
};

// ── router ──

const App = {
  currentPage: 'main',
  pages: ['main', 'tester', 'lists', 'contested', 'games', 'diagnostics', 'probe', 'cdn', 'asn'],
  testActive: false,

  // Кнопка «Инструкция и статусы» в info-баннере (единый механизм для всех страниц)
  bindHelpToggle(btnId, detId) {
    const btn = $(btnId);
    if (!btn) return;
    btn.addEventListener('click', () => {
      const det = $(detId);
      const open = !!det && det.hidden;
      if (det) det.hidden = !open;
      btn.classList.toggle('is-open', open);
    });
  },

  // Быстрый старт (туториал): 3 шага для новичка. Показывается, пока
  // пользователь не закроет; факт закрытия хранится в конфиге (tour_done).
  async initTour() {
    const card = $('tourCard');
    if (!card) return;
    try {
      const r = await apiGet('/config');
      if ((r.config || {}).tour_done) return;
      card.hidden = false;
    } catch (e) {
      return;
    }
    $('tourClose').addEventListener('click', async () => {
      card.hidden = true;
      try { await apiPost('/config', { tour_done: true }); } catch (e) { /* ignore */ }
    });
    $('tourStep1').addEventListener('click', () => {
      if (MainPage._z2Running) {
        showToast('Обход уже запущен - переходите к шагу 2', 'ok');
        return;
      }
      $('btnZ2Toggle').click();
    });
    $('tourStep2').addEventListener('click', () => { location.hash = 'diagnostics'; });
    $('tourStep3').addEventListener('click', () => { location.hash = 'tester'; });
  },

  // Честное уведомление «что делает программа и какие данные» - один раз
  // (флаг notice_done в конфиге; закрывается крестиком или «Понятно»).
  async initNotice() {
    const card = $('noticeCard');
    if (!card) return;
    try {
      const r = await apiGet('/config');
      if ((r.config || {}).notice_done) return;
      card.hidden = false;
    } catch (e) {
      return;
    }
    const dismiss = async () => {
      card.hidden = true;
      try { await apiPost('/config', { notice_done: true }); } catch (e) { /* ignore */ }
    };
    $('noticeClose').addEventListener('click', dismiss);
    $('noticeOk').addEventListener('click', dismiss);
  },

  // Фоновая проверка списков при старте: только уведомление (чистит юзер -
  // кнопкой в «Списках»), чтобы дубли из блокнота не путали со временем.
  async checkListsHealth() {
    try {
      const r = await apiGet('/lists/health');
      if (r.status !== 'ok') return;
      const bits = [];
      if (r.total_dups) bits.push(`дубли: ${r.total_dups}`);
      if (r.total_cross) bits.push(`повторы между вашими списками: ${r.total_cross}`);
      if (r.total_redundant) bits.push(`повторы: ${r.total_redundant}`);
      if (r.total_conflicts) bits.push(`конфликты: ${r.total_conflicts}`);
      if (bits.length) {
        showToast('Списки: ' + bits.join(', ') + ' - вкладка «Списки» → «Проверить»', 'warn');
      }
    } catch (e) { /* фоновая проверка не должна мешать запуску */ }
  },

  // Идёт проверка (стратегии/CDN/ASN/blob/диагностика): обходом управляет
  // тестер - блокируем ручной запуск/остановку, службу и другие кнопки
  // проверок, показываем мигающую точку на вкладке-источнике.
  setTestActive(active) {
    if (this.testActive === active) return;
    this.testActive = active;
    const badge = $('testerBadge');
    if (badge) {
      badge.hidden = !active;
      // Точка «идёт проверка» - на странице-источнике, а не всегда на «Подборе»
      if (active) {
        const link = document.querySelector(`.nav-link[data-page="${this.currentPage}"]`);
        if (link && link !== badge.parentElement) link.appendChild(badge);
      }
    }
    // Кнопки всех проверок - взаимоисключающие (бэкенд дублирует 409-ом).
    ['btnStartTest', 'cdnScanBtn', 'asnScanBtn', 'btnBlobProbe', 'diagRunBtn', 'btnDiagCheck']
      .forEach(id => { const el = $(id); if (el) el.disabled = active; });
    // Отдельный тост «идёт проверка» больше не нужен: задачу показывает
    // плавающая плашка внизу справа, а кнопки видно отключёнными.
    if (Status.last) MainPage.renderStatus(Status.last);
  },

  async init() {
    Popover.init();
    Modal.init();
    this.bindNav();
    this.bindProbeButtons();
    this.handleHash();
    window.addEventListener('hashchange', () => this.handleHash());
    this.loadVersion();
    this.checkUpdate();
    this.initTour();
    this.initNotice();
    this.checkListsHealth();
    try {
      const data = await apiGet('/profiles');
      PROFILES = (data.profiles || []).map(p => p.name);
    } catch (e) { PROFILES = ['default']; }
    Status.start();
    if (this.currentPage === 'main') MainPage.onShow();
  },

bindProbeButtons() {
    const scan = $('probeScanBtn');
    const start = $('probeStartBtn');
    const stop = $('probeStopBtn');
    if (scan) scan.addEventListener('click', () => TesterPage.scanProbeProcesses());
    const procInput = $('probeProcInput');
    if (procInput) {
      let t = null;
      procInput.addEventListener('input', () => {
        clearTimeout(t);
        t = setTimeout(() => TesterPage._hintProbeProcess(), 250);
      });
    }
    const sel = $('probeProcSelect');
    if (sel) sel.addEventListener('change', () => {
      $('probeProcInput').value = sel.value;
      TesterPage._hintProbeProcess();
    });
if (start) start.addEventListener('click', () => TesterPage.startProbe());
    if (stop) stop.addEventListener('click', () => TesterPage.stopProbe());
    const report = $('probeReportBtn');
    if (report) report.addEventListener('click', () => TesterPage.saveProbeReport());
  },

  bindNav() {
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.hash = link.dataset.page;
      });
    });
  },

  handleHash() {
    const hash = window.location.hash.replace('#', '') || 'main';
    if (!this.pages.includes(hash)) { window.location.hash = this.currentPage; return; }
    this.currentPage = hash;
    frontendLog('nav: hash=' + hash);
    document.querySelectorAll('.nav-link').forEach(l =>
      l.classList.toggle('active', l.dataset.page === hash));
    const expert = $('expertNav');
    if (expert) {
      const cur = document.querySelector('.nav-link.active');
      if (cur && expert.contains(cur)) expert.open = true;
    }
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    $('page-' + hash).classList.add('active');
    // Смена вкладки - наверх: скролл не должен переезжать между страницами
    const content = document.querySelector('.content');
    if (content) content.scrollTop = 0;
    const titles = { main: 'Главная', tester: 'Подбор стратегии', lists: 'Списки', contested: 'Спорные домены', games: 'Игровые блокировки', diagnostics: 'Проверка системы', probe: 'Анализ приложения', cdn: 'CDN-стабилизация', asn: 'ASN-скан' };
    $('pageTitle').textContent = titles[hash];
    if (hash === 'main') MainPage.onShow();
    if (hash === 'lists') ListsPage.onShow();
    if (hash === 'contested') ListsPage.onShow();
    if (hash === 'games') GamesPage.onShow();
    if (hash === 'cdn') CdnStab.init();
    if (hash === 'asn') AsnPage.init();
    if (hash === 'diagnostics') DiagnosticsPage.onShow();
    if (hash === 'tester') TesterPage.onShow();
    // Список процессов заполняем сами при открытии вкладки - ручная
    // кнопка «Сканировать» не нужна, интерфейс не дублирует действия.
    if (hash === 'probe' && !TesterPage._probePollTimer && !TesterPage._probeStarting) {
      TesterPage.scanProbeProcesses(true);
    }
  },

  async loadVersion() {
    try {
      const d = await apiGet('/version');
      if (d.version) $('appVersion').textContent = d.version;
    } catch (e) { /* ignore */ }
  },

  async checkUpdate() {
    try {
      const r = await apiGet('/update-check');
      if (r.available && r.latest) {
        $('updateVersion').textContent = r.latest;
        $('updateLink').href = r.url || '#';
        $('updateMirrorLink').href = r.mirror_url || '#';
        this._updateTag = r.tag || r.latest.replace(' ', '-');
        $('updateBanner').hidden = false;
      }
    } catch (e) { /* silent */ }
  },

  // Обновление из программы (0.8): скачать → бэкап → применить (portable/lite)
  // или подготовить замену EXE → предложит перезапуск; после - проверка службы
  async runUpdate() {
    const btn = $('updateNowBtn');
    btn.disabled = true;
    btn.textContent = 'Обновление…';
    try {
      await apiPost('/update/start', {});
      const pollId = setInterval(async () => {
        try {
          const st = await apiGet('/update/status');
          btn.textContent = `${st.phase || '…'} ${st.percent ? st.percent + '%' : ''}`.trim();
          if (st.running) return;
          clearInterval(pollId);
          if (st.error) {
            showToast('Обновление не удалось: ' + st.error, 'error');
            btn.disabled = false;
            btn.textContent = 'Повторить обновление';
            return;
          }
          const res = st.result || {};
          $('updateBanner').hidden = true;
          if (res.service_mismatch) {
            showToast('Обновление проверено по подписи и применено. Служба стоит на старой конфигурации - переустановите её кнопкой', 'warn');
            btn.disabled = false;
            btn.textContent = 'Переустановить службу';
            this._updateStage = 'service';
          } else {
            showToast('Обновление проверено по подписи и применено - перезапустите программу', 'ok');
            setTimeout(() => { location.reload(); }, 1500);
          }
        } catch (e) {
          clearInterval(pollId);
          btn.disabled = false;
          btn.textContent = 'Повторить';
        }
      }, 1000);
    } catch (e) {
      showToast('Обновление не запустилось: ' + (e.message || e), 'error');
      btn.disabled = false;
      btn.textContent = 'Обновить сейчас';
    }
  },

  _onUpdateBtn() {
    if (this._updateStage === 'service') {
      const btn = $('updateNowBtn');
      btn.disabled = true;
      btn.textContent = 'Переустановка службы…';
      apiPost('/service/install', {}).then(r => {
        if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
        showToast('Служба переустановлена - перезапустите программу', 'ok');
        setTimeout(() => { location.reload(); }, 1500);
      }).catch(e => {
        showToast('Ошибка переустановки: ' + (e.message || e), 'error');
        btn.disabled = false;
        btn.textContent = 'Повторить переустановку';
      });
      return;
    }
    this.runUpdate();
  },
};

// ══════════════════════════ ГЛАВНАЯ ══════════════════════════

const MainPage = {
  _busy: false,
  _z2Running: false,
  _z2Strategy: '',
  _loaded: false,
  _runningToggles: null,  // тогглы, с которыми реально запущен обход
  _configLoaded: false,

  onShow() {
    if (!this._loaded) {
      this._loaded = true;
      this.populateFakeBlobs();
      this.loadConfig();
      this.bind();
      MainPage.renderServiceLine();
    }
    if (Status.last) this.renderStatus(Status.last);
  },

  bind() {
    $('btnZ2Toggle').addEventListener('click', () => this.toggleZ2());
    $('btnQuickCheck').addEventListener('click', () => {
      location.hash = 'diagnostics';
      // «Проверить работу» должна реально запускать проверку, а не просто
      // переключать вкладку: небольшая задержка - пока страница активируется.
      setTimeout(() => DiagnosticsPage.run(), 150);
    });
    $('btnStopZ1Now').addEventListener('click', () => this.stopZ1());
    $('btnApplyToggles').addEventListener('click', () => this.restartZapret());
    $('btnRevertToggles').addEventListener('click', () => this._revertToggles());
    $('btnSvcRepair').addEventListener('click', () => this.svcRepair());
    $('btnSvcInstall').addEventListener('click', () => this.svcInstall());
    $('btnSvcStart').addEventListener('click', () => this.svcStart());
    $('btnSvcStop').addEventListener('click', () => this.svcStop());
    $('btnSvcRemove').addEventListener('click', () => this.svcRemove());
    $('btnZ1SaveDir').addEventListener('click', () => this.saveZ1Dir());
    $('btnZ1Toggle').addEventListener('click', () => this.toggleZ1());
    $('updateBannerClose').addEventListener('click', () => { $('updateBanner').hidden = true; });
    $('updateNowBtn').addEventListener('click', () => this._onUpdateBtn());

    ['toggleGameFilter', 'toggleAutoHostlist', 'toggleIpFilter',
      'toggleDiscordVoice', 'toggleDiscordAlt', 'toggleWinws2Debug', 'fakeBlobSelect'].forEach(id => {
      $(id).addEventListener('change', () => this.saveToggles());
    });
    $('btnBlobProbe').addEventListener('click', () => {
      if (this._blobProbing) this._cancelBlobProbe();
      else this.runBlobProbe();
    });
    const gamesSave = $('gamesSaveBtn');
    if (gamesSave) gamesSave.addEventListener('click', () => GamesPage.save());
    const gs = $('gamesSearch');
    if (gs) gs.addEventListener('input', () => GamesPage.render());
    // Подвал меню: экспорт/импорт настроек и техинфо (обновления)
    const impFile = $('settingsImportFile');
    if (impFile) impFile.addEventListener('change', () => ListsPage.importSettings(impFile));
    const sideExp = $('sideExport');
    if (sideExp) sideExp.addEventListener('click', () => ListsPage.exportSettings());
    const sideInfo = $('sideInfo');
    if (sideInfo) sideInfo.addEventListener('click', () => AppInfo.open());
    // Статус-чип в подвале меню кликабелен: ведёт на главную
    const protChip = $('protChip');
    if (protChip) {
      const goMain = () => { location.hash = '#main'; };
      protChip.addEventListener('click', goMain);
      protChip.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); goMain(); }
      });
    }
  },

  async loadConfig() {
    try {
      const r = await apiGet('/config');
      const c = r.config || {};
      $('toggleGameFilter').value = c.game_filter_mode || 'off';
      $('toggleAutoHostlist').checked = !!c.autohostlist;
      $('toggleIpFilter').checked = !!c.ipset_catchall;
      $('toggleDiscordVoice').value = c.discord_voice_mode || (c.discord_voice ? 'fake' : 'off');
      $('toggleDiscordAlt').checked = !!c.discord_alt;
      this._updateVoiceHint();
      this._pendingFakeBlob = c.fake_blob || '';
      const fbSel = $('fakeBlobSelect');
      if (fbSel && Array.from(fbSel.options).some(o => o.value === this._pendingFakeBlob)) {
        fbSel.value = this._pendingFakeBlob;
      }
      $('toggleWinws2Debug').checked = !!c.winws2_debug;
      $('z1DirPath').value = c.zapret1_dir || '';
      if (c.last_profile) {
        this._savedProfile = c.last_profile;
        const sel = $('strategySelect');
        if ([...sel.options].some(o => o.value === c.last_profile)) sel.value = c.last_profile;
      }
      if (c.zapret1_last_strategy) this._z1SavedStrategy = c.zapret1_last_strategy;
      if (c.zapret1_dir) this.scanZ1Strategies();
      this._configLoaded = true;
      // Обход уже был запущен до загрузки конфига - снимок тогглов делаем
      // только теперь, когда DOM показывает сохранённые значения.
      if (this._z2Running && !this._runningToggles) {
        this._runningToggles = this._collectToggles();
        this._updateApplyHint();
      }
    } catch (e) { /* ignore */ }
  },

  // Список доступных TLS-фейк-блобов (blobs/tls_clienthello_*.bin).
  // Рекомендованные (проверенные, ≤700 байт) - первыми, с меткой ★.
  async populateFakeBlobs() {
    try {
      const r = await apiGet('/fake-blobs');
      const sel = $('fakeBlobSelect');
      if (!sel || this._blobsLoaded) return;
      this._blobsLoaded = true;
      const rec = new Set(r.recommended || []);
      const sizes = r.sizes || {};
      for (const key of r.blobs || []) {
        if (Array.from(sel.options).some(o => o.value === key)) continue;
        const o = document.createElement('option');
        o.value = key;
        const label = key.replace(/_/g, '.');
        const sz = sizes[key] || 0;
        o.textContent = rec.has(key)
          ? `★ ${label} (${sz} B)`
          : (sz > 700 ? `⚠ ${label} (${sz} B) - большой` : `${label} (${sz} B)`);
        sel.appendChild(o);
      }
      sel.value = this._pendingFakeBlob || '';
    } catch (e) { /* список не критичен */ }
  },

  // Перебор TLS-фейк-блобов: короткая батарея на каждом, победитель
  // подставляется в селектор (применение - через «Перезапустить»).
  async runBlobProbe() {
    if (this._blobProbing || App.testActive) return;
    this._blobProbing = true;
    this._blobProbeCancelled = false;
    App.setTestActive(true);
    const btn = $('btnBlobProbe');
    const hint = $('fakeBlobHint');
    // На время подбора кнопка сама становится «Остановить» - без лишней.
    btn.textContent = 'Остановить';
    btn.classList.add('btn-danger-text');
    btn.title = 'Остановить подбор';
    btn.disabled = false;
    hint.textContent = 'Запуск...';
    try {
      const started = await apiPost('/blob-probe', {});
      if (started.status !== 'ok') throw new Error(started.message || 'ошибка');
      const deadline = Date.now() + 6 * 60 * 1000;
      let final = null;
      while (!final && Date.now() < deadline) {
        await new Promise(res => setTimeout(res, 700));
        const st = await apiGet('/tester/status');
        if (st.error) throw new Error(st.error);
        if (st.progress && hint && !this._blobProbeCancelled) {
          hint.textContent = `${st.progress.message || ''} (${st.progress.percent ?? 0}%)`;
          Activity.set('main', 'Подбор блоба: ' + (st.progress.message || ''),
                       st.progress.percent, true);
        }
        if (!st.running) final = st.final_result;
      }
      if (!final) throw new Error('подбор не завершился вовремя');
      if (final.restored) showToast(final.restored, 'ok');
      const results = (final.results || []).filter(x => x.rate >= 0)
        .sort((a, b) => b.rate - a.rate || b.ok - a.ok);
      if (!results.length) throw new Error('нет результатов');
      if (hint) {
        hint.innerHTML = results.map(x =>
          `<div>${x.blob === results[0].blob ? '<b>' : ''}${escapeHtml(x.blob)}: ${x.rate}% (${x.ok}/${x.total})${x.blob === results[0].blob ? '</b>' : ''}</div>`).join('');
      }
      if (this._blobProbeCancelled) {
        // частичный прогон: показываем, но лучший не подставляем
        Activity.done('Подбор остановлен');
        showToast('Подбор остановлен - показаны частичные результаты', 'warn');
      } else {
        const best = results[0];
        const sel = $('fakeBlobSelect');
        Activity.done('Подбор блоба завершён');
        showToast(`Лучший блоб: ${best.blob.replace(/_/g, '.')} (${best.rate}%)`, 'ok');
        if (Array.from(sel.options).some(o => o.value === best.blob) && sel.value !== best.blob) {
          sel.value = best.blob;
          this.saveToggles();
        }
      }
    } catch (e) {
      if (this._blobProbeCancelled) {
        Activity.done('Подбор остановлен');
        showToast('Подбор остановлен', 'warn');
        if (hint) hint.textContent = '';
      } else {
        Activity.fail('Подбор блоба: ' + e.message);
        showToast('Подбор блоба: ' + e.message, 'error');
        if (hint) hint.textContent = '';
      }
    }
    btn.textContent = 'Подобрать блоба';
    btn.classList.remove('btn-danger-text');
    btn.title = 'Переберёт блобы и поставит лучший';
    btn.disabled = false;
    this._blobProbing = false;
    App.setTestActive(false);
    Status.refresh();
  },

  _cancelBlobProbe() {
    const btn = $('btnBlobProbe');
    btn.disabled = true;
    this._blobProbeCancelled = true;
    apiPost('/tester/action', { action: 'cancel' }).catch(() => {});
    const hint = $('fakeBlobHint');
    if (hint) hint.textContent = 'Останавливаем...';
  },

  populateProfiles(list) {
    if (!list || !list.length) return;
    const sig = list.join(',');
    if (sig === this._profilesSig) return;
    this._profilesSig = sig;
    const sel = $('strategySelect');
    const cur = sel.value || this._savedProfile || '';
    sel.innerHTML = '';
    for (const p of list) {
      const o = document.createElement('option');
      o.value = p; o.textContent = p;
      sel.appendChild(o);
    }
    if (cur && list.includes(cur)) sel.value = cur;
    else if (list.includes('default')) sel.value = 'default';
    sel.onchange = () => {
      if (sel.value) apiPost('/config', { last_profile: sel.value }).catch(() => {});
    };
  },

  renderStatus(d) {
    if (!d) return;
    const z2 = d.zapret || {}, z1 = d.zapret1 || {};
    const st = $('z2State');
    const badge = st.querySelector('.dot');
    const text = st.querySelector('.state-text');
    const conflict = z2.running && z1.running;

    // статусные рамки панелей: ok / warn (внимание) / err (конфликт)
    const z2p = $('z2Panel');
    z2p.classList.remove('is-ok', 'is-warn', 'is-err');
    if (conflict) z2p.classList.add('is-err');
    else if (z2.running) z2p.classList.add('is-ok');
    else if (z1.running) z2p.classList.add('is-warn');
    const z1p = $('z1Panel');
    z1p.classList.remove('is-ok', 'is-warn', 'is-err');
    if (z1.running && z2.running) z1p.classList.add('is-err');
    else if (z1.running) z1p.classList.add('is-warn');
    // Панель Zapret 1 - только тем, у кого он реально есть (папка настроена,
    // служба найдена или он запущен): у остальных это мёртвый блок
    z1p.hidden = !(z1.installed || z1.running);
    if (z2.running) {
      badge.className = 'dot ' + (conflict ? 'dot-warn' : 'dot-ok');
      text.className = 'state-text ' + (conflict ? 'st-warn' : 'st-ok');
      text.textContent = conflict
        ? 'Работает (конфликт с Zapret 1)'
        : 'Работает' + (z2.pid ? ' · PID ' + z2.pid : '');
    } else if (z1.running) {
      badge.className = 'dot dot-warn';
      text.className = 'state-text st-warn';
      text.textContent = 'Выключен (работает Zapret 1)';
    } else {
      badge.className = 'dot dot-off';
      text.className = 'state-text st-mute';
      text.textContent = 'Выключен';
    }

    // Отдача пользователю на главной: что сейчас и что делать дальше
    const fb = $('z2Feedback');
    if (fb) {
      if (conflict) {
        fb.textContent = 'Оба обхода запущены одновременно - остановите один из них.';
      } else if (z2.running) {
        fb.textContent = 'Обход работает' + (z2.strategy ? ' («' + z2.strategy + '»)' : '') +
          ' - проверьте, открываются ли нужные сайты.';
      } else if (z1.running) {
        fb.textContent = 'Работает запасной Zapret 1 - Zapret 2 остановлен.';
      } else {
        fb.textContent = 'Обход выключен: заблокированные сайты не откроются, пока не нажмёте «Запустить».';
      }
    }
    const qc = $('btnQuickCheck');
    if (qc) qc.hidden = !z2.running;

    this._z2Running = z2.running;
    this._z2Strategy = z2.strategy || '';
    // Снимок тогглов запущенного процесса: до loading конфига не снимаем.
    if (!this._z2Running) this._runningToggles = null;
    else if (!this._runningToggles && this._configLoaded) this._runningToggles = this._collectToggles();

    const btn = $('btnZ2Toggle');
    if (!this._busy && !App.testActive) {
      const sel = $('strategySelect');
      const strategyChanged = this._z2Running && sel.value && this._z2Strategy && sel.value !== this._z2Strategy;
      if (!this._z2Running) {
        btn.textContent = 'Запустить';
        btn.classList.add('btn-go');
        btn.classList.remove('btn-stop', 'btn-primary');
      } else if (strategyChanged) {
        // Выбор расходится с запущенной стратегией: кнопка применяет выбор.
        btn.textContent = 'Применить «' + sel.value + '»';
        btn.classList.add('btn-primary');
        btn.classList.remove('btn-go', 'btn-stop');
      } else {
        btn.textContent = 'Остановить';
        btn.classList.add('btn-stop');
        btn.classList.remove('btn-go', 'btn-primary');
      }
      btn.disabled = false;
    } else if (App.testActive) {
      btn.disabled = true;
    }
    const hint = $('strategyApplyHint');
    const selNow = $('strategySelect').value;
    const strategyChangedNow = this._z2Running && selNow && this._z2Strategy && selNow !== this._z2Strategy;
    hint.hidden = !strategyChangedNow;
    if (strategyChangedNow) {
      hint.textContent = 'Запущена «' + this._z2Strategy + '» - нажатие кнопки перезапустит обход с выбранной.';
    }

    $('conflictBanner').hidden = !(z2.running && z1.running);
    $('togglesOverlay').hidden = !z1.running;

    // Zapret 1 - единый стиль статуса с Zapret 2 (слова и цвет текста)
    const zs = $('z1State');
    const z1Text = zs.querySelector('.state-text');
    const z1Conflict = z1.running && z2.running;
    zs.querySelector('.dot').className = 'dot ' + (z1Conflict ? 'dot-warn' : z1.running ? 'dot-ok' : 'dot-off');
    z1Text.className = 'state-text ' + (z1Conflict ? 'st-warn' : z1.running ? 'st-ok' : 'st-mute');
    z1Text.textContent = z1.running ? 'Работает' : 'Выключен';
    // Запасной инструмент - нейтральная кнопка: синий primary только у Zapret 2.
    const z1btn = $('btnZ1Toggle');
    z1btn.textContent = z1.running ? 'Остановить' : 'Запустить';
    z1btn.classList.remove('btn-primary');
    z1btn.disabled = App.testActive;

    // перезапуск по изменённым тогглам - только когда что-то изменено и запущено
    this._updateApplyHint();
    this.populateProfiles(d.profiles || []);
  },

  renderServiceLine() {
    const svc = Status.svc;
    if (!svc) return;
    const installed = !!svc.installed;
    const running = !!svc.running;
    $('btnSvcInstall').hidden = installed;
    $('btnSvcStart').hidden = !(installed && !running);
    $('btnSvcStop').hidden = !(installed && running);
    $('btnSvcRemove').hidden = !installed;
    $('svcStatusText').textContent = this._svcBusy ? '…'
      : !installed ? 'не установлена - обход только при открытом приложении'
      : (running ? 'установлена · работает (автозапуск при загрузке)'
                 : 'установлена · остановлена');
    const chip = $('svcState');
    if (chip) {
      const dot = chip.querySelector('.dot');
      const txt = chip.querySelector('.state-text');
      if (this._svcBusy) {
        dot.className = 'dot dot-idle'; txt.textContent = '…'; txt.className = 'state-text st-mute';
      } else if (!installed) {
        dot.className = 'dot dot-off'; txt.textContent = 'не установлена'; txt.className = 'state-text st-mute';
      } else if (running) {
        dot.className = 'dot dot-ok'; txt.textContent = 'работает'; txt.className = 'state-text st-ok';
      } else {
        dot.className = 'dot dot-off'; txt.textContent = 'остановлена'; txt.className = 'state-text st-mute';
      }
    }
  },

  _setSvcBusy(b) {
    this._svcBusy = b;
    ['btnSvcRepair', 'btnSvcInstall', 'btnSvcStart', 'btnSvcStop', 'btnSvcRemove'].forEach(id => {
      $(id).disabled = b;
    });
  },

  async _svcAction(fn, busyText, okText, errText) {
    this._setSvcBusy(true);
    $('svcStatusText').textContent = busyText;
    Activity.set('main', busyText);
    try {
      const r = await fn();
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      Activity.done(okText);
      showToast(okText, 'ok');
    } catch (e) {
      Activity.fail(errText + e.message);
      showToast(errText + e.message, 'error');
    }
    this._setSvcBusy(false);
    Status.refreshService();
    Status.refresh();
  },

  svcInstall() {
    const t = this._collectToggles();
    const payload = {
      profile: $('strategySelect').value,
      game_filter: t.game_filter_mode, discord_voice_mode: t.discord_voice_mode,
      debug: t.winws2_debug, autohostlist: t.autohostlist,
      ipset_catchall: t.ipset_catchall, discord_alt: t.discord_alt,
    };
    this._svcAction(
      async () => {
        let r = await apiPost('/service/install', payload);
        if (r.status !== 'ok' && /Zapret 1/.test(r.message || '')) {
          const go = await Confirm.ask({
            title: 'Обнаружен Zapret 1',
            text: 'Остановить и удалить его? Это то же действие, что «Remove Services» в service.bat Zapret 1: служба zapret будет остановлена и удалена, процесс winws.exe будет остановлен. После этого установка продолжится автоматически.',
            ok: 'Удалить Zapret 1 и продолжить',
            danger: true,
          });
          if (!go) return r;
          r = await apiPost('/service/install', { ...payload, cleanup_zapret1: true });
        }
        if (r.status !== 'ok') return r;
        return apiPost('/service/start', {});
      },
      'Установка…', 'Служба установлена и запущена - обход работает без программы',
      'Не удалось установить службу: ');
  },

  svcStart() {
    this._svcAction(() => apiPost('/service/start', {}),
      'Запуск…', 'Служба запущена', 'Не удалось запустить службу: ');
  },

  svcStop() {
    this._svcAction(() => apiPost('/service/stop', {}),
      'Остановка…', 'Служба остановлена', 'Не удалось остановить службу: ');
  },

  async svcRemove() {
    const ok = await Confirm.ask({
      title: 'Удалить службу Zapret 2?',
      text: 'Автозапуск обхода после перезагрузки отключится (сам обход это не затронет).',
      ok: 'Удалить службу',
      danger: true,
    });
    if (!ok) return;
    this._svcAction(async () => {
      if (Status.svc && Status.svc.running) await apiPost('/service/stop', {}).catch(() => {});
      return apiPost('/service/remove', {});
    }, 'Удаление…', 'Служба удалена', 'Не удалось удалить службу: ');
  },

  async svcRepair() {
    this._setSvcBusy(true);
    $('svcStatusText').textContent = 'Проверка драйвера…';
    try {
      const r = await apiPost('/service/repair', {});
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      const acts = r.actions || [];
      if (r.reboot_required) {
        showToast('Нужна перезагрузка: ' + acts.join('; '), 'error');
      } else if (acts.length) {
        showToast('Починено: ' + acts.join('; '), 'ok');
      } else {
        showToast('Драйвер в порядке - проблем не найдено', 'ok');
      }
      if (r.zapret1) {
        showToast('Замечание: ' + r.zapret1, 'warn');
      }
    } catch (e) {
      showToast('Не удалось починить: ' + e.message, 'error');
    }
    this._setSvcBusy(false);
    Status.refreshService();
    Status.refresh();
  },

  _collectToggles() {
    return {
      game_filter_mode: $('toggleGameFilter').value,
      discord_voice: $('toggleDiscordVoice').value !== 'off',
      discord_voice_mode: $('toggleDiscordVoice').value,
      winws2_debug: $('toggleWinws2Debug').checked,
      autohostlist: $('toggleAutoHostlist').checked,
      ipset_catchall: $('toggleIpFilter').checked,
      discord_alt: $('toggleDiscordAlt').checked,
      fake_blob: $('fakeBlobSelect') ? $('fakeBlobSelect').value : '',
    };
  },

  _VOICE_HINTS: {
    off: 'Голос идёт без обхода - этого хватает большинству',
    fake: 'Стандарт: подмена QUIC-пакетов на голосовых портах Discord',
    udplen: 'Сдвиг длины каждого голосового пакета - если стандарт не берёт голос',
  },

  _updateVoiceHint() {
    const el = $('voiceModeHint');
    if (el) el.textContent = this._VOICE_HINTS[$('toggleDiscordVoice').value] || '';
  },

  async saveToggles() {
    this._updateVoiceHint();
    const t = this._collectToggles();
    try {
      await apiPost('/config', t);
      // Без тоста на каждый чекбокс: факт «есть неприменённые изменения»
      // показывает кнопка «Перезапустить с новыми параметрами».
    } catch (e) {
      showToast('Не удалось сохранить: ' + e.message, 'error');
    }
    this._updateApplyHint();
  },

  _togglesEqual(a, b) {
    return !!a && !!b &&
      a.game_filter_mode === b.game_filter_mode &&
      (a.discord_voice_mode || (a.discord_voice ? 'fake' : 'off')) === (b.discord_voice_mode || (b.discord_voice ? 'fake' : 'off')) &&
      !!a.winws2_debug === !!b.winws2_debug &&
      !!a.autohostlist === !!b.autohostlist &&
      !!a.ipset_catchall === !!b.ipset_catchall &&
      !!a.discord_alt === !!b.discord_alt &&
      (a.fake_blob || '') === (b.fake_blob || '');
  },

  _TOGGLE_NAMES: {
    game_filter_mode: 'Игровые порты',
    discord_voice_mode: 'Discord Voice',
    discord_alt: 'Альт-режим Discord',
    autohostlist: 'Авто-список',
    ipset_catchall: 'Общий IP-обход',
    winws2_debug: 'DEBUG-лог',
    fake_blob: 'Блоб фейка',
  },

  _TOGGLE_VALUES: {
    game_filter_mode: { off: 'Выключено', tcp: 'только TCP', udp: 'только UDP', both: 'TCP + UDP' },
    discord_voice_mode: { off: 'Выключено', fake: 'Стандарт', udplen: 'UDP-длина' },
  },

  // Что расходится с запущенным обходом (для плашки «есть неприменённые»)
  _pendingDiff() {
    if (!this._z2Running || !this._runningToggles) return [];
    const cur = this._collectToggles();
    const ref = this._runningToggles;
    const out = [];
    const val = (k, v) => (this._TOGGLE_VALUES[k] || {})[v] || v;
    for (const k of Object.keys(this._TOGGLE_NAMES)) {
      if (k === 'discord_voice_mode') {
        const av = ref.discord_voice_mode || (ref.discord_voice ? 'fake' : 'off');
        const bv = cur.discord_voice_mode || (cur.discord_voice ? 'fake' : 'off');
        if (av !== bv) out.push(`${this._TOGGLE_NAMES[k]}: ${val(k, av)} → ${val(k, bv)}`);
        continue;
      }
      if (['discord_alt', 'autohostlist', 'ipset_catchall', 'winws2_debug'].includes(k)) {
        if (!!ref[k] !== !!cur[k]) {
          out.push(`${this._TOGGLE_NAMES[k]}: ${cur[k] ? 'включить' : 'выключить'}`);
        }
        continue;
      }
      const a = k === 'fake_blob' ? (ref[k] || '') : ref[k];
      const b = k === 'fake_blob' ? (cur[k] || '') : cur[k];
      if (a !== b) {
        const show = (x) => (x || 'как в пресете').replace(/_/g, '.');
        out.push(`${this._TOGGLE_NAMES[k]}: ${show(a)} → ${show(b)}`);
      }
    }
    const sel = $('strategySelect');
    if (sel && sel.value && this._z2Strategy && sel.value !== this._z2Strategy) {
      out.push(`Стратегия: ${this._z2Strategy} → ${sel.value}`);
    }
    return out;
  },

  _updateApplyHint() {
    const btn = $('btnApplyToggles');
    const rev = $('btnRevertToggles');
    const hint = $('applyTogglesHint');
    const diff = $('applyTogglesDiff');
    // Кнопки только когда обход запущен и параметры расходятся с тем,
    // с чем процесс реально стартовал.
    const list = this._pendingDiff();
    const pending = list.length > 0;
    btn.hidden = !pending;
    if (rev) rev.hidden = !pending;
    if (diff) diff.innerHTML = list.map(t => `<span>${escapeHtml(t)}</span>`).join('');
    hint.textContent = pending
      ? 'Есть неприменённые изменения:'
      : (this._z2Running ? '' : '');
  },

  // Вернуть переключатели к состоянию запущенного обхода
  _revertToggles() {
    const ref = this._runningToggles;
    if (!ref) return;
    $('toggleGameFilter').value = ref.game_filter_mode || 'off';
    $('toggleDiscordVoice').value =
      ref.discord_voice_mode || (ref.discord_voice ? 'fake' : 'off');
    $('toggleWinws2Debug').checked = !!ref.winws2_debug;
    $('toggleAutoHostlist').checked = !!ref.autohostlist;
    $('toggleIpFilter').checked = !!ref.ipset_catchall;
    $('toggleDiscordAlt').checked = !!ref.discord_alt;
    const sel = $('fakeBlobSelect');
    if (sel) sel.value = ref.fake_blob || '';
    const st = $('strategySelect');
    if (this._z2Strategy && st && [...st.options].some(o => o.value === this._z2Strategy)) {
      st.value = this._z2Strategy;
    }
    this.saveToggles();
  },

  async toggleZ2() {
    const sel = $('strategySelect');
    if (this._z2Running) {
      // Выбор расходится с запущенной стратегией - кнопка применяет его.
      if (sel.value && this._z2Strategy && sel.value !== this._z2Strategy) {
        return this.applyStrategy(sel.value);
      }
      return this.stop();
    }
    if (!sel.value) { showToast('Выберите стратегию', 'warn'); return; }
    this._setBusy(true);
    try {
      await apiPost('/config', Object.assign({ last_profile: sel.value }, this._collectToggles()));
      const r = await apiPost('/start', { profile: sel.value });
      if (r.status === 'ok') {
        this._runningToggles = this._collectToggles();
        showToast('Обход запущен: ' + sel.value, 'ok');
      } else {
        showToast('Не удалось запустить: ' + (r.message || 'ошибка'), 'error');
      }
    } catch (e) {
      showToast('Ошибка запуска: ' + e.message, 'error');
    }
    this._setBusy(false);
    Status.refresh();
  },

  async stop() {
    this._setBusy(true);
    try {
      const r = await apiPost('/stop', {});
      showToast(r.status === 'ok' ? 'Обход остановлен' : ('Ошибка: ' + r.message),
        r.status === 'ok' ? 'ok' : 'error');
    } catch (e) { showToast('Ошибка: ' + e.message, 'error'); }
    this._setBusy(false);
    Status.refresh();
  },

  async restartZapret() {
    const strategy = this._z2Strategy || $('strategySelect').value;
    if (!strategy) return;
    const btn = $('btnApplyToggles');
    btn.disabled = true;
    try {
      await apiPost('/config', this._collectToggles());
      await apiPost('/stop', {});
      await new Promise(r => setTimeout(r, 1200));
      const r = await apiPost('/start', { profile: strategy });
      if (r.status === 'ok') {
        this._runningToggles = this._collectToggles();
        showToast('Перезапущено: ' + strategy, 'ok');
      } else {
        showToast('Ошибка: ' + r.message, 'error');
      }
    } catch (e) {
      showToast('Ошибка перезапуска: ' + e.message, 'error');
    }
    btn.disabled = false;
    this._updateApplyHint();
    Status.refresh();
  },

  // Запуск стратегии (из вердикта тестера, из тостов списков, с Главной).
  // gotoMain=false - остаться на текущей вкладке.
  async applyStrategy(profile, gotoMain = true) {
    if (!profile || this._busy || App.testActive) return;
    this._setBusy(true);
    try {
      const sel = $('strategySelect');
      if (sel && Array.from(sel.options).some(o => o.value === profile)) sel.value = profile;
      await apiPost('/config', Object.assign({ last_profile: profile }, this._collectToggles()));
      const r = await apiPost('/start', { profile });
      if (r.status === 'ok') {
        this._runningToggles = this._collectToggles();
        showToast('Обход запущен: ' + profile, 'ok');
        if (gotoMain) window.location.hash = 'main';
      } else {
        showToast('Не удалось запустить: ' + (r.message || 'ошибка'), 'error');
      }
    } catch (e) {
      showToast('Ошибка запуска: ' + e.message, 'error');
    }
    this._setBusy(false);
    this._updateApplyHint();
    Status.refresh();
  },

  _setBusy(b) {
    this._busy = b;
    $('btnZ2Toggle').disabled = b;
    ['btnSvcRepair', 'btnSvcInstall', 'btnSvcStart', 'btnSvcStop', 'btnSvcRemove'].forEach(id => {
      $(id).disabled = b;
    });
  },

  // ── Zapret 1 ──

  async saveZ1Dir() {
    const dir = $('z1DirPath').value.trim();
    if (!dir) { showToast('Укажите папку Zapret 1', 'warn'); return; }
    try {
      const r = await apiPost('/zapret1/save-dir', { path: dir });
      if (r.status === 'ok') { showToast('Путь сохранён', 'ok'); this.scanZ1Strategies(); }
      else showToast(r.message || 'Ошибка', 'error');
    } catch (e) { showToast('Ошибка: ' + e.message, 'error'); }
  },

  async scanZ1Strategies() {
    const sel = $('z1StrategySelect');
    sel.disabled = true;
    sel.innerHTML = '<option>сканирование…</option>';
    try {
      const r = await apiGet('/zapret1/strategies');
      const strs = r.strategies || [];
      sel.innerHTML = '';
      if (!strs.length) {
        sel.innerHTML = '<option value="">- в папке нет .bat -</option>';
        return;
      }
      sel.disabled = false;
      for (const s of strs) {
        const o = document.createElement('option');
        o.value = s.name; o.textContent = s.name + '.bat';
        sel.appendChild(o);
      }
      if (this._z1SavedStrategy && strs.some(s => s.name === this._z1SavedStrategy)) {
        sel.value = this._z1SavedStrategy;
      }
    } catch (e) {
      sel.innerHTML = '<option value="">- ошибка сканирования -</option>';
    }
  },

  async toggleZ1() {
    if (this._z1Busy) return;
    this._z1Busy = true;
    $('btnZ1Toggle').disabled = true;
    const running = Status.last && Status.last.zapret1 && Status.last.zapret1.running;
    try {
      if (running) {
        const r = await apiPost('/zapret1/stop', {});
        showToast(r.status === 'ok' ? 'Zapret 1 остановлен' : ('Ошибка: ' + r.message),
          r.status === 'ok' ? 'ok' : 'error');
      } else {
        const strategy = $('z1StrategySelect').value;
        if (!strategy) { showToast('Выберите стратегию Zapret 1', 'warn'); return; }
        const r = await apiPost('/zapret1/start', { strategy });
        showToast(r.status === 'ok' ? ('Zapret 1 запущен: ' + strategy) : ('Ошибка: ' + (r.message || '')),
          r.status === 'ok' ? 'ok' : 'error');
      }
    } catch (e) { showToast('Ошибка: ' + e.message, 'error'); }
    this._z1Busy = false;
    $('btnZ1Toggle').disabled = false;
    Status.refresh();
  },

  async stopZ1() { await this.toggleZ1(); },
};

// ══════════════════════════ ПРОВЕРКА СИСТЕМЫ ══════════════════════════

const DiagnosticsPage = {
  _last: '',

  onShow() {
    if (!this._bound) {
      this._bound = true;
      $('diagRunBtn').addEventListener('click', () => this.run());
      $('diagCopyBtn').addEventListener('click', () => this.copyReport());
    }
  },

  async run() {
    if (App.testActive) {
      showToast('Идёт другая проверка - дождитесь завершения', 'warn');
      return;
    }
    App.setTestActive(true);
    const btn = $('diagRunBtn');
    btn.disabled = true;
    btn.textContent = 'Проверяю…';
    $('diagCopyBtn').hidden = true;
    $('diagIdle').hidden = true;
    $('diagResults').hidden = true;
    $('diagLoading').hidden = false;
    const t0 = Date.now();
    const timer = setInterval(() => {
      const el = $('diagTimer');
      if (el) el.textContent = Math.round((Date.now() - t0) / 1000);
    }, 1000);
    try {
      const started = await apiPost('/diagnose/action', {});
      if (started.status !== 'ok') throw new Error(started.message || 'ошибка');
      let report = null;
      // Страховка от вечного цикла: диагностика на бэкенде не живёт дольше
      // трёх минут - если статус не пришёл, считаем backend зависшим.
      const deadline = Date.now() + 3 * 60 * 1000;
      while (report === null) {
        await new Promise(res => setTimeout(res, 300));
        if (Date.now() > deadline) throw new Error('backend не отвечает');
        const st = await apiGet('/diagnose/status');
        if (st.error) throw new Error(st.error);
        const cur = $('diagCurrent');
        if (cur && st.progress) cur.textContent = st.progress;
        if (st.running) Activity.set('diagnostics', st.progress || 'Проверка системы');
        if (!st.running) report = st.report;
      }
      if (!report) throw new Error('нет результата');
      Activity.done('Проверка системы завершена');
      localStorage.setItem('z2_diag_done', String(Date.now()));
      const note = $('diagDoneNote');
      if (note) note.hidden = false;
      this.render(report);
    } catch (e) {
      $('diagLoading').hidden = true;
      $('diagResults').hidden = false;
      $('diagSummary').innerHTML = '';
      $('diagList').innerHTML = '<div class="diag-err">Ошибка диагностики: ' + escapeHtml(String(e.message || e)) + '</div>';
      $('diagRecommend').hidden = true;
    }
    clearInterval(timer);
    App.setTestActive(false);
    btn.disabled = false;
    btn.textContent = this._last ? 'Повторить' : 'Проверить';
  },

  render(report) {
    const s = report.summary || {};
    $('diagLoading').hidden = true;
    $('diagResults').hidden = false;

    const badges = [];
    if (s.ok) badges.push(`<span class="badge badge-ok">✓ ${s.ok} пройдено</span>`);
    if (s.warn) badges.push(`<span class="badge badge-warn">! ${s.warn} внимание</span>`);
    if (s.fail) badges.push(`<span class="badge badge-err">✕ ${s.fail} ошибок</span>`);
    if (s.skip) badges.push(`<span class="badge badge-mute">- ${s.skip} пропущено</span>`);
    if (report.elapsed_sec != null) badges.push(`<span class="badge badge-mute">⏱ ${report.elapsed_sec} с</span>`);
    $('diagSummary').innerHTML = badges.join('');

    const ICONS = {
      ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
      warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
      fail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
      skip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    };

    const rows = (report.checks || []).map(c => `
      <div class="diag-row chk-${c.status}">
        <div class="diag-icon">${ICONS[c.status] || ICONS.skip}</div>
        <div class="diag-param">${escapeHtml(c.name)}</div>
        <div class="diag-value"${c.tech ? ` data-popover-title="Технические детали" data-popover="${escapeHtml(c.tech)}"` : ''}>${escapeHtml(c.detail || '')}</div>
      </div>`).join('');
    $('diagList').innerHTML = rows || '<div class="empty-note">Нет результатов</div>';

    $('diagRecommend').hidden = !((s.fail || 0) > 0);

    this._last = report.report_text || '';
    $('diagCopyBtn').hidden = !this._last;
  },

  async copyReport() {
    if (!this._last) return;
    try {
      await navigator.clipboard.writeText(this._last);
      showToast('Отчёт скопирован', 'ok');
    } catch (e) {
      const ta = document.createElement('textarea');
      ta.value = this._last;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); showToast('Отчёт скопирован', 'ok'); }
      catch (e2) { showToast('Не удалось скопировать', 'warn'); }
      document.body.removeChild(ta);
    }
  },
};

// ══════════════════════════ СПИСКИ ══════════════════════════

// ── Игровые блокировки: домены (авторизация) + UDP-фикс (коннект) ──
// Домены применяются сразу (hot-reload hostlist), UDP-профили - при
// следующем запуске обхода/переустановке службы.
const GamesPage = {
  _data: null,
  _open: {},
  _svcWired: false,
  _checks: {},

  async onShow() {
    const body = $('gamesBody');
    if (!this._svcWired) {
      const svcBtn = $('gamesSvcBtn');
      if (svcBtn) svcBtn.addEventListener('click', () => this.reinstallService());
      this._svcWired = true;
    }
    try {
      const r = await apiGet('/games');
      this._data = (r.games && Array.isArray(r.games.games))
        ? r.games : { games: [] };
      this.render();
    } catch (e) {
      body.innerHTML = '<div class="empty-note">Не удалось загрузить: '
        + escapeHtml(e.message || String(e)) + '</div>';
    }
  },

  render() {
    const body = $('gamesBody');
    const games = this._data.games || [];
    const q = (($('gamesSearch') && $('gamesSearch').value) || '')
      .trim().toLowerCase();
    const visible = games.map((g, gi) => ({ g, gi })).filter(({ g }) =>
      !q || String(g.name || '').toLowerCase().includes(q) ||
      (g.domains || []).some(d =>
        String(d.domain || '').toLowerCase().includes(q)));
    if (!visible.length) {
      body.innerHTML = '<div class="empty-note">' +
        (games.length ? 'Ничего не найдено' : 'Список пуст') + '</div>';
      return;
    }
    body.innerHTML = visible.map(({ g, gi }) => {
      const open = !!this._open[g.id || gi];
      const domCount = (g.domains || []).length;
      const domOn = (g.domains || []).filter(d => d.on).length;
      const udpCount = (g.udp || []).length;
      const udpOn = (g.udp || []).filter(u => u.on).length;
      const udpPorts = (g.udp || []).map(u => u.ports).join(', ');
      const check = this._checks[g.id || gi] || null;
      const mark = (domain) => {
        if (!check) return '';
        const r = check[domain];
        if (!r) return '';
        return r.ok
          ? ' <span class="st-ok">✓</span>'
          : ` <span class="st-err" title="код ${escapeHtml(r.code)}">✗ ${escapeHtml(r.code)}</span>`;
      };
      return `
      <div class="game-item${open ? ' open' : ''}">
        <div class="game-row" data-g-expand="${gi}">
          <div class="game-left">
            <svg class="game-chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
            <span class="game-title">${escapeHtml(g.name || g.id)}</span>
            <div class="game-badges">
              ${domCount ? `<span class="pill-badge" data-popover-title="Домены игры" data-popover="Включено ${domOn} из ${domCount}: ${escapeHtml((g.domains || []).map(d => d.domain).join(', '))}">домены: ${domOn}/${domCount}</span>` : ''}
              ${udpCount ? `<span class="pill-badge" data-popover-title="UDP-фикс" data-popover="Включено ${udpOn} из ${udpCount}. Порт: ${escapeHtml(udpPorts || '')}">UDP-фикс: ${udpOn}/${udpCount}</span>` : ''}
            </div>
          </div>
          <label class="switch" title="Включить игру" data-g-noexp="1">
            <input type="checkbox" data-g-on="${gi}" ${g.enabled ? 'checked' : ''}>
            <span class="switch-track"><span class="switch-knob"></span></span>
          </label>
        </div>
        <div class="game-details">
          <div class="detail-group">
            <div class="group-label">Домены авторизации и лобби</div>
            ${(g.domains || []).map((d, di) => `
              <label class="rule-item">
                <input type="checkbox" class="cbx" data-g-dom="${gi}:${di}" ${d.on ? 'checked' : ''}>
                <div class="rule-content">
                  <div class="rule-main-line">
                    <span class="rule-target">${escapeHtml(d.domain)}${mark(d.domain)}</span>
                  </div>
                  ${d.note ? `<div class="rule-comment">${d.tag ? `<span class="${d.warn ? 'comment-warning' : 'comment-tag'}">${escapeHtml(d.tag)}:</span> ` : ''}${escapeHtml(d.note)}</div>` : ''}
                </div>
              </label>`).join('') || '<div class="empty-note">Доменов нет</div>'}
          </div>
          <div class="detail-group">
            <div class="group-label">UDP-фикс (подключение к игровым серверам)</div>
            ${(g.udp || []).map((u, ui) => `
              <label class="rule-item">
                <input type="checkbox" class="cbx" data-g-udp="${gi}:${ui}" ${u.on ? 'checked' : ''}>
                <div class="rule-content">
                  <div class="rule-main-line">
                    <span class="rule-target">Порт UDP ${escapeHtml(u.ports)}</span>
                    <span class="pill-badge" style="color: var(--ok)">fake на старте</span>
                  </div>
                  ${u.note ? `<div class="rule-comment">${u.tag ? `<span class="comment-tag">${escapeHtml(u.tag)}:</span> ` : ''}${escapeHtml(u.note)}</div>` : ''}
                  <div class="ip-subnets">Подсети: ${escapeHtml((u.cidrs || []).join(', '))}</div>
                </div>
              </label>`).join('') || '<div class="empty-note">UDP-правил нет</div>'}
          </div>
          <div class="game-actions" data-g-noexp="1">
            <button class="btn btn-sm" data-g-check="${gi}" ${domOn ? '' : 'disabled'} title="Быстрая проба включённых доменов игры: открываются ли они сейчас">Проверить домены</button>
            <button class="btn btn-sm" data-g-analyze="${gi}" ${g.process ? '' : 'disabled'} title="${g.process ? 'Запустить сетевой анализ процесса игры' : 'У игры не задан процесс'}">Анализ приложения</button>
            <span class="meta">${g.process ? 'процесс: ' + escapeHtml(g.process) : 'процесс не задан'}</span>
          </div>
        </div>
      </div>`;
    }).join('');
    body.querySelectorAll('[data-g-expand]').forEach(row =>
      row.addEventListener('click', (ev) => {
        if (ev.target.closest('[data-g-noexp]')) return;
        const gi = +row.dataset.gExpand;
        const key = games[gi].id || gi;
        this._open[key] = !this._open[key];
        this.render();
      }));
    body.querySelectorAll('[data-g-on]').forEach(cb =>
      cb.addEventListener('change', () => {
        games[+cb.dataset.gOn].enabled = cb.checked;
        this.save();
      }));
    body.querySelectorAll('[data-g-dom]').forEach(cb =>
      cb.addEventListener('change', () => {
        const [gi, di] = cb.dataset.gDom.split(':').map(Number);
        games[gi].domains[di].on = cb.checked;
        this.save();
      }));
    body.querySelectorAll('[data-g-udp]').forEach(cb =>
      cb.addEventListener('change', () => {
        const [gi, ui] = cb.dataset.gUdp.split(':').map(Number);
        games[gi].udp[ui].on = cb.checked;
        this.save();
      }));
    body.querySelectorAll('[data-g-analyze]').forEach(btn =>
      btn.addEventListener('click', (ev) => {
        ev.stopPropagation();
        this.analyzeGame(+btn.dataset.gAnalyze);
      }));
    body.querySelectorAll('[data-g-check]').forEach(btn =>
      btn.addEventListener('click', (ev) => {
        ev.stopPropagation();
        this.checkDomains(+btn.dataset.gCheck);
      }));
  },

  // Быстрая проба включённых доменов игры (сквозь текущий обход, если он есть)
  async checkDomains(gi) {
    const g = (this._data.games || [])[gi];
    if (!g) return;
    const key = g.id || gi;
    const btn = document.querySelector(`[data-g-check="${gi}"]`);
    if (btn) { btn.disabled = true; btn.textContent = 'Проверяю…'; }
    Activity.set('games', `Проверка доменов: ${g.name || g.id}`);
    try {
      const r = await apiPost('/games/check', { id: g.id || gi });
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      const map = {};
      (r.results || []).forEach(x => { map[x.domain] = x; });
      this._checks[key] = map;
      const bad = (r.results || []).filter(x => !x.ok);
      if (!r.results || !r.results.length) {
        Activity.done('Нечего проверять');
        showToast('Нет включённых доменов', 'warn');
      } else if (bad.length) {
        Activity.fail(`Не открываются: ${bad.length}`);
        showToast('Не открываются: ' + bad.map(x => x.domain).join(', '), 'warn');
      } else {
        Activity.done('Все домены открываются');
        showToast('Все домены открываются', 'ok');
      }
      this.render();
    } catch (e) {
      Activity.fail('Проверка доменов: ошибка');
      showToast('Проверка доменов: ' + (e.message || e), 'error');
      if (btn) { btn.disabled = false; btn.textContent = 'Проверить домены'; }
    }
  },

  async reinstallService() {
    const ok = await Confirm.ask({
      title: 'Переустановить службу?',
      text: 'Это нужно, чтобы UDP-фикс игр вступил в силу. Обход на пару секунд прервётся.',
      ok: 'Переустановить',
    });
    if (!ok) return;
    MainPage.svcInstall();
  },

  analyzeGame(gi) {
    const g = (this._data.games || [])[gi];
    const proc = ((g && g.process) || '').trim();
    if (!proc) {
      showToast('У игры не задан процесс для анализа', 'error');
      return;
    }
    // Запомним игру: в анализе найденные домены можно будет добавить сразу в неё
    TesterPage._gameContext = { id: g.id || gi, name: g.name || g.id };
    location.hash = '#probe';
    setTimeout(async () => {
      const inp = $('probeProcInput');
      if (inp) inp.value = proc;
      try { await TesterPage.scanProbeProcesses(true); } catch (e) { /* не критично */ }
      if (TesterPage._hintProbeProcess) TesterPage._hintProbeProcess();
      TesterPage.startProbe();
    }, 250);
  },

  async save() {
    try {
      const r = await apiPost('/games/save', { games: this._data });
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      showToast(r.message || 'Сохранено', 'ok');
    } catch (e) {
      showToast('Игровые блокировки: ' + (e.message || e), 'error');
    }
  },
};

// ── О программе: обновления и техническая информация (подвал меню) ──
const AppInfo = {
  _wired: false,

  async open() {
    try {
      const r = await apiGet('/app-info');
      const i = r.info || {};
      const rows = [
        `Версия: <b>${escapeHtml(i.version || '?')}</b>`,
        `Сборка: ${i.frozen ? 'EXE (onefile)' : 'portable (Python)'}`,
        `Папка: <span class="meta">${escapeHtml(i.path || '')}</span>`,
      ];
      if (i.exe_sha256) {
        rows.push(`SHA256 exe: <span class="meta">${escapeHtml(i.exe_sha256)}</span>`);
      }
      if (i.update_key) {
        rows.push(`Ключ подписи обновлений: <b>${escapeHtml(i.update_key)}</b>`);
      }
      $('appInfoBody').innerHTML = rows.join('<br>');
      $('appInfoStatus').textContent = '';
      Modal.open('appInfoOverlay');
      this._wire();
    } catch (e) {
      showToast('Не удалось получить сведения: ' + (e.message || e), 'error');
    }
  },

  close() { Modal.close('appInfoOverlay'); },

  _wire() {
    if (this._wired) return;
    this._wired = true;
    $('appInfoClose').addEventListener('click', () => this.close());
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && $('appInfoOverlay').classList.contains('open')) this.close();
    });
    $('appInfoOverlay').addEventListener('click', (ev) => {
      if (ev.target.id === 'appInfoOverlay') this.close();
    });
    $('appInfoCheck').addEventListener('click', async () => {
      const st = $('appInfoStatus');
      st.textContent = 'Проверяю…';
      try {
        const r = await apiGet('/update-check?force=1');
        if (r.error) throw new Error(r.error);
        if (r.available) {
          st.innerHTML = `Доступна версия <b>${escapeHtml(r.latest || '')}</b> - смотрите баннер вверху страницы.`;
          $('updateVersion').textContent = r.latest || '';
          $('updateLink').href = r.url || '#';
          $('updateMirrorLink').href = r.mirror_url || '#';
          App._updateTag = r.tag || '';
          $('updateBanner').hidden = false;
        } else {
          st.textContent = `Установлена последняя версия (${r.current || ''})`;
        }
      } catch (e) {
        st.textContent = 'Ошибка проверки: ' + (e.message || e);
      }
    });
  },
};

const ListsPage = {
  _loaded: false,
  saved: {},
  _badLines: {},   // key -> массив номеров ошибочных строк (для гутера)
  _bundled: null,   // Set доменов из bundled-включений (для проверки приоритетов)
  _activeList: 'domInc',

  showList(key) {
    if (!this.editors[key]) return;
    this._activeList = key;
    document.querySelectorAll('[data-list-tab]').forEach(t => {
      const on = t.dataset.listTab === key;
      t.classList.toggle('active', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    document.querySelectorAll('[data-list-panel]').forEach(p =>
      p.classList.toggle('active', p.dataset.listPanel === key));
    const ta = $(key + 'Textarea');
    if (ta) this._syncNums(key);
  },

  editors: {
    domInc: { api: '/include-list', kind: 'domain' },
    domExc: { api: '/exclude-list', kind: 'domain' },
    ipInc: { api: '/ipset-include-list', kind: 'cidr' },
    ipExc: { api: '/ipset-exclude-list', kind: 'cidr' },
  },

  onShow() {
    if (!this._loaded) {
      this._loaded = true;
      const helpBtn = $('toggleHelpBtn');
      if (helpBtn) helpBtn.addEventListener('click', () => {
        const det = $('helpDetails');
        const open = !!det && det.hidden;
        if (det) det.hidden = !open;
        helpBtn.classList.toggle('is-open', open);
      });
      document.querySelectorAll('[data-save]').forEach(btn =>
        btn.addEventListener('click', () => this.save(btn.dataset.save)));
      // Вкладки списков: один большой редактор вместо четырёх окон
      document.querySelectorAll('[data-list-tab]').forEach(tab =>
        tab.addEventListener('click', () => this.showList(tab.dataset.listTab)));
      this.showList(this._activeList || 'domInc');
      apiGet('/bundled-domains')
        .then(r => { this._bundled = new Set(r.domains || []); })
        .catch(() => {});
      Object.keys(this.editors).forEach(key => {
        const ta = $(key + 'Textarea');
        ta.addEventListener('input', () => this.validate(key));
        ta.addEventListener('scroll', () => this._syncNums(key));
        this.load(key);
      });
      // резервная копия настроек (экспорт/импорт юзер-файлов)
      const exp = $('btnSettingsExport');
      if (exp) exp.addEventListener('click', () => this.exportSettings());
      const hc = $('btnListsCheck');
      if (hc) hc.addEventListener('click', () => this.checkHealth(true));
      const hd = $('btnListsDedupe');
      if (hd) hd.addEventListener('click', () => this.dedupeLists());
    }
    this.checkHealth(false);
    this.loadContested();
  },

  async exportSettings() {
    const btn = $('btnSettingsExport');
    if (btn) btn.disabled = true;
    try {
      const r = await apiPost('/settings/export', {});
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      const fileName = (r.name || '').split('\\').pop();
      showToast(`Настройки сохранены: ${fileName} в папке программы`, 'ok');
      const res = $('settingsResult');
      if (res) res.textContent = 'Сохранено: ' + fileName;
    } catch (e) {
      showToast('Экспорт не удался: ' + (e.message || e), 'error');
    }
    if (btn) btn.disabled = false;
  },

  async importSettings(input) {
    const file = input.files && input.files[0];
    if (!file) return;
    const btn = $('btnSettingsExport');
    if (btn) btn.disabled = true;
    const res = $('settingsResult');
    if (res) res.textContent = 'Импортирую…';
    try {
      const b64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
        reader.onerror = () => reject(new Error('не удалось прочитать файл'));
        reader.readAsDataURL(file);
      });
      const r = await apiPost('/settings/import', { data: b64 });
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      showToast(r.message || 'Настройки восстановлены', 'ok');
      if (res) res.textContent = `Восстановлено: ${r.imported}, пропущено: ${r.skipped}`;
      await this.load('domInc');
      await this.load('domExc');
      await this.load('ipInc');
      await this.load('ipExc');
    } catch (e) {
      showToast('Импорт не удался: ' + (e.message || e), 'error');
      if (res) res.textContent = '';
    }
    input.value = '';
    if (btn) btn.disabled = false;
  },

  // ── Спорные домены (AWS и др.: десинк одним нужен, других ломает) ──
  async loadContested() {
    const body = $('contestedBody');
    const prot = $('contestedProt');
    if (!body) return;
    try {
      const r = await apiGet('/contested/status');
      if (prot) {
        const dot = prot.querySelector('.dot');
        const txt = prot.querySelector('.state-text');
        const running = !!r.protection_running;
        dot.className = 'dot ' + (running ? 'dot-ok' : 'dot-off');
        txt.className = 'state-text ' + (running ? 'st-ok' : 'st-mute');
        txt.textContent = running ? 'проба идёт через работающий обход' : 'обход не запущен - проба будет «в голую»';
      }
      body.innerHTML = '';
      for (const it of (r.items || [])) {
        const block = document.createElement('div');
        block.className = 'service-block';
        block.innerHTML = `
          <div class="service-row">
            <div class="service-info">
              <span class="service-name">${escapeHtml(it.title)}</span>
              <span class="service-domain">${escapeHtml(it.domain)}</span>
            </div>
            <div class="service-desc">${escapeHtml(it.why)}</div>
            <div class="service-actions">
              <button class="btn btn-sm btn-primary" data-ct-check="${escapeHtml(it.id)}">Проба</button>
              <span class="switch-cap">в обход</span>
              <label class="switch" title="Включить/выключить обход для этого домена">
                <input type="checkbox" ${it.enabled ? 'checked' : ''} data-ct-id="${escapeHtml(it.id)}">
                <span class="switch-track"><span class="switch-knob"></span></span>
              </label>
            </div>
          </div>
          <div data-ct-result="${escapeHtml(it.id)}"></div>`;
        body.appendChild(block);
      }
      body.querySelectorAll('[data-ct-id]').forEach(cb =>
        cb.addEventListener('change', () => this.toggleContested(cb.dataset.ctId, cb.checked, cb)));
      body.querySelectorAll('[data-ct-check]').forEach(btn =>
        btn.addEventListener('click', () => this.checkContested(btn.dataset.ctCheck, btn)));
    } catch (err) {
      frontendLog('contested: CATCH ' + (err.message || String(err)));
      body.innerHTML = '<div class="empty-note">Не удалось загрузить спорные домены: '
        + escapeHtml(err.message || String(err)) + '</div>';
    }
  },

  async toggleContested(id, enabled, cb) {
    cb.disabled = true;
    try {
      const r = await apiPost('/contested/toggle', { id, enabled });
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      showToast(r.message, 'ok');
      const res = document.querySelector(`[data-ct-result="${id}"]`);
      if (res) res.textContent = '';
      await this.load('domInc');
    } catch (e) {
      showToast('Спорные домены: ' + (e.message || e), 'error');
      cb.checked = !enabled;
    }
    cb.disabled = false;
  },

  async checkContested(id, btn) {
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = 'Проба…';
    const res = document.querySelector(`[data-ct-result="${id}"]`);
    if (res) {
      res.innerHTML = '<div class="test-result-box loading"><div class="mini-spinner"></div>' +
        '<span>Отправка тестового запроса (до 10 сек)…</span></div>';
    }
    try {
      const r = await apiPost('/contested/check', { id });
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      const code = parseInt(r.code, 10);
      const alive = code >= 100 && code < 500 && code !== 0;
      const engine = !!r.engine_running;
      const toggled = !!r.enabled;
      const protectedNow = engine && toggled;  // домен реально обрабатывается обходом
      const badge = `${alive ? '✓' : '✕'} HTTP ${r.code || '-'} · ${r.elapsed} с`;
      let title, advice;
      if (alive) {
        if (protectedNow) {
          title = 'Работает с обходом';
          advice = 'Домен включён в обход и отвечает. Тумблер можно оставить включённым.';
        } else if (toggled) {
          title = 'Работает без обхода';
          advice = 'Обход сейчас не запущен. Тумблер включён - перепроверьте после запуска обхода: если с обходом сервис ломается, тумблер стоит выключить.';
        } else {
          title = 'Работает без обхода';
          advice = 'Домен не в обходе и отвечает. Тумблер не нужен - держите выключенным.';
        }
      } else if (protectedNow) {
        title = 'С обходом не отвечает';
        advice = 'Тумблер включён - вероятно, текущий десинк ломает сервис. Выключите тумблер и повторите пробу: правка списков применяется к новым подключениям. Если и без обхода нет - жёсткий блок, потребуется WARP.';
      } else if (!engine) {
        title = 'Обход не запущен';
        advice = toggled
          ? 'Запустите обход и повторите пробу - тумблер уже включён.'
          : 'Запустите обход и повторите пробу. Если сервис без обхода не живёт - включите тумблер.';
      } else {
        title = 'Не отвечает и без обхода';
        advice = 'Домен не в обходе. Включите тумблер и повторите пробу - правка списков применяется к новым подключениям. Если и с обходом нет - IP-блок, поможет только WARP.';
      }
      if (res) {
        res.innerHTML = `
          <div class="test-result-box ${alive ? 'success' : 'danger'}">
            <span class="res-badge">${badge}</span>
            <div class="res-content">
              <span class="res-title">${title}</span>
              <span class="res-advice">${advice}</span>
            </div>
          </div>`;
      }
      showToast(`Проба: HTTP ${r.code || '-'}`, alive ? 'ok' : 'error');
    } catch (e) {
      if (res) {
        res.innerHTML = `<div class="test-result-box danger">
          <span class="res-badge">✕</span>
          <div class="res-content"><span class="res-title">Ошибка пробы</span>
          <span class="res-advice">${escapeHtml(e.message || String(e))}</span></div></div>`;
      }
      showToast('Проба: ' + (e.message || e), 'error');
    }
    btn.textContent = label;
    btn.disabled = false;
  },

  // ── Здоровье списков: дубли/повторы/конфликты (серверный list_health) ──

  async checkHealth(warnIfClear) {
    const txt = $('listsHealthText');
    const btn = $('btnListsDedupe');
    if (!txt) return;
    txt.textContent = 'Проверяю…';
    try {
      const r = await apiGet('/lists/health');
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      const bits = [];
      if (r.total_dups) bits.push(`дубли: ${r.total_dups}`);
      if (r.total_cross) bits.push(`повторы между вашими списками: ${r.total_cross}`);
      if (r.total_redundant) bits.push(`повторы уже включённых: ${r.total_redundant}`);
      if (r.total_conflicts) bits.push(`конфликты вкл/искл: ${r.total_conflicts}`);
      if (bits.length) {
        const example = (r.conflicts[0] && r.conflicts[0].entry)
          || (r.redundant[0] && r.redundant[0].entry) || '';
        txt.innerHTML = `<span class="st-err">Найдено: ${escapeHtml(bits.join(' · '))}</span>`
          + (example ? ` <span class="meta">(например: ${escapeHtml(example)})</span>` : '');
        if (btn) btn.hidden = false;
        if (warnIfClear) showToast('Списки: ' + bits.join(' · '), 'warn');
      } else {
        txt.textContent = 'Проблем не найдено - списки чистые.';
        if (btn) btn.hidden = true;
        if (warnIfClear) showToast('Списки в порядке', 'ok');
      }
    } catch (e) {
      txt.textContent = 'Не удалось проверить: ' + (e.message || e);
    }
  },

  async dedupeLists() {
    const ok = await Confirm.ask({
      title: 'Убрать дубли во всех списках?',
      text: 'Несохранённые правки в полях будут потеряны.',
      ok: 'Убрать дубли',
      danger: true,
    });
    if (!ok) return;
    const btn = $('btnListsDedupe');
    btn.disabled = true;
    try {
      const r = await apiPost('/lists/dedupe', {});
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      showToast(r.total ? `Убрано лишних записей: ${r.total}` : 'Дублей не найдено', 'ok');
      Object.keys(this.editors).forEach(key => this.load(key));
      this.checkHealth(false);
    } catch (e) {
      showToast('Не удалось почистить: ' + (e.message || e), 'error');
    }
    btn.disabled = false;
  },

  // Кнопка «В обход» из подсказок анализа приложения (дедуп на сервере)
  async addDomainSuggestion(btn) {
    const domain = btn.dataset.addDomain;
    btn.disabled = true;
    try {
      const r = await apiPost('/lists/add-domain', { domain, mode: 'include' });
      btn.textContent = r.message || 'Готово';
      showToast(`${domain}: ${r.message || ''}`.trim(), r.status === 'ok' ? 'ok' : 'warn');
      if (r.status === 'ok') this.checkHealth(false);
    } catch (e) {
      btn.textContent = 'Ошибка';
      showToast('Не удалось добавить: ' + (e.message || e), 'error');
    }
  },

  async load(key) {
    const e = this.editors[key];
    try {
      const r = await apiGet(e.api);
      $(key + 'Textarea').value = r.content || '';
      this.saved[key] = $(key + 'Textarea').value;
      this.validate(key);
    } catch (err) {
      $(key + 'Valid').innerHTML = '<span class="bad">не удалось загрузить список</span>';
    }
  },

  _dirtyCheck(key) {
    const dirty = $(key + 'Textarea').value !== (this.saved[key] ?? '');
    const cnt = $(key + 'Count');
    if (cnt) cnt.classList.toggle('dirty', dirty);
    const btn = document.querySelector(`[data-save="${key}"]`);
    if (btn) btn.classList.toggle('dirty', dirty);
    const ta = $(key + 'Textarea');
    const card = ta && ta.closest('.list-card');
    if (card) card.classList.toggle('is-dirty', dirty);
    return dirty;
  },

  validate(key) {
    const e = this.editors[key];
    const ta = $(key + 'Textarea');
    const lines = ta.value.split('\n');
    let ok = 0;
    const bad = [];
    lines.forEach((line, i) => {
      const s = line.trim();
      if (!s || s.startsWith('#')) return;
      if (e.kind === 'domain' ? this._validDomain(s) : this._validCidr(s)) ok++;
      else bad.push(i + 1);
    });
    this._badLines[key] = bad;
    this._syncNums(key);
    const dirty = this._dirtyCheck(key);

    const cnt = $(key + 'Count');
    if (cnt) cnt.textContent = String(ok);

    const btn = document.querySelector(`[data-save="${key}"]`);
    if (btn) btn.disabled = bad.length > 0 || !dirty;

    const wrap = ta.closest('.editor-wrapper');
    if (wrap) wrap.classList.toggle('has-error', bad.length > 0);
    const card = ta.closest('.list-card');
    if (card) card.classList.toggle('is-error', bad.length > 0);

    const ICON_ERR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';
    const ICON_DOT = '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="8"/></svg>';
    const ICON_OK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
    const box = $(key + 'Valid');
    box.className = 'status-msg';
    box.removeAttribute('data-popover');
    if (bad.length) {
      box.classList.add('status-error');
      const errText = `строки с ошибкой: ${bad.slice(0, 12).join(', ')}${bad.length > 12 ? '…' : ''} - сохранение заблокировано`;
      box.innerHTML = ICON_ERR + `<span>${errText}</span>`;
      box.setAttribute('data-popover', errText);
    } else if (dirty) {
      box.classList.add('status-unsaved');
      box.innerHTML = ICON_DOT + '<span>изменения не сохранены - нажмите «Сохранить»</span>';
    } else if (ok === 0) {
      box.classList.add('status-empty');
      box.innerHTML = '<span>список пуст - ни на что не влияет</span>';
    } else {
      box.classList.add('status-synced');
      box.innerHTML = ICON_OK + '<span>сохранено</span>';
    }
    $(key + 'Result').textContent = '';
    return bad.length === 0;
  },

  // Пересечение пользовательского списка с bundled-включениями
  _bundledOverlap(key) {
    if (!this._bundled || !this._bundled.size) return [];
    if (key !== 'domInc' && key !== 'domExc') return [];
    return $(key + 'Textarea').value.split('\n')
      .map(l => l.trim().toLowerCase())
      .filter(l => l && !l.startsWith('#') && this._bundled.has(l));
  },

  _fmtList(items) {
    return items.slice(0, 3).join(', ') + (items.length > 3 ? ` +${items.length - 3}` : '');
  },

  _validDomain(s) {
    if (/\s|,|;|\//.test(s) || s.startsWith('.') || s.endsWith('.')) return false;
    return /^[A-Za-z0-9А-Яа-яЁё]([A-Za-z0-9А-Яа-яЁё_-]*[A-Za-z0-9А-Яа-яЁё])?(\.[A-Za-z0-9А-Яа-яЁё]([A-Za-z0-9А-Яа-яЁё_-]*[A-Za-z0-9А-Яа-яЁё])?)+\.?$/.test(s);
  },

  _syncNums(key) {
    const ta = $(key + 'Textarea');
    const nums = $(key + 'Nums');
    if (!nums) return;
    const n = ta.value.split('\n').length;
    const bad = new Set(this._badLines[key] || []);
    let html = '';
    for (let i = 1; i <= n; i++) {
      html += (i > 1 ? '\n' : '') + (bad.has(i) ? `<span class="bad-line">${i}</span>` : String(i));
    }
    nums.innerHTML = html;
    nums.scrollTop = ta.scrollTop;
  },

  _validCidr(s) {
    if (s.indexOf(':') >= 0) return /^[0-9a-fA-F:]+(\/\d{1,3})?$/.test(s);
    const m = s.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(?:\/(\d{1,2}))?$/);
    if (!m) return false;
    for (let i = 1; i <= 4; i++) if (+m[i] > 255) return false;
    if (m[5] != null && +m[5] > 32) return false;
    return true;
  },

  async save(key) {
    if (!this.validate(key)) {
      showToast('Исправьте ошибочные строки - список не сохранён', 'error');
      return;
    }
    const e = this.editors[key];
    const el = $(key + 'Result');
    el.textContent = 'Сохранение…';
    try {
      const r = await apiPost(e.api, { content: $(key + 'Textarea').value });
      if (r.status === 'ok') {
        el.textContent = 'сохранено';
        this.saved[key] = $(key + 'Textarea').value;
        // winws2 перечитывает списки на лету (mtime) - правка вступает в
        // силу для НОВЫХ подключений, перезапуск обхода не нужен.
        let msg = 'Список сохранён - применится к новым подключениям';
        let type = 'ok';
        const overlap = this._bundledOverlap(key);
        if (key === 'domExc' && overlap.length) {
          // Исключение сильнее включения (hostlist.c: exclude проверяется
          // первым) - пользователь должен знать, что обход на домен отключится.
          msg = 'Приоритет у исключения: обход отключится для ' + this._fmtList(overlap) + '. ' + msg;
          type = 'warn';
        } else if (key === 'domInc' && overlap.length) {
          msg += ' (уже в стандартных списках - дубль безвреден: ' + this._fmtList(overlap) + ')';
        }
        showToast(msg, type);
        this.validate(key);
      } else {
        el.textContent = 'ошибка';
        showToast('Ошибка сохранения: ' + (r.message || ''), 'error');
      }
    } catch (err) {
      el.textContent = 'ошибка';
      showToast('Ошибка: ' + err.message, 'error');
    }
  },
};

// ══════════════════════════ ТЕСТЕР ══════════════════════════

const CdnStab = {
  _polling: false,
  _pollTicks: 0,
  _applied: new Set(),

  VERDICTS: {
    fix: { label: 'DPI режет - лечится', cls: 'bad', btn: { action: 'general', text: 'В обход' } },
    covered: { label: 'уже в ipset-all - наложения нет', cls: '', btn: null },
    ok: { label: 'чисто', cls: '', btn: null },
    break: { label: 'обход ломает', cls: 'bad', btn: { action: 'exclude', text: 'В стоп-лист' } },
    hard: { label: 'не лечится', cls: '', btn: null },
    dead: { label: 'хост мёртв (не блок)', cls: '', btn: null },
    unknown: { label: 'не проверено', cls: '', btn: null },
  },

  _bound: false,

  init() {
    if (this._bound) return;
    this._bound = true;
    $('cdnScanBtn').addEventListener('click', () => this.scan());
    $('cdnCancelBtn').addEventListener('click', () => this.cancel());
    App.bindHelpToggle('cdnHelpBtn', 'cdnHelpDetails');
  },

  cancel() {
    apiPost('/tester/action', { action: 'cancel' }).catch(() => {});
    this._fail('Сканирование отменено.');
  },

  async scan() {
    if (this._polling || App.testActive) return;
    this._applied = new Set();
    App.setTestActive(true);
    $('cdnScanBtn').disabled = true;
    $('cdnIdle').hidden = true;
    $('cdnResults').hidden = true;
    $('cdnScanning').hidden = false;
    $('cdnProgressTitle').textContent = 'Подготовка…';
    $('cdnProgressPct').textContent = '0%';
    $('cdnProgressFill').style.width = '0%';
    try {
      // apiPost уже добавляет /api - пути без префикса
      const r = await apiPost('/tester/action', { action: 'cdn_scan' });
      if (r.status !== 'ok') {
        this._fail('Не удалось запустить сканирование: ' + (r.message || ''));
        return;
      }
      this._polling = true;
      this._pollTicks = 0;
      this._poll();
    } catch (err) {
      this._fail('Ошибка запуска: ' + err.message);
    }
  },

  _fail(msg) {
    this._stop();
    Activity.fail('Скан CDN: ' + msg);
    $('cdnIdle').hidden = true;
    $('cdnResults').hidden = false;
    $('cdnResults').innerHTML = `<div class="empty-note st-err">${escapeHtml(msg)}</div>`;
    showToast(msg, 'error');
  },

  async _poll() {
    if (!this._polling) return;
    if (++this._pollTicks > 200) {  // ~4 минуты максимум
      this._fail('Сканирование не завершилось за отведённое время.');
      return;
    }
    let st;
    try {
      st = await apiGet('/tester/status');
    } catch {
      this._fail('Не удалось получить статус сканирования.');
      return;
    }
    if (st.running) {
      // M4: гонка старта - worker проставляет action_type асинхронно; первые
      // тики видят action прошлого прогона → ложное «другая задача»
      if (st.action && st.action !== 'cdn_scan' && this._pollTicks > 3) {
        this._fail('Запущена другая задача тестера - сканирование CDN прервано.');
        return;
      }
      const p = st.progress || {};
      $('cdnProgressTitle').textContent = p.message || 'Сканирование…';
      const pct = p.percent ?? 0;
      Activity.set('cdn', p.message || 'Скан CDN', pct, true);
      $('cdnProgressPct').textContent = Math.round(pct) + '%';
      $('cdnProgressFill').style.width = Math.min(100, Math.max(0, pct)) + '%';
      $('cdnProgressFill').setAttribute('aria-valuenow', Math.min(100, Math.max(0, pct)));
      setTimeout(() => this._poll(), 1200);
      return;
    }
    const fr = st.final_result;
    if (fr && fr.type === 'cdn_scan') {
      if (fr.error) {
        this._fail(fr.error);
        return;
      }
      this._render(fr);
      Activity.done('Скан CDN завершён');
      if (fr.naked_done && fr.note) showToast(fr.note);
    } else {
      this._fail(fr?.error || 'Сканирование прервано.');
    }
    this._stop();
  },

  _stop() {
    this._polling = false;
    App.setTestActive(false);
    $('cdnScanBtn').disabled = false;
    $('cdnScanning').hidden = true;
  },

  _render(fr) {
    const v = fr.verdicts || [];
    this._lastVerdicts = v;
    const counts = {};
    v.forEach(x => { counts[x.verdict] = (counts[x.verdict] || 0) + 1; });
    const sum = (k) => counts[k] || 0;
    const modeTxt = fr.ipset_mode
      ? 'Режим: IP-обход (тоггл включён)'
      : 'Режим: Hostlist (тоггл выключен)';
    const abFixed = v.filter(x => x.ipset === 'чинит').length;
    const abBroken = v.filter(x => x.ipset === 'ломает').length;
    const abRan = abFixed + abBroken > 0;
    // Кнопки есть у строк с IP-действиями: «чинит» (точечный ipset-обход
    // хоста), «ломает» при ipset-режиме (исключить IP), fix/break - доменные.
    const actionable = sum('fix') + sum('break') + (fr.ipset_mode ? abBroken : 0) + (!fr.ipset_mode ? abFixed : 0);

    let banner = '';
    if (abRan || actionable) {
      const recTitle = abRan
        ? (abBroken > abFixed
          ? 'Держите «Общий IP-обход» выключенным'
          : (abFixed > abBroken ? '«Общий IP-обход» можно держать включённым' : 'Эффект IP-обхода неоднозначный'))
        : 'Есть правки для применения';
      const recDesc = abRan
        ? `IP-обход чинит <b>${abFixed}</b> хост(а), но ломает <b>${abBroken}</b> - решайте по нужным хостам.`
        : 'Нажмите кнопки в строках - правка применится к спискам, обход перезапустится автоматически.';
      banner = `<div class="rec-banner">
        <div>
          <span class="rec-tag">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            Рекомендация по IP-обходу
          </span>
          <div class="rec-title">${recTitle}</div>
          <div class="rec-desc">${recDesc}</div>
        </div>
        ${actionable ? `<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <button id="cdnApplyAll" class="btn btn-primary">Применить все правки (${actionable})</button>
          <span class="meta rec-note" id="cdnApplyAllNote"></span>
        </div>` : ''}
      </div>`;
    }

    const metrics = `
      <span class="m-badge success" data-popover="Эти хосты открываются и без обхода - с ними всё хорошо.">✓ Чисто: ${sum('ok')}</span>
      ${actionable ? `<span class="m-badge warning" data-popover="Этим хостам обход мешает или их режет DPI - можно исправить кнопкой в строке.">● Требует правки: ${actionable}</span>` : ''}
      <span class="m-badge danger" data-popover="Не отвечает даже без обхода - похоже, сервер недоступен, это не блокировка.">✕ Не лечится: ${sum('hard')}</span>
      ${sum('covered') ? `<span class="m-badge neutral" data-popover="Уже покрыты общим IP-обходом - трогать не нужно.">Уже в ipset: ${sum('covered')}</span>` : ''}
      <span class="m-badge neutral" data-popover="Не отвечают ни с обходом, ни без него - вероятно, хост выключен или устарел.">Мёртвые: ${sum('dead')}</span>
      <span class="metrics-mode">${modeTxt}</span>`;

    const badgeCls = { fix: 'action', break: 'action', ok: 'clean', hard: 'fatal', dead: 'dead', covered: 'clean', unknown: 'neutral' };
    const badgeLabel = { fix: 'DPI режет - лечится', break: 'обход ломает', covered: 'уже в ipset', dead: 'хост мёртв' };
    const rows = v.map(x => {
      const vd = this.VERDICTS[x.verdict] || this.VERDICTS.unknown;
      const applied = this._applied.has(x.domain);
      let btn = '';
      let act = vd.btn || null;
      let actText = act ? act.text : '';
      // A/B-действия IP-based: «чинит» в hostlist-режиме -> ipset-включения;
      // «ломает» в ipset-режиме -> IP в исключения.
      if (!act && x.ipset === 'чинит' && !fr.ipset_mode && (x.ips || []).length) {
        act = { action: 'ipset-include' };
        actText = 'В ipset-включения';
      }
      if (!act && x.ipset === 'ломает' && fr.ipset_mode && (x.ips || []).length) {
        act = { action: 'ipset-exclude' };
        actText = 'Исключить IP';
      }
      if (!applied && act) {
        const text = (fr.ipset_mode && act.action === 'general')
          ? 'В ipset-включения' : actText;
        btn = `<button class="btn-row-action" data-cdn-act="${act.action}" data-cdn-domain="${escapeHtml(x.domain)}">${text}</button>`;
      } else if (applied) {
        btn = '<span class="meta">применено</span>';
      }
      const ips = (fr.ipset_mode && x.ips && x.ips.length)
        ? `<span class="meta"> ${escapeHtml(x.ips.join(', '))}</span>` : '';
      return `<tr data-cdn-ips="${escapeHtml((x.ips || []).join(','))}">
        <td><div class="host-cell">
          <span class="host-name">${escapeHtml(x.domain)}</span>
          ${x.provider ? `<span class="cdn-tag">${escapeHtml(x.provider)}</span>` : ''}
        </div></td>
        <td>${x.alive === 'A' ? 'да' : 'нет'}</td>
        <td>${x.dpi === 'DET' ? '<span class="st-err">режет</span>' : (x.dpi === 'ok' ? 'не режет' : '-')}</td>
        <td><span class="verdict-badge ${badgeCls[x.verdict] || 'neutral'}">${escapeHtml(badgeLabel[x.verdict] || vd.label)}</span>${ips}</td>
        <td>${x.ipset === 'ломает' ? '<span class="ip-ab-tag breaks">ломает</span>'
          : (x.ipset === 'чинит' ? '<span class="ip-ab-tag fixes">чинит</span>' : '-')}</td>
        <td style="text-align:right">${btn}</td>
      </tr>`;
    }).join('');

    let guide;
    if (actionable) {
      guide = 'Нажмите кнопку в строке - правка применится к спискам, и обход перезапустится автоматически. «чинит» = точечный IP-обход хоста; «ломает» = исключить его IP из IP-обхода. Либо примените всё сразу кнопкой вверху.';
    } else if (abRan) {
      guide = 'Точечных правок списков не требуется - смотрите итог по IP-обходу выше.';
    } else {
      guide = 'Живые хосты отвечают, stateful DPI не обнаружен, а мёртвые не отвечают и без защиты - это не блокировка. Проверять больше нечего.';
    }

    $('cdnResults').innerHTML = banner + `
      <div class="metrics-bar">${metrics}</div>
      <div class="hosts-table-wrap"><table class="hosts-table">
        <thead><tr>
          <th style="width:250px">Хост и CDN</th>
          <th style="width:90px">Под защитой</th>
          <th style="width:120px">Stateful DPI</th>
          <th>Вердикт</th>
          <th style="width:100px">IP-обход</th>
          <th style="width:170px;text-align:right">Действие</th>
        </tr></thead>
        <tbody>${rows || '<tr><td colspan="6"><div class="empty-note">Нет данных</div></td></tr>'}</tbody>
      </table></div>
      <div class="cdn-guide">${guide}</div>`;
    $('cdnResults').hidden = false;
    $('cdnResults').querySelectorAll('[data-cdn-act]').forEach(b =>
      b.addEventListener('click', () => this.apply(b, fr.ipset_mode)));
    const ab = $('cdnApplyAll');
    if (ab) ab.addEventListener('click', () => this.applyAll(fr));
    $('cdnResults').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  },

  // Собрать список правок из вердиктов (та же логика, что в apply()).
  _collectActions(fr) {
    const out = [];
    (this._lastVerdicts || []).forEach(x => {
      let action = null;
      if (x.verdict === 'fix') action = 'general';
      else if (x.verdict === 'break') action = 'exclude';
      else if (x.ipset === 'чинит' && !fr.ipset_mode && (x.ips || []).length) action = 'ipset-include';
      else if (x.ipset === 'ломает' && fr.ipset_mode && (x.ips || []).length) action = 'ipset-exclude';
      if (action && !this._applied.has(x.domain)) {
        out.push({ domain: x.domain, action, ips: x.ips || [] });
      }
    });
    return out;
  },

  async applyAll(fr) {
    const actions = this._collectActions(fr);
    if (!actions.length) return;
    const workingDomains = (this._lastVerdicts || [])
      .filter(x => x.alive === 'A')
      .map(x => x.domain);
    const preview = actions.map(a => `  ${a.domain} - ${a.action}`).join('\n');
    if (!confirm(`Применить все правки по матрице?\n\n${preview}\n\nОдин перезапуск обхода. Пропуски (наложения/нет IP) будут показаны.`)) return;
    const btn = $('cdnApplyAll');
    if (btn) { btn.disabled = true; btn.textContent = 'Применяю…'; }
    try {
      const r = await apiPost('/cdn/apply-all', {
        actions,
        working_domains: workingDomains,
      });
      if (r.status === 'ok') {
        (r.applied || []).forEach(d => this._applied.add(d));
        const skipped = r.skipped && r.skipped.length
          ? ` Пропущено: ${r.skipped.map(s => `${s.domain} (${s.reason})`).join('; ')}` : '';
        showToast(r.message, 'ok');
        const note = $('cdnApplyAllNote');
        if (note) note.textContent = skipped ? `⚠ ${skipped}` : '✓ всё применено';
        this._render(fr);
      } else {
        showToast('Ошибка: ' + (r.message || ''), 'error');
        if (btn) { btn.disabled = false; btn.textContent = `Применить все правки (${actions.length})`; }
      }
    } catch (err) {
      showToast('Ошибка: ' + err.message, 'error');
      if (btn) { btn.disabled = false; btn.textContent = `Применить все правки (${actions.length})`; }
    }
  },

  async apply(btn, ipsetMode) {
    const domain = btn.dataset.cdnDomain;
    const action = btn.dataset.cdnAct;
    const row = btn.closest('tr');
    const ips = row ? row.dataset.cdnIps : '';
    btn.disabled = true;
    btn.textContent = '…';
    try {
      // apiPost уже добавляет /api - путь без префикса
      // working_domains: живые в основном прогоне (кроме самой цели) - сервер
      // резолвит их в protection-множество и расширяет правки до наибольшего
      // чистого префикса (anycast сам вырождается в /32).
      const workingDomains = (this._lastVerdicts || [])
        .filter(x => x.alive === 'A' && x.domain !== domain)
        .map(x => x.domain);
      const r = await apiPost('/cdn/recommendation', {
        domain, action,
        ips: ips ? ips.split(',') : [],
        working_domains: workingDomains,
      });
      if (r.status === 'ok') {
        this._applied.add(domain);
        btn.textContent = '✓ ' + r.message.split(',')[0];
        showToast('Применено: ' + domain, 'ok');
      } else {
        btn.disabled = false;
        btn.textContent = (ipsetMode && action === 'general') ? 'В ipset-включения' : (action === 'general' ? 'В обход' : 'В стоп-лист');
        showToast('Ошибка: ' + (r.message || ''), 'error');
      }
    } catch (err) {
      btn.disabled = false;
      btn.textContent = (ipsetMode && action === 'general') ? 'В ipset-включения' : (action === 'general' ? 'В обход' : 'В стоп-лист');
      showToast('Ошибка: ' + err.message, 'error');
    }
  },
};

const AsnPage = {
  _polling: false,
  _bound: false,

  init() {
    if (this._bound) return;
    this._bound = true;
    $('asnScanBtn').addEventListener('click', () => this.scan());
    App.bindHelpToggle('asnHelpBtn', 'asnHelpDetails');
  },

  async scan() {
    if (this._polling || App.testActive) return;
    this._polling = true;
    App.setTestActive(true);
    $('asnScanBtn').disabled = true;
    $('asnIdle').hidden = true;
    $('asnResults').hidden = true;
    $('asnScanning').hidden = false;
    $('asnProgressTitle').textContent = 'Подготовка…';
    $('asnProgressPct').textContent = '0%';
    $('asnProgressFill').style.width = '0%';
    try {
      const r = await apiPost('/asn-scan', {});
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      const deadline = Date.now() + 10 * 60 * 1000;
      let final = null;
      while (!final && Date.now() < deadline) {
        await new Promise(res => setTimeout(res, 700));
        const st = await apiGet('/tester/status');
        if (st.error && !st.running) throw new Error(st.error);
        if (st.progress) {
          $('asnProgressTitle').textContent = st.progress.message || 'Сканирование…';
          const pct = st.progress.percent ?? 0;
          Activity.set('asn', st.progress.message || 'ASN-скан', pct, true);
          $('asnProgressPct').textContent = Math.round(pct) + '%';
          $('asnProgressFill').style.width = Math.min(100, Math.max(0, pct)) + '%';
          $('asnProgressFill').setAttribute('aria-valuenow', Math.min(100, Math.max(0, pct)));
        }
        if (!st.running) final = st.final_result;
      }
      if (!final) throw new Error('скан не завершился вовремя');
      if (final.type === 'asn_scan') {
        this._render(final.probes || [], final.restored || '');
        Activity.done('ASN-скан завершён');
      } else throw new Error('неожиданный результат');
    } catch (e) {
      Activity.fail('ASN-скан: ' + e.message);
      $('asnScanning').hidden = true;
      $('asnResults').hidden = false;
      $('asnResults').innerHTML = `<div class="empty-note st-err">${escapeHtml(e.message)}</div>`;
      showToast('ASN-скан: ' + e.message, 'error');
    }
    this._polling = false;
    App.setTestActive(false);
    $('asnScanBtn').disabled = false;
    $('asnScanning').hidden = true;
  },

  _render(probes, restored) {
    const okN = probes.filter(x => x.status === 'OK').length;
    const detN = probes.filter(x => x.status === 'DETECTED').length;
    const synN = probes.filter(x => x.status === 'SYN DROP').length;
    const rsts = probes.filter(x => x.status === 'TCP RST' || x.status === 'TLS RST').length;
    const errN = probes.length - okN - detN - synN - rsts;

    const metrics = `
      <span class="m-badge neutral">Проб: ${probes.length}</span>
      <span class="m-badge success">✓ Чисто: ${okN}</span>
      <span class="m-badge danger">✕ DETECTED: ${detN}</span>
      <span class="m-badge warning">● SYN DROP: ${synN}</span>
      ${rsts ? `<span class="m-badge warning">RST: ${rsts}</span>` : ''}
      ${errN ? `<span class="m-badge neutral">Прочие: ${errN}</span>` : ''}
      ${restored ? `<span class="metrics-mode">защита восстановлена: ${escapeHtml(restored)}</span>` : ''}`;

    const badgeCls = s => s === 'OK' ? 'clean' : (s === 'DETECTED' ? 'fatal' : (s === 'SYN DROP' ? 'action' : 'neutral'));
    const rows = probes.map(x => `
      <tr>
        <td class="host-name">${escapeHtml(x.id)}</td>
        <td class="mono">${escapeHtml(x.asn)}</td>
        <td>${escapeHtml(x.provider)}</td>
        <td><span class="verdict-badge ${badgeCls(x.status)}">${escapeHtml(x.status)}</span></td>
        <td class="meta">${escapeHtml(x.detail || '')}</td>
      </tr>`).join('');

    let guide = 'Если большинство проб <b>OK</b> и сайты работают - <b>ничего делать не нужно</b>: 100% «OK» не требуется, с моими пресетами доступно ~99% сайтов.';
    if (detN > 0) guide += ` «DETECTED» (${detN}) - stateful DPI режет CDN-класс: лечится кнопками на вкладке «CDN-стабилизация».`;
    if (synN > 0) guide += ` «SYN DROP» (${synN}) - диапазоны режутся целиком или IP списка протухли; десинк против этого не поможет.`;
    guide += ' Мобильная сеть меняет картину от часа к часу: перед выводами прогоните скан повторно с паузой.';

    $('asnResults').innerHTML = `
      <div class="metrics-bar">${metrics}</div>
      <div class="hosts-table-wrap"><table class="hosts-table">
        <thead><tr>
          <th style="width:200px">ID</th>
          <th style="width:120px">ASN</th>
          <th>Провайдер</th>
          <th style="width:130px">Статус</th>
          <th>Детали</th>
        </tr></thead>
        <tbody>${rows || '<tr><td colspan="5"><div class="empty-note">Нет данных</div></td></tr>'}</tbody>
      </table></div>
      <div class="cdn-guide">${guide}</div>`;
    $('asnResults').hidden = false;
  },
};

const TesterPage = {
  state: {
    extendedTest: false, collectLogs: false,
    vpnActive: false,
    currentResults: null, nakedResults: null, phase2Results: null,
    fullAnalysisResults: null,
    collectFormData: null, collectBatFile: null,
    testStartTime: 0, elapsedInterval: null,
    rows: null, currentKey: null, knownResults: 0,
  },

  onShow() {
    if (!this._bound) {
      this._bound = true;
      $('btnStartTest').addEventListener('click', () => this.startTest());
      $('btnDiagCheck').addEventListener('click', () => { location.hash = 'diagnostics'; });
      $('btnCancelTest').addEventListener('click', () => this.cancelTest());
      if (this._diagDoneRecently()) $('diagDoneNote').hidden = false;
      this.bindModals();
    }
  },

  // «выполнена» у шага 1 - только если диагностика реально была за сутки
  _diagDoneRecently() {
    const ts = +localStorage.getItem('z2_diag_done') || 0;
    return ts && (Date.now() - ts) < 24 * 60 * 60 * 1000;
  },

  // ── таблица стратегий ──

  _label(key) {
    if (key === '__naked__') return 'Без защиты (базовый уровень)';
    if (key === '__current__') return 'Zapret 1 (текущий)';
    return key;
  },

  _resetTable() {
    // Гасим отложенную очередь _addHostRow: «долётелившие» строки прошлого
    // теста не должны влиться в таблицу нового запуска.
    this._addHostRow.resetQueue();
    $('stratTbody').innerHTML =
      '<tr class="strat-empty"><td colspan="6">Ожидание первых результатов…</td></tr>';
    this.state.rows = new Map();
    this.state.currentKey = null;
  },

  _rowFor(profileKey) {
    const key = (profileKey || '__naked__').trim() || '__naked__';
    let r = this.state.rows.get(key);
    if (r) return r;
    const empty = $('stratTbody').querySelector('.strat-empty');
    if (empty) empty.remove();

    const tr = document.createElement('tr');
    tr.className = 'strat-row expandable';
    tr.innerHTML =
      `<td class="col-strat"><span class="strat-name">${escapeHtml(this._label(key))}</span></td>` +
      '<td class="col-state"><span class="strat-state"><span class="dot dot-idle"></span><span class="st-text">в очереди</span></span></td>' +
      '<td class="col-rate">-</td><td class="col-mini">-</td><td class="col-mini">-</td><td class="col-rate">0/0</td>';

    const detail = document.createElement('tr');
    detail.className = 'strat-detail';
    detail.hidden = true;
    detail.innerHTML = `<td colspan="6">
      <div class="subtable-header">
        <span>Проверка хостов в стратегии «${escapeHtml(this._label(key))}»</span>
        <span>статус / задержка</span>
      </div>
      <table class="host-table"><tbody></tbody></table></td>`;

    $('stratTbody').appendChild(tr);
    $('stratTbody').appendChild(detail);
    if (key === '__naked__' || key === '__current__') tr.classList.add('row-baseline');

    const toggleDetail = () => { detail.hidden = !detail.hidden; tr.setAttribute('aria-expanded', detail.hidden ? 'false' : 'true'); };
    tr.addEventListener('click', toggleDetail);
    tr.tabIndex = 0;
    tr.setAttribute('aria-expanded', 'false');
    tr.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleDetail(); }
    });

    r = {
      key, tr, detail,
      tbody: detail.querySelector('tbody'),
      stateDot: tr.querySelector('.dot'),
      stateText: tr.querySelector('.st-text'),
      rateCell: tr.children[2],
      discordCell: tr.children[3],
      ytCell: tr.children[4],
      hostsCell: tr.children[5],
      hosts: new Map(), ok: 0, total: 0, netOk: 0, netTotal: 0,
    };
    this.state.rows.set(key, r);
    return r;
  },

  _setCurrent(key) {
    this._rowFor(key);
    if (this.state.currentKey && this.state.currentKey !== key) {
      // Предыдущую стратегию закрываем честно: у «голого теста» отдельного
      // сигнала о финише нет - строка висела «тестируется…»
      const prevKey = this.state.currentKey;
      this._finishRow(prevKey);
      if (this._completedSeen) this._completedSeen.add(prevKey);
    }
    this.state.currentKey = key;
    const row = this.state.rows.get(key);
    row.tr.classList.add('is-current');
    row.stateDot.className = 'dot dot-warn';
    row.stateText.textContent = 'тестируется…';
    row.detail.hidden = false;
  },

  _finishRow(key) {
    const row = this.state.rows.get(key);
    if (!row) return;
    row.tr.classList.remove('is-current');
    const rate = (row.netTotal || row.total)
      ? (row.netTotal ? row.netOk / row.netTotal : row.ok / row.total) * 100 : 0;
    row.stateDot.className = 'dot ' + (rate >= SCORE_OK ? 'dot-ok' : rate >= SCORE_MID ? 'dot-warn' : 'dot-err');
    row.stateText.textContent = 'готово';
    row.tr.classList.remove('st-good', 'st-mid', 'st-bad');
    row.tr.classList.add(rate >= SCORE_OK ? 'st-good' : rate >= SCORE_MID ? 'st-mid' : 'st-bad');
    row.detail.hidden = true;
    if (this.state.currentKey === key) this.state.currentKey = null;
  },

  _addHostRow: (function (processFn, delayMs) {
    let queue = [], timer = null;
    const fn = function (item) {
      queue.push(item);
      if (!timer) timer = setTimeout(() => {
        const batch = queue; queue = []; timer = null;
        processFn(batch);
      }, delayMs);
    };
    // Полный сброс очереди (новый тест - старые отложенные строки не нужны).
    fn.resetQueue = function () {
      if (timer) { clearTimeout(timer); timer = null; }
      queue = [];
    };
    return fn;
  })(function (batch) { for (const b of batch) TesterPage._addHostImmediate(b); }, 90),

  _addHostImmediate(data) {
    const row = this._rowFor(data.profile);
    const mapKey = (data.domain || '') + '|' + (data.test_type || '');
    const isOk = data.status === 'OK' || data.status === 'OK_BLOCKED';
    const isPing = data.test_type === 'ping';
    // QUIC-класс (youtube и др.): TCP-проба сторонним клиентом под десинком
    // не показательная - нейтральный серый статус вместо красного креста.
    const isQuirk = !isPing && QUIRK_HOSTS.has(data.domain);
    const isQuicStatus = isQuirk && data.status === 'QUIC';
    // rated/control - бэкендовая категория: live-счётчики «Хосты» считаются
    // только по rated - иначе прыгают (17/17 → 8/8) на финальном network_rate
    const isRated = data.rated === undefined ? (!isPing && !isQuirk) : !!data.rated;
    let h = row.hosts.get(mapKey);
    const wasOk = h ? h.ok : false;
    if (!h) {
      h = { tr: document.createElement('tr'), ok: false };
      h.tr.innerHTML =
        '<td style="width:16px"></td>' +
        `<td class="h-domain" style="width:26%">${escapeHtml(data.domain || '?')}${data.cdn_provider ? `<span class="badge-cdn">${escapeHtml(data.cdn_provider)}</span>` : ''}</td>` +
        `<td style="width:9%" class="h-type"></td>` +
        `<td style="width:9%" class="h-code"></td>` +
        `<td style="width:9%" class="h-time"></td>` +
        '<td class="h-err"></td>';
      row.tbody.appendChild(h.tr);
      row.total++;
      if (!isPing && isRated) row.netTotal++;
    }
    h.ok = isOk;
    // считаем «доступность» и «хосты» вживую (сеть, без пингов - как финальный network_rate);
    // quirk-хосты не входят ни в rate, ни в счётчики
    if (isOk && !wasOk) { row.ok++; if (!isPing && isRated) row.netOk++; }
    if (!isOk && wasOk) { row.ok--; if (!isPing && isRated) row.netOk--; }
    row.hostsCell.innerHTML = row.netOk + '/' + row.netTotal +
      (row.total > row.netTotal
        ? ` <span class="meta">(${row.total})</span>` : '');
    if (row.netTotal) {
      const rate = row.netOk / row.netTotal * 100;
      row.rateCell.innerHTML = `<span class="${rateClass(rate)}">${rate.toFixed(0)}%</span>`;
    }
    h.tr.className = isOk ? 'hrow-ok'
      : data.status === 'QUIC' ? 'hrow-quirk'
      : isPing ? 'hrow-quirk'
      : (data.status === 'TIMEOUT' || data.status === 'BLOCKED' || data.status === 'FAIL'
        ? 'hrow-err' : 'hrow-warn');
    const stIcon = isOk ? '<span class="st-ok">✓</span>'
      : data.status === 'QUIC' ? '<span class="st-quirk">≈ QUIC</span>'
      : isPing ? '<span class="st-quirk">ping</span>'
      : data.status === 'TIMEOUT' || data.status === 'BLOCKED' || data.status === 'FAIL'
        ? '<span class="st-err">✗</span>'
        : '<span class="st-warn">•</span>';
    const cells = h.tr.children;
    cells[0].innerHTML = stIcon;
    cells[2].textContent = data.test_type || '';
    cells[3].textContent = data.status_code || (data.status === 'TCP16_20' || data.status === 'DPI_DROP' ? 'DPI' : '');
    cells[4].textContent = data.time_ms != null ? formatTime(data.time_ms) : '';
    cells[5].textContent = data.error || '';
    row.hosts.set(mapKey, h);
    if (data.domain === 'discord.com' || (data.domain === 'gateway.discord.gg' && !row._discord)) {
      row._discord = true;
      row.discordCell.innerHTML = isOk ? '<span class="st-ok">✓</span>' : '<span class="st-err">✗</span>';
    }
    if (data.domain === 'www.youtube.com' && !row._yt) {
      row._yt = true;
      row.ytCell.innerHTML = isOk ? '<span class="st-ok">✓</span>'
        : data.status === 'QUIC' ? '<span class="st-quirk">QUIC</span>'
        : '<span class="st-err">✗</span>';
    }
  },

  _handleProgressMessage(msg) {
    if (!msg) return;
    let m = msg.match(/^Голый тест: (\d+)\/(\d+) доступно$/);
    if (m) {
      const row = this.state.rows.get('__naked__');
      if (row) {
        const rate = +m[1] / +m[2] * 100;
        row.rateCell.innerHTML = `<span class="${rateClass(rate)}">${Math.round(rate)}%</span>`;
        row.hostsCell.textContent = m[1] + '/' + m[2];
      }
      this._finishRow('__naked__');
      return;
    }
    m = msg.match(/^Тестируем стратегию (.+?) \(\d+\/\d+\)\.\.\.$/) ||
            msg.match(/^Тестируем собранную стратегию (.+?)\.\.\.$/) ||
            msg.match(/^Голый тест.*$/);
    if (m) {
      const key = /^Голый/.test(msg) ? '__naked__' : m[1];
      this._setCurrent(key);
      $('testCurrentPhase').textContent = /^Голый/.test(msg)
        ? 'Базовый уровень: проверяем без защиты'
        : 'Тестирую стратегию: ' + key;
      return;
    }
    m = msg.match(/^Стратегия (.+?): (\d+(?:\.\d+)?)%$/) ||
        msg.match(/^Стратегия (.+?): не запустилась$/);
    if (m) {
      const row = this.state.rows.get(m[1]);
      if (row) {
        row.rateCell.innerHTML = m[2] !== undefined
          ? Math.round(+m[2]) + '%'
          : '<span class="st-err">0%</span>';
        row.tr.classList.add('st-bad');
      }
      this._finishRow(m[1]);
    }
  },

  // ── опрос тестера ──

  _startTesterAction(actionData, callbacks) {
    const { resultType, onResult, progressConfig, onError, onCancel, onIntermediate } = callbacks || {};
    const { startPercent = 0, scalePercent = 1, textTemplate = '' } = progressConfig || {};
    let known = this.state.knownResults = 0;
    this._completedSeen = new Set();
    let started = false;
    let pollActive = true;
    const actPage = { cdn_scan: 'cdn', asn_scan: 'asn' }[actionData.action] || 'tester';

    fetch('/api/tester/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(actionData),
    }).then(r => {
      if (!r.ok) throw Error('HTTP ' + r.status);
      started = true;
    }).catch(() => {
      pollActive = false;
      App.setTestActive(false);
      if (onError) onError();
    });

    const pollId = setInterval(() => {
      if (!pollActive) { clearInterval(pollId); return; }
      if (!started) return;
      apiGet('/tester/status').then(state => {
        if (!pollActive) return;
        if (state.cancelled) {
          frontendLog('poll: cancelled');
          pollActive = false; clearInterval(pollId);
          Activity.done('Отменено');
          $('testCurrentPhase').textContent = 'Тест отменён';
          this.clearElapsedTimer();
          setTimeout(() => this.resetToIntro('отменён пользователем'), 1300);
          return;
        }
        if (state.progress) {
          this._setProgress(startPercent + (state.progress.percent || 0) * scalePercent);
          Activity.set(actPage, state.progress.message || 'Выполняется…',
                       state.progress.percent, true);
          if (state.progress.message) {
            if (textTemplate) $('testProgressMsg').textContent = textTemplate.replace('{msg}', state.progress.message);
            this._handleProgressMessage(state.progress.message);
          }
        }
        const results = state.results || [];
        while (known < results.length) {
          const item = results[known++];
          if (!item) continue;
          const type = item.type || '';
          if (type === 'test_result' || (item.domain && item.status)) this._addHostRow(item);
          else if (type === 'intermediate') {
            if (onIntermediate) onIntermediate(item);
            else this.addTestLog((item.profile || '?') + (item.blob ? ' + ' + item.blob : '') +
              ' score=' + (item.success_rate != null ? item.success_rate.toFixed(0) : '?'));
          }
        }
        // Надёжное закрытие строк: сервер отдаёт список завершённых стратегий;
        // закрываем один раз на стратегию (повторный вызов сворачивал бы
        // раскрытые пользователем списки доменов)
        const seen = this._completedSeen || (this._completedSeen = new Set());
        for (const key of (state.completed || [])) {
          if (!seen.has(key)) {
            seen.add(key);
            this._finishRow(key);
          }
        }
        if (!state.running) {
          // финальная синхронизация: строка последней стратегии могла не
          // получить своё «Стратегия X: N%» (progress перезаписался) -
          // все «тестируется…» закрываем, иначе висят вечно
          for (const [k, row] of this.state.rows) {
            if (row.stateText && row.stateText.textContent === 'тестируется…') {
              this._finishRow(k);
            }
          }
          const fr = state.final_result;
          if (state.error) {
            frontendLog('poll: finished with error: ' + state.error);
            pollActive = false; clearInterval(pollId);
            Activity.fail('Ошибка: ' + state.error);
            this.clearElapsedTimer();
            $('testCurrentPhase').textContent = 'Ошибка: ' + state.error;
            showToast('Тест прерван: ' + state.error, 'error');
            setTimeout(() => this.resetToIntro('ошибка теста'), 2500);
            return;
          }
          if (!fr) {
            frontendLog('poll: finished WITHOUT result (known=' + known + ')');
            pollActive = false; clearInterval(pollId);
            Activity.fail('Тест завершился без результата');
            this.clearElapsedTimer();
            $('testCurrentPhase').textContent = 'Тест завершился без результата';
            showToast('Тест завершился без результата - запустите подбор заново', 'warn');
            setTimeout(() => this.resetToIntro('тест без результата'), 1800);
            return;
          }
          frontendLog('poll: finished OK (type=' + (fr.type || '?') + ')');
          pollActive = false; clearInterval(pollId);
          Activity.done('Готово');
          if (state.all_results && !fr.all_results) fr.all_results = state.all_results;
          if (fr.restored) showToast(fr.restored, /Не удалось|не восстановлен/.test(fr.restored) ? 'warn' : 'ok');
          if (resultType && fr.type === resultType) { if (onResult) onResult(fr); }
          else if (fr.type === 'current_result') { this.state.currentResults = fr; this.runFullPipelinePhase1(); }
          else if (fr.type === 'need_zapret1') {
            this.clearElapsedTimer();
            $('testRun').hidden = true;
            Modal.open('needZapret1Overlay');
            $('needZapret1Status').textContent = '';
          }
          else if (fr.type === 'check_result') { if (onResult) onResult(fr); }
          else if (fr.type === 'final') {
            this.state.fullAnalysisResults = fr.all_results || [];
            this._fillTable(this.state.fullAnalysisResults);
            this._finishAdvancedPhase4();
          }
          else if (onResult) onResult(fr);
        }
      }).catch(() => {
        if (pollActive && known === 0) {
          pollActive = false; clearInterval(pollId);
          if (onError) onError();
        }
        // Опрос умер - не держим блокировку «идёт тест» навсегда.
        if (pollActive) { pollActive = false; clearInterval(pollId); App.setTestActive(false); }
      });
    }, 350);
    return pollId;
  },

  // ── запуск ──

  startTest() {
    frontendLog('btn: Начать подбор (extended=' + $('extendedCheck').checked + ')');
    this.state.advancedTest = $('extendedCheck').checked;
    this.state.collectLogs = $('logCheck').checked;
    this.resetAllState();
    this.runVpnCheck();
  },

  resetAllState() {
    Object.assign(this.state, {
      currentResults: null, nakedResults: null, phase2Results: null,
      fullAnalysisResults: null, collectFormData: null, collectBatFile: null,
    });
    $('testLog').innerHTML = '';
    $('testSummary').hidden = true;
    $('testSummary').innerHTML = '';
    this._resetTable();
  },

  runVpnCheck() {
    const pollId = this._startTesterAction({ action: 'check_vpn' }, {
      onResult: (final) => {
        clearInterval(pollId);
        this.state.vpnActive = !!final.vpn_active;
        if (final.vpn_active) {
          $('vpnDetails').textContent = final.details || '';
          $('testRun').hidden = true;
          Modal.open('vpnOverlay');
          $('vpnStatus').textContent = '';
        } else {
          this.runPipeline();
        }
      },
      onError: () => this.runPipeline(),
    });
  },

  runPipeline() {
    App.setTestActive(true);
    Modal.close('vpnOverlay');
    $('testerIntro').hidden = true;
    $('testRun').hidden = false;
    $('testCurrentPhase').textContent = 'Подготовка…';
    this._setProgress(0);
    $('testProgressMsg').textContent = '';
    $('btnStartTest').disabled = true;
    // Скелетон: строки известных участников видны сразу («в очереди»),
    // таблица не выглядит замершей до первых результатов.
    const planned = this.state.advancedTest
      ? ['__current__', '__naked__', ...PROFILES]
      : ['__naked__', ...PROFILES];
    planned.forEach(p => this._rowFor(p));
    this.startElapsedTimer();
    if (this.state.advancedTest) this.runFullPipelinePhase0();
    else this.runBasicPhase2();
  },

  _setProgress(pct) {
    const fill = $('testProgressFill');
    const v = Math.min(100, Math.max(0, pct));
    fill.style.width = v + '%';
    fill.setAttribute('aria-valuenow', v);
    // Кот на краю заливки имеет смысл только когда заливка уже видна.
    fill.parentElement.classList.toggle('has-cat', pct >= 5);
  },

  runBasicPhase2() {
    $('testCurrentPhase').textContent = 'Стратегии тестируются по очереди';
    this._startTesterAction(
      { action: 'test_profiles', profiles: PROFILES,
        alt_params: !!($('altParamsCheck') && $('altParamsCheck').checked) },
      {
        progressConfig: { startPercent: 0, scalePercent: 1, textTemplate: '{msg}' },
        onResult: (d) => {
          this.state.phase2Results = d;
          this._fillTable(d.all_results || []);
          this.finalizePipeline('basic');
        },
        onError: () => { $('testCurrentPhase').textContent = 'Ошибка теста'; this.clearElapsedTimer(); },
      });
  },

  runFullPipelinePhase0() {
    $('testCurrentPhase').textContent = 'Фаза 1 из 4: текущий Zapret 1';
    this._startTesterAction({ action: 'current' }, {
      progressConfig: { startPercent: 0, scalePercent: 0.08 },
      onError: () => { $('testCurrentPhase').textContent = 'Ошибка (Zapret 1)'; this.clearElapsedTimer(); },
    });
  },

  runFullPipelinePhase1() {
    $('testCurrentPhase').textContent = 'Фаза 2 из 4: базовый уровень без защиты';
    this._startTesterAction({ action: 'naked' }, {
      resultType: 'naked_result',
      progressConfig: { startPercent: 8, scalePercent: 0.07 },
      onResult: (d) => {
        this.state.nakedResults = d;
        const row = this.state.rows.get('__naked__');
        if (row) {
          const rate = d.network_rate || 0;
          row.rateCell.innerHTML = `<span class="${rateClass(rate)}">${rate.toFixed(0)}%</span>`;
          row.hostsCell.textContent = (d.net_ok_count != null ? d.net_ok_count : 0) + '/' + (d.net_total != null ? d.net_total : 0);
        }
        this._finishRow('__naked__');
        this.runFullPipelinePhase2();
      },
      onError: () => { $('testCurrentPhase').textContent = 'Ошибка (naked)'; this.clearElapsedTimer(); },
    });
  },

  runFullPipelinePhase2() {
    $('testCurrentPhase').textContent = 'Фаза 3 из 4: стратегии Zapret 2';
    this._startTesterAction(
      { action: 'test_profiles', profiles: PROFILES,
        alt_params: !!($('altParamsCheck') && $('altParamsCheck').checked) },
      {
        resultType: 'result',
        progressConfig: { startPercent: 15, scalePercent: 0.1 },
        onResult: (d) => {
          this.state.phase2Results = d;
          this._fillTable(d.all_results || []);
          this.runFullPipelinePhase3();
        },
        onError: () => { $('testCurrentPhase').textContent = 'Ошибка теста'; this.clearElapsedTimer(); },
      });
  },

  runFullPipelinePhase3() {
    if (!PROFILES.length) {
      $('testCurrentPhase').textContent = 'Нет профилей для анализа';
      this.clearElapsedTimer();
      this.finalizePipeline('full');
      return;
    }
    $('testCurrentPhase').textContent = 'Фаза 4 из 4: полный анализ комбинаций';
    this._startTesterAction({ action: 'full_analysis', profiles: PROFILES }, {
      progressConfig: { startPercent: 25, scalePercent: 0.35 },
      onError: () => { $('testCurrentPhase').textContent = 'Ошибка анализа'; this.clearElapsedTimer(); },
    });
  },

  _finishAdvancedPhase4() {
    this._setProgress(95);
    this.finalizePipeline('full');
  },

  // ── заполнение таблицы финальными числами ──

  _markUntested() {
    // Скелетон-строки, до которых прогон не дошёл (например «custom» не
    // собралась) - переводим из «в очереди» в честное «-».
    for (const row of this.state.rows.values()) {
      if (row.stateText && row.stateText.textContent === 'в очереди') {
        row.stateText.textContent = '-';
        row.stateDot.className = 'dot dot-idle';
      }
    }
  },

  _fillTable(allResults) {
    for (const r of allResults) {
      const key = r.profile || '';
      const row = this._rowFor(key);
      const rate = r.network_rate != null ? r.network_rate : (r.success_rate || 0);
      row.rateCell.innerHTML = `<span class="${rateClass(rate)}">${rate.toFixed(0)}%</span>`;
      if (r.net_ok_count != null) row.hostsCell.textContent = r.net_ok_count + '/' + r.net_total;
      const statusOf = (domains) => {
        const found = (r.results || []).filter(x => domains.includes(x.domain) && x.test_type !== 'ping');
        if (!found.length) return '-';
        return found.some(x => x.status === 'OK' || x.status === 'OK_BLOCKED')
          ? '<span class="st-ok">✓</span>' : '<span class="st-err">✗</span>';
      };
      row.discordCell.innerHTML = statusOf(['discord.com', 'gateway.discord.gg']);
      row.ytCell.innerHTML = statusOf(['www.youtube.com', 'youtu.be', 'i.ytimg.com']);
      row.stateDot.className = 'dot ' + (rate >= SCORE_OK ? 'dot-ok' : rate >= SCORE_MID ? 'dot-warn' : 'dot-err');
      row.stateText.textContent = 'готово';
      row.tr.classList.remove('is-current');
      row.tr.classList.remove('st-good', 'st-mid', 'st-bad');
      row.tr.classList.add(rate >= SCORE_OK ? 'st-good' : rate >= SCORE_MID ? 'st-mid' : 'st-bad');
    }
    const rec = this.state.phase2Results && this.state.phase2Results.recommendation;
    if (rec && rec.best_profile) {
      const best = this.state.rows.get(rec.best_profile);
      if (best) best.tr.classList.add('is-best');
    }
  },

  // ── финал ──

  finalizePipeline(mode) {
    App.setTestActive(false);
    this.clearElapsedTimer();
    this._setProgress(100);
    $('testCurrentPhase').textContent = 'Готово';
    $('btnStartTest').disabled = false;
    $('testRun').hidden = true;
    this._markUntested();

    const el = $('testSummary');
    let html = '';

    if (mode === 'basic') {
      const p2 = this.state.phase2Results || {};
      const rec = p2.recommendation;
      const custom = p2.custom;
      const naked = p2.naked;

      if (rec) html += this._renderVerdict(rec);
      else html += '<div class="detail-section"><span class="detail-head st-warn">Итог не определён</span><p class="detail-text">Нет результатов - запустите подбор заново.</p></div>';

      if (custom && custom.summary) {
        const rel = custom.relation === 'better' ? '- обгоняет лучшую'
          : custom.relation === 'worse' ? '- уступает лучшей'
          : custom.relation === 'equal' ? '- равна лучшей' : '';
        const rateTxt = custom.rate != null ? ` (${custom.rate}%)` : '';
        html += `<div class="detail-section">
          <span class="detail-head">Личная стратегия «custom»</span>
          <p class="detail-text">${escapeHtml(custom.summary)}${rel ? ' ' + rel : ''}${rateTxt}.
          ${custom.valid
            ? 'Если «custom» помечена лучшей в таблице - запускайте её кнопкой выше.'
            : 'Не прошла проверку движком - запускать её не стоит.'}
          ${custom.error && !custom.valid ? `<span class="st-err">${escapeHtml(custom.error)}</span>` : ''}</p>
        </div>`;
      } else if (custom && custom.error) {
        html += `<div class="detail-section">
          <span class="detail-head st-err">Личная стратегия не собрана</span>
          <p class="detail-text st-err">${escapeHtml(custom.error)}</p>
        </div>`;
      }

      if (naked && naked.net_total) {
        html += `<div class="detail-section">
          <span class="detail-head">Базовый уровень (без защиты): <span class="${rateClass(naked.network_rate || 0)}">${(naked.network_rate || 0).toFixed(0)}%</span></span>
          <p class="detail-text">Столько сервисов доступно вообще без Zapret. Столбец «Без защиты» в таблице - точка отсчёта.</p>
        </div>`;
      }

      if (rec && rec.blocked_domains && rec.blocked_domains.length && rec.verdict !== 'ok') {
        html += `<div class="detail-section" style="background: var(--err-bg); border-color: var(--err-line);">
          <span class="detail-head" style="color: #f0b7b8;">Не пробито ни одной стратегией (${rec.blocked_domains.length} хост${rec.blocked_domains.length > 1 ? 'а' : ''})</span>
          <p class="detail-text" style="color: #f0c6c6;">Если это ваши рабочие домены - добавьте их в «Списки → Домены - обрабатывать».</p>
          <div class="chip-list">${rec.blocked_domains.map(d => `<span class="fail-domain">${escapeHtml(d)}</span>`).join('')}</div>
        </div>`;
      }
    } else {
      const cur = this.state.currentResults;
      const naked = this.state.nakedResults;
      const fa = this.state.fullAnalysisResults || [];
      const rateOf = r => (r.network_rate != null ? r.network_rate : (r.success_rate || 0));
      const best = fa.length ? fa.reduce((a, b) => rateOf(a) > rateOf(b) ? a : b) : null;
      html += `<div class="detail-section">
        <span class="detail-head">Сравнение</span>
        <table class="check-table"><tbody>
          <tr><td class="check-name">Zapret 1 (текущий)</td><td class="mono">${cur ? rateOf(cur).toFixed(0) + '%' : '-'}</td></tr>
          <tr><td class="check-name">Без защиты</td><td class="mono">${naked ? rateOf(naked).toFixed(0) + '%' : '-'}</td></tr>
          <tr><td class="check-name">Zapret 2, лучшая${best ? ' («' + escapeHtml(best.profile || '') + (best.blob ? ' + ' + escapeHtml(best.blob) : '') + '»)' : ''}</td>
              <td class="mono ${best ? rateClass(rateOf(best)) : ''}">${best ? rateOf(best).toFixed(0) + '%' : '-'}</td></tr>
        </tbody></table>
        <p class="detail-text">Подробности каждой комбинации - в таблице стратегий (клик по строке).</p>
      </div>`;
    }

    if (this.state.collectLogs) {
      html += `<div class="detail-section" style="display:flex;gap:12px;align-items:center">
        <button class="btn btn-primary" id="btnShowCollect">Сохранить отчёт для поддержки</button>
        <span class="meta">ZIP с результатами теста сохранится в папку программы</span>
      </div>`;
    }
    html += `<div class="results-actions"><button class="btn" id="btnBackToIntro">Новый подбор</button></div>`;

    el.innerHTML = html;
    el.hidden = false;
    if ($('btnShowCollect')) $('btnShowCollect').addEventListener('click', () => this.showCollectForm());
    $('btnBackToIntro').addEventListener('click', () => this.resetToIntro('кнопка назад'));
    const recBtn = $('btnApplyRec');
    const bestProfile = (mode === 'basic' && rec && rec.best_profile) ? rec.best_profile : null;
    if (recBtn && bestProfile) {
      recBtn.addEventListener('click', () => MainPage.applyStrategy(bestProfile));
    }
  },

  _renderVerdict(rec) {
    const vm = {
      ok: ['Обход работает', 'badge-ok'],
      partial: ['Частичный обход', 'badge-warn'],
      no_bypass: ['Обход не сработал', 'badge-err'],
      engine_broken: ['Проблема с движком Zapret', 'badge-err'],
      no_data: ['Нет данных', 'badge-mute'],
    };
    const [title, badgeCls] = vm[rec.verdict] || vm.no_data;
    const isBad = rec.verdict === 'no_bypass' || rec.verdict === 'engine_broken';
    let subtitle = escapeHtml(rec.message || '');
    let chips = '';
    if (rec.key_hosts && rec.key_hosts.length) {
      const okN = rec.key_hosts.filter(k => k.status === 'OK' || k.status === 'QUIC_OK').length;
      if (!subtitle) subtitle = `Успешно пробито <b>${okN} из ${rec.key_hosts.length}</b> ключевых сервисов.`;
      chips = '<div class="services-grid">' + rec.key_hosts.map(k => {
        const ok = k.status === 'OK' || k.status === 'QUIC_OK';
        const quic = k.status === 'QUIC_OK';
        return `<div class="service-chip">
          <div class="chip-head"><span class="${ok ? 'mark-ok' : 'mark-bad'}">${ok ? '✓' : '✗'}</span> ${escapeHtml(k.label)}${quic ? ' <span class="st-quirk">QUIC</span>' : ''}</div>
          <div class="chip-ping ${ok ? '' : 'chip-ping-bad'}">${k.time_ms ? formatTime(k.time_ms) : (ok ? 'доступен' : 'не пробит')}</div>
          ${k.note ? `<div class="chip-note">${escapeHtml(k.note)}</div>` : ''}
        </div>`;
      }).join('') + '</div>';
    }
    let actions = '';
    if (isBad) {
      actions = `<button class="btn btn-primary hero-btn" onclick="location.hash='diagnostics'">Открыть проверку системы</button>
        ${rec.best_profile ? '<span class="meta">лучшая из протестированных: ' + escapeHtml(rec.best_profile) + '</span>' : ''}`;
    } else if (rec.best_profile) {
      actions = `<button class="btn btn-primary hero-btn" id="btnApplyRec">Запустить: ${escapeHtml(rec.best_profile)}
        (${(rec.best_network_rate || 0).toFixed(0)}%)</button>`;
    }
    if (rec.same_as_naked) {
      actions += '<span class="meta">результат как без защиты - обход не применяется</span>';
    }
    const badgeExtra = rec.best_network_rate != null && rec.verdict !== 'no_data'
      ? ' · ' + rec.best_network_rate.toFixed(0) + '% успеха' : '';
    return `<div class="verdict-hero">
      <div class="verdict-top">
        <div>
          <span class="verdict-badge ${badgeCls}">${escapeHtml(title)}${badgeExtra}</span>
          <div class="verdict-title">${isBad
            ? escapeHtml(title)
            : (rec.best_profile ? 'Рекомендована стратегия «' + escapeHtml(rec.best_profile) + '»' : escapeHtml(title))}</div>
          ${subtitle ? `<div class="verdict-subtitle">${subtitle}</div>` : ''}
        </div>
      </div>
      ${chips}
      ${rec.top3 && rec.top3.length > 1 ? `<div class="detail-section">
        <span class="detail-head">Топ стратегий</span>
        <p class="detail-text">${rec.top3.map((t, i) =>
          `${i + 1}. <b>${escapeHtml(t.name)}</b> - ${t.rate.toFixed(0)}% (${t.net_ok}/${t.net_total})`
        ).join('<br>')}<br><span class="st-quirk">разница в пределах ±1 домена - погрешность прогона, стратегии практически равнозначны</span></p>
      </div>` : ''}
      <div class="verdict-actions">${actions}</div>
    </div>`;
  },

  bindModals() {
    $('vpnCancelBtn').addEventListener('click', () => {
      Modal.close('vpnOverlay');
      this.resetToIntro();
    });
    $('retryVpnBtn').addEventListener('click', () => {
      Modal.close('vpnOverlay');
      $('testRun').hidden = false;
      $('vpnStatus').textContent = 'Проверяю…';
      this.runVpnCheck();
    });
    $('vpnSkipBtn').addEventListener('click', () => {
      this.state.vpnActive = true;
      $('testRun').hidden = false;
      this.runPipeline();
    });
    $('needZ1CancelBtn').addEventListener('click', () => {
      Modal.close('needZapret1Overlay');
      this.resetToIntro();
    });
    $('checkZapret1Btn').addEventListener('click', () => {
      $('needZapret1Status').textContent = 'Проверка…';
      $('checkZapret1Btn').disabled = true;
      this._startTesterAction({ action: 'check-winws' }, {
        onResult: (d) => {
          $('checkZapret1Btn').disabled = false;
          if (d.running) {
            Modal.close('needZapret1Overlay');
            $('testRun').hidden = false;
            this.runFullPipelinePhase0();
          } else {
            $('needZapret1Status').textContent = 'winws.exe всё ещё не найден - запустите батник Zapret 1.';
          }
        },
        onError: () => {
          $('checkZapret1Btn').disabled = false;
          $('needZapret1Status').textContent = 'Ошибка связи';
        },
      });
    });
    $('collectClose').addEventListener('click', () => this.closeCollectForm());
    $('collectCancelBtn').addEventListener('click', () => this.closeCollectForm());
    $('collectSubmitBtn').addEventListener('click', () => this.saveReport());
    $('collectBatZone').addEventListener('click', () => $('collectBatInput').click());
    $('collectBatInput').addEventListener('change', (e) => this.handleCollectBat(e));
    const dz = $('collectBatZone');
    dz.addEventListener('dragover', e => e.preventDefault());
    dz.addEventListener('drop', (e) => { e.preventDefault(); this.handleCollectDrop(e); });

    // Escape и клик по фону закрывают модалки (как «Отмена»).
    const closeModal = (id, onCancel) => {
      const ov = $(id);
      ov.addEventListener('mousedown', (e) => {
        if (e.target === ov) onCancel();
      });
    };
    closeModal('vpnOverlay', () => $('vpnCancelBtn').click());
    closeModal('needZapret1Overlay', () => $('needZ1CancelBtn').click());
    closeModal('collectFormOverlay', () => this.closeCollectForm());
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      if ($('collectFormOverlay').classList.contains('open')) this.closeCollectForm();
      else if ($('vpnOverlay').classList.contains('open')) $('vpnCancelBtn').click();
      else if ($('needZapret1Overlay').classList.contains('open')) $('needZ1CancelBtn').click();
    });
  },

  cancelTest() {
    frontendLog('btn: Отменить тест');
    fetch('/api/tester/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'cancel' }),
    }).catch(() => {});
    $('testCurrentPhase').textContent = 'Отмена…';
  },

  resetToIntro(reason) {
    frontendLog('resetToIntro: ' + (reason || 'без причины (кнопка)'));
    App.setTestActive(false);
    this.clearElapsedTimer();
    $('testRun').hidden = true;
    $('testSummary').hidden = true;
    $('testerIntro').hidden = false;
    $('btnStartTest').disabled = false;
    if (this._diagDoneRecently()) $('diagDoneNote').hidden = false;
  },

  // ── сбор отчёта ──

  showCollectForm() {
    $('collectCity').value = '';
    $('collectIsp').value = '';
    $('collectBatLabel').textContent = 'Файл стратегии Zapret 1 (.bat) - по желанию';
    $('collectBatZone').classList.remove('filed');
    $('collectConsent').checked = false;
    $('collectSubmitBtn').disabled = false;
    $('collectSubmitBtn').textContent = 'Сохранить отчёт';
    this.state.collectBatFile = null;
    Modal.open('collectFormOverlay');
  },

  closeCollectForm() { Modal.close('collectFormOverlay'); },

  handleCollectBat(e) { this._setCollectFile(e.target.files[0]); },
  handleCollectDrop(e) { this._setCollectFile(e.dataTransfer.files[0]); },
  _setCollectFile(f) {
    if (!f) return;
    this.state.collectBatFile = f;
    $('collectBatLabel').textContent = '✓ ' + f.name;
    $('collectBatZone').classList.add('filed');
  },

  async saveReport() {
    const consent = $('collectConsent').checked;
    if (!consent) { showToast('Отметьте согласие на сбор данных', 'warn'); return; }
    $('collectSubmitBtn').disabled = true;
    $('collectSubmitBtn').textContent = 'Сохранение…';

    const cur = this.state.currentResults;
    const naked = this.state.nakedResults;
    const phase2 = this.state.phase2Results;
    const slim = r => r ? {
      ok_count: r.ok_count, fail_count: r.fail_count, success_rate: r.success_rate,
      total_time_ms: r.total_time_ms, results: r.results,
    } : null;

    const body = {
      consent,
      city: $('collectCity').value.trim(),
      isp: $('collectIsp').value.trim(),
      vpn_active: this.state.vpnActive || false,
      zapret1_strategy: '',
      zapret1_cmdline: (cur && cur.zapret1_cmdline) || '',
      phase0_results: cur ? slim(cur) : { skipped: true },
      phase1_results: naked ? slim(naked) : null,
      phase2_results: phase2 ? Object.assign(slim(phase2) || {}, { all_results: phase2.all_results || [] }) : null,
      mode: this.state.advancedTest ? 'full' : 'basic',
    };
    if (this.state.collectBatFile) {
      try {
        body.zapret1_strategy = await this.fileToBase64(this.state.collectBatFile);
        body.zapret1_filename = this.state.collectBatFile.name;
      } catch (e) { /* ignore */ }
    }

    try {
      const r = await apiPost('/export-report', body);
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      try { await apiPost('/stop', {}); } catch (e) { /* ignore */ }
      this.closeCollectForm();
      const fileName = (r.file || '').split('\\').pop() || 'report.zip';
      $('testSummary').insertAdjacentHTML('beforeend',
        `<div class="notice notice-info">Отчёт сохранён: <b class="mono">${escapeHtml(fileName)}</b> в папке программы.</div>`);
      showToast('Отчёт сохранён', 'ok');
    } catch (e) {
      showToast('Ошибка сохранения отчёта: ' + e.message, 'error');
      $('collectSubmitBtn').disabled = false;
      $('collectSubmitBtn').textContent = 'Сохранить отчёт';
    }
  },

  fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  },

  addTestLog(msg) {
    const el = $('testLog');
    const ts = new Date().toLocaleTimeString();
    const div = document.createElement('div');
    div.className = 'test-log-entry';
    div.innerHTML = `<span class="ts">${ts}</span>` + escapeHtml(msg);
    el.appendChild(div);
    el.scrollTop = el.scrollHeight;
  },

  startElapsedTimer() {
    this.clearElapsedTimer();
    this.state.testStartTime = Date.now();
    this.state.elapsedInterval = setInterval(() => {
      const s = Math.floor((Date.now() - this.state.testStartTime) / 1000);
      $('testElapsed').textContent =
        String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    }, 1000);
  },

  clearElapsedTimer() {
    if (this.state.elapsedInterval) {
      clearInterval(this.state.elapsedInterval);
      this.state.elapsedInterval = null;
    }
  },

  // ── Анализ процесса (game/app network probe) ──────────────
  _probePollTimer: null,
  _probeStarting: false,
  _probeStartAt: 0,
  _probeDuration: 60,
  _probeTimer: null,
  _probeScanned: false,
  _probeProcesses: [],

  _setProbeState(text, cls) {
    const chip = $('probeState');
    if (!chip) return;
    const dot = chip.querySelector('.dot');
    const txt = chip.querySelector('.state-text');
    const map = { idle: ['dot-idle', 'st-mute'], live: ['dot-ok', 'st-ok'], done: ['dot-ok', 'st-ok'], err: ['dot-err', 'st-err'] };
    const [dc, tc] = map[cls] || map.idle;
    dot.className = 'dot ' + dc;
    txt.className = 'state-text ' + tc;
    txt.textContent = text;
  },

  async scanProbeProcesses(quiet) {
    if (quiet && this._probeScanned) return;
    const btn = $('probeScanBtn');
    const statusEl = $('probeStatus');
    if (statusEl) { statusEl.hidden = false; statusEl.textContent = 'Сканирование процессов…'; statusEl.className = 'probe-status'; }
    if (btn) btn.disabled = true;
    try {
      const r = await apiPost('/process-probe/scan', {});
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      const sel = $('probeProcSelect');
      sel.innerHTML = '<option value="">- выберите процесс -</option>';
      const groups = {};
      for (const p of (r.processes || [])) {
        if (!groups[p.name]) groups[p.name] = { count: 0, title: p.title || '' };
        groups[p.name].count++;
        if (!groups[p.name].title && p.title) groups[p.name].title = p.title;
      }
      for (const name of Object.keys(groups).sort()) {
        const g = groups[name];
        const suffix = g.count > 1 ? ` (${g.count} процесса)` : '';
        const title = g.title ? ` - ${g.title}` : '';
        const o = document.createElement('option');
        o.value = name;
        o.textContent = name + suffix + title;
        sel.appendChild(o);
      }
      const total = (r.processes || []).length;
      this._probeScanned = true;
      this._probeProcesses = r.processes || [];
      if (statusEl) { statusEl.textContent = `Найдено процессов: ${total}`; statusEl.className = 'probe-status'; }
      if (!quiet) showToast(`Найдено процессов: ${total}`, 'ok');
      this._hintProbeProcess();
    } catch (e) {
      if (statusEl) { statusEl.textContent = 'Ошибка: ' + (e.message || e); statusEl.className = 'probe-status st-err'; }
      if (!quiet) showToast('Сканирование: ' + (e.message || e), 'error');
    }
    if (btn) btn.disabled = false;
  },

  _probeTick() {
    const el = $('probeLiveTimer');
    if (!el) return;
    const s = Math.floor((Date.now() - this._probeStartAt) / 1000);
    const mm = String(Math.floor(s / 60)).padStart(2, '0');
    const ss = String(s % 60).padStart(2, '0');
    // total в mm:ss (L6: 120 сек писалось как «00:120»)
    const totalMm = String(Math.floor(this._probeDuration / 60)).padStart(2, '0');
    const totalSs = String(this._probeDuration % 60).padStart(2, '0');
    el.textContent = `${mm}:${ss} / ${totalMm}:${totalSs}`;
  },

  // Живая подсказка по ручному вводу процесса: имя/PID из отсканированного
  // списка, ближайшие совпадения по имени, режим ожидания для ещё не запущенных.
  _hintProbeProcess() {
    const box = $('probeProcHint');
    const input = $('probeProcInput');
    if (!box || !input) return;
    const v = (input.value || '').trim();
    if (!v) { box.hidden = true; return; }
    const list = this._probeProcesses || [];
    box.hidden = false;
    box.innerHTML = '';
    const esc = escapeHtml;
    const add = (cls, html) => { box.insertAdjacentHTML('beforeend', `<span class="${cls}">${html}</span>`); };
    const norm = s => s.toLowerCase().replace(/\.exe$/, '');

    if (/^\d+$/.test(v)) {
      const pid = parseInt(v, 10);
      const hit = list.find(p => p.pid === pid);
      if (hit) {
        add('pp-hint-ok', `✓ PID ${pid} - ${esc(hit.name)}${hit.title ? ' · ' + esc(hit.title) : ''}`);
      } else {
        add('pp-hint-err', `PID ${pid} не найден среди процессов с сетью - если процесс ещё не запущен, анализатор дождётся его`);
      }
      return;
    }

    const vn = norm(v);
    const exact = list.filter(p => norm(p.name) === vn);
    if (exact.length) {
      const names = [...new Set(exact.map(p => p.name))];
      add('pp-hint-ok', `✓ найден: ${esc(names.join(', '))} - ${exact.length} процесс${exact.length > 1 ? 'а' : ''} с сетью`);
      return;
    }

    const subs = [...new Set(list.map(p => norm(p.name)).filter(n => n.includes(vn)))].slice(0, 4);
    if (subs.length) {
      add('pp-hint-warn', 'Возможно, вы имели в виду: ');
      subs.forEach(n => {
        const b = document.createElement('span');
        b.className = 'pp-sugg';
        b.textContent = n;
        b.addEventListener('click', () => {
          $('probeProcInput').value = n;
          this._hintProbeProcess();
        });
        box.appendChild(b);
      });
      return;
    }

    if (!list.length) add('pp-hint-mute', 'Список процессов ещё не загружен - нажмите «Сканировать»');
    else add('pp-hint-err', 'не найден в списке - без активных соединений или ещё не запущен (анализатор дождётся его)');
  },

  async startProbe() {
    if (this._probePollTimer || this._probeStarting) return;
    this._probeStarting = true;
    const btn = $('probeStartBtn');
    btn.disabled = true;
    const process = ($('probeProcInput').value || '').trim()
      || ($('probeProcSelect').value || '').trim();
    if (!process) {
      showToast('Впишите имя процесса или PID', 'error');
      btn.disabled = false;
      this._probeStarting = false;
      return;
    }
    const duration = $('probeDurSelect').value || 60;
    try {
      const r = await apiPost('/process-probe/start', { process, duration });
      if (r.status !== 'ok') {
        showToast('Анализ: ' + (r.message || 'ошибка'), 'error');
        btn.disabled = false;
        return;
      }
      $('probeStopBtn').hidden = false;
      $('probeStartBtn').hidden = true;
      $('probeReportBtn').hidden = true;
      $('probeResults').hidden = true;
      $('probeResults').innerHTML = '';
      $('probeIdle').hidden = true;
      $('probeLive').hidden = false;
      $('probeVerdict').hidden = true;
      $('probeTbody').innerHTML = '<tr><td colspan="4"><div class="empty-note">Наблюдение…</div></td></tr>';
      $('probeLiveTitle').textContent = `Прослушивание сетевого трафика процесса «${process}»`;
      $('probeLiveSub').textContent = 'Пакетов: 0 · Соединений: 0';
      this._probeStartAt = Date.now();
      this._probeDuration = +duration;
      this._probeTick();
      if (this._probeTimer) clearInterval(this._probeTimer);
      this._probeTimer = setInterval(() => this._probeTick(), 1000);
      this._setProbeState('● Перехват пакетов', 'live');
      this._probePollTimer = setInterval(() => this.pollProbe(), 2000);
      this.pollProbe();
    } finally {
      this._probeStarting = false;
    }
  },

  async pollProbe() {
    let r;
    try {
      r = await apiGet('/process-probe/status');
    } catch (e) {
      this._stopProbePolling();
      return;
    }
    if (r.status !== 'ok') {
      this._stopProbePolling();
      return;
    }
    const st = r.state || {};
    const stEl = $('probeStatus');
    if (st.error) {
      if (stEl) { stEl.hidden = false; stEl.textContent = st.error; stEl.className = 'probe-status st-err'; }
      this._setProbeState('Ошибка анализа', 'err');
    } else if (st.phase && stEl) {
      stEl.hidden = false;
      stEl.textContent = st.phase;
      stEl.className = 'probe-status';
    }
    this.renderProbe(st);
    if (st.phase === 'завершено' || st.error) {
      this._stopProbePolling();
      if (this._probeTimer) { clearInterval(this._probeTimer); this._probeTimer = null; }
      $('probeStartBtn').disabled = false;
      $('probeStartBtn').hidden = false;
      $('probeStopBtn').hidden = true;
      $('probeReportBtn').hidden = false;
      this._setProbeState(st.error ? 'Анализ прерван' : '✓ Анализ завершён', st.error ? 'err' : 'done');
      if (st.error) showToast('Анализ: ' + st.error, 'error');
    }
  },

  _stopProbePolling() {
    if (this._probePollTimer) {
      clearInterval(this._probePollTimer);
      this._probePollTimer = null;
    }
  },

  async stopProbe() {
    await apiPost('/process-probe/stop', {});
    this._stopProbePolling();
    if (this._probeTimer) { clearInterval(this._probeTimer); this._probeTimer = null; }
    $('probeStartBtn').disabled = false;
    $('probeStartBtn').hidden = false;
    $('probeStopBtn').hidden = true;
    $('probeReportBtn').hidden = false;
    this._setProbeState('Анализ остановлен', 'done');
  },

  async saveProbeReport() {
    const r = await apiPost('/process-probe/report', {});
    if (r.status === 'ok' && r.report) {
      const el = $('probeResults');
      el.hidden = false;
      el.innerHTML = '<pre class="probe-report">' + escapeHtml(r.report) + '</pre>';
      showToast('Отчёт сохранён: ' + r.path, 'ok');
    } else {
      showToast('Не удалось сохранить отчёт', 'error');
    }
  },

  renderProbe(st) {
    // История за окно наблюдения (сервер копит её снимками каждые 2с):
    // показываем итог по каждой цели, включая те, что так и не подключились
    const box = $('probeTbody');
    if (!box) return;
    const hist = st.history || {};
    const dns = st.dns || {};
    const dnsName = (ip) => (dns[ip] ? ` <span class="endpoint-dns">→ ${escapeHtml(dns[ip][0])}</span>` : '');
    const rowsData = Object.entries(hist).map(([k, h]) => {
      const idx = k.lastIndexOf(':');
      const ip = k.slice(0, idx), port = k.slice(idx + 1);
      const states = h.states || {};
      let status, cls, metric, sev;
      if (h.proto === 'tcp') {
        if ('SynSent' in states && !('Established' in states)) { status = 'Нет ответа (SYN)'; cls = 'syn-sent'; sev = 0; }
        else if ('Established' in states) { status = 'Установлено'; cls = 'established'; sev = 2; }
        else if ('CloseWait' in states) { status = 'Сервер закрыл'; cls = 'neutral'; sev = 1; }
        else { status = h.state || '-'; cls = 'neutral'; sev = 1; }
        metric = `снимков ${h.snapshots || 0}`;
      } else {
        const s = h.sent || 0, r = h.recv || 0;
        if (s > 0 && r === 0) { status = 'Нет ответа (UDP)'; cls = 'syn-sent'; sev = 0; }
        else if (r > 0) { status = 'Диалог'; cls = 'established'; sev = 2; }
        else { status = 'UDP'; cls = 'neutral'; sev = 1; }
        metric = (s || r) ? `${s}→${r}` : `снимков ${h.snapshots || 0}`;
      }
      return { k, ip, port, status, cls, metric, sev, proto: h.proto };
    }).sort((a, b) => a.sev - b.sev || a.k.localeCompare(b.k));
    let rows = '';
    for (const r of rowsData) {
      rows += `<tr>
        <td><span class="proto-badge ${r.proto === 'udp' ? 'udp' : ''}">${r.proto === 'udp' ? 'UDP' : 'TCP'}</span></td>
        <td><span class="endpoint-ip">${escapeHtml(r.ip)}</span><span class="endpoint-dns">:${escapeHtml(r.port)}</span>${dnsName(r.ip)}</td>
        <td><span class="state-badge ${r.cls}"><span class="sdot"></span>${escapeHtml(r.status)}</span></td>
        <td style="text-align:center"><span class="packets-count">${escapeHtml(r.metric)}</span></td>
      </tr>`;
    }
    box.innerHTML = rows || '<tr><td colspan="4"><div class="empty-note">Наблюдение…</div></td></tr>';
    const sub = $('probeLiveSub');
    if (sub) {
      const cap = st.udp_capture || {};
      let txt = `Целей: ${rowsData.length}`;
      if (cap.sent || cap.recv) txt += ` · UDP-пакетов: ${cap.sent || 0}→${cap.recv || 0}`;
      sub.textContent = txt;
    }
    const vd = $('probeVerdict');
    if (vd) {
      if (st.verdict) {
        vd.hidden = false;
        vd.innerHTML = escapeHtml(st.verdict);
      } else {
        vd.hidden = true;
      }
    }
    // Подсказки «в обход»: домены проблемных целей (SYN/UDP без ответа)
    const domBox = $('probeDomains');
    if (domBox) {
      if (!st.verdict || st.phase !== 'завершено') {
        domBox.hidden = true;
      } else {
        const problems = [];
        for (const [k, h] of Object.entries(hist)) {
          const states = h.states || {};
          const bad = (h.proto === 'tcp' && 'SynSent' in states && !('Established' in states))
            || (h.proto === 'udp' && (h.sent || 0) > 0 && (h.recv || 0) === 0);
          if (!bad) continue;
          const ip = k.slice(0, k.lastIndexOf(':'));
          for (const d of (dns[ip] || [])) problems.push(d);
        }
        const uniq = [...new Set(problems)];
        domBox.hidden = false;
        if (!uniq.length) {
          domBox.innerHTML = '<div class="meta">Проблемные цели - серверы по IP '
            + '(имён в DNS-кэше нет). Попробуйте «Общий IP-обход» или добавьте IP в ipset-включения.</div>';
        } else {
          const gctx = this._gameContext;
          domBox.innerHTML = '<div class="probe-domains-title">Домены проблемных целей - можно добавить в обход:</div>'
            + uniq.map(d => `<div class="probe-domain-row">
                <span class="endpoint-ip">${escapeHtml(d)}</span>
                <button class="btn btn-sm" data-add-domain="${escapeHtml(d)}">В обход</button>
                ${gctx ? `<button class="btn btn-sm" data-add-to-game="${escapeHtml(d)}">В игру: ${escapeHtml(gctx.name)}</button>` : ''}
              </div>`).join('');
          domBox.querySelectorAll('[data-add-domain]').forEach(b =>
            b.addEventListener('click', () => ListsPage.addDomainSuggestion(b)));
          domBox.querySelectorAll('[data-add-to-game]').forEach(b =>
            b.addEventListener('click', () => this.addToGame(b)));
        }
      }
    }
  },

  // Добавить найденный в анализе домен прямо в игру (запущенную из её карточки)
  async addToGame(btn) {
    const ctx = this._gameContext;
    if (!ctx) return;
    const domain = btn.dataset.addToGame;
    btn.disabled = true;
    btn.textContent = 'Добавляю…';
    try {
      const r = await apiPost('/games/add-domain',
                              { game_id: ctx.id, domain });
      if (r.status !== 'ok') throw new Error(r.message || 'ошибка');
      showToast(r.message || 'Домен добавлен в игру', 'ok');
      btn.textContent = 'Добавлено';
    } catch (e) {
      showToast('Игра: ' + (e.message || e), 'error');
      btn.disabled = false;
      btn.textContent = 'В игру: ' + ctx.name;
    }
  },
};

// ── boot ──

// ── Свои подсказки-поповеры: data-popover / data-popover-title ──────
// Системные title не подходят для длинных текстов: долгая задержка,
// нет переносов, нельзя стилизовать. Здесь: hover/focus, Esc, скролл.
const Popover = {
  _el: null, _anchor: null, _timer: null,

  init() {
    document.addEventListener('mouseover', (e) => {
      const t = e.target.closest && e.target.closest('[data-popover]');
      if (t) this._schedule(t, 140);
    });
    document.addEventListener('mouseout', (e) => {
      const t = e.target.closest && e.target.closest('[data-popover]');
      if (t && t.contains(e.relatedTarget)) return;
      if (t) this._cancel(t);
    });
    document.addEventListener('focusin', (e) => {
      const t = e.target.closest && e.target.closest('[data-popover]');
      if (t) this._schedule(t, 0);
    });
    document.addEventListener('focusout', () => this.hide());
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') this.hide(); });
    window.addEventListener('scroll', () => this.hide(), true);
    window.addEventListener('resize', () => this.hide());
  },

  _schedule(anchor, delay) {
    if (this._anchor === anchor && this._el) return;
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    this._timer = setTimeout(() => { this._timer = null; this.show(anchor); }, delay);
  },

  _cancel(anchor) {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    if (this._anchor === anchor) this.hide();
  },

  show(anchor) {
    const text = anchor.getAttribute('data-popover');
    if (!text) return;
    this.hide();
    const el = document.createElement('div');
    el.className = 'popover';
    const title = anchor.getAttribute('data-popover-title');
    if (title) {
      const t = document.createElement('div');
      t.className = 'popover-title';
      t.textContent = title;
      el.appendChild(t);
    }
    const body = document.createElement('div');
    body.textContent = text;
    el.appendChild(body);
    document.body.appendChild(el);
    this._el = el;
    this._anchor = anchor;

    const r = anchor.getBoundingClientRect();
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const below = r.top < vh / 2;
    let left = Math.round(r.left + r.width / 2 - w / 2);
    let top = below ? r.bottom + 9 : r.top - h - 9;
    left = Math.max(8, Math.min(left, vw - w - 8));
    top = Math.max(8, Math.min(top, vh - h - 8));
    el.style.left = left + 'px';
    el.style.top = top + 'px';
    el.dataset.placement = below ? 'bottom' : 'top';
    const arrowX = Math.max(14, Math.min(r.left + r.width / 2 - left, w - 14));
    el.style.setProperty('--arrow-x', arrowX + 'px');
    requestAnimationFrame(() => el.classList.add('visible'));
  },

  hide() {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    if (this._el) { this._el.remove(); this._el = null; }
    this._anchor = null;
  },
};

// ── Модалки: фокус, Tab-ловушка, возврат фокуса ─────────────────────
const Modal = {
  _last: null,

  open(id) {
    const ov = $(id);
    if (!ov || ov.classList.contains('open')) return;
    this._last = document.activeElement;
    ov.classList.add('open');
    const f = ov.querySelector('.modal button, .modal input, .modal select, .modal textarea, .modal a[href]');
    if (f) setTimeout(() => f.focus(), 0);
  },

  close(id) {
    const ov = $(id);
    if (!ov || !ov.classList.contains('open')) return;
    ov.classList.remove('open');
    const last = this._last;
    this._last = null;
    if (last && last.focus && document.contains(last)) last.focus();
  },

  _top() {
    const all = document.querySelectorAll('.modal-overlay.open');
    return all.length ? all[all.length - 1] : null;
  },

  init() {
    document.addEventListener('keydown', (e) => {
      const ov = this._top();
      if (!ov || e.key !== 'Tab') return;
      const items = Array.from(ov.querySelectorAll(
        'button:not([disabled]):not([hidden]), [href], input:not([disabled]):not([hidden]), select:not([hidden]), textarea:not([hidden]), [tabindex]:not([tabindex="-1"])'
      )).filter(el => el.offsetParent !== null);
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (!ov.contains(document.activeElement)) { e.preventDefault(); first.focus(); return; }
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
  },
};

// ── Своё подтверждение вместо window.confirm ────────────────────────
const Confirm = {
  _resolve: null,
  _wired: false,

  ask({ title, text, ok = 'Продолжить', danger = false } = {}) {
    return new Promise((resolve) => {
      this._resolve = resolve;
      $('confirmTitle').textContent = title || 'Подтвердите действие';
      $('confirmText').textContent = text || '';
      const btn = $('confirmOk');
      btn.textContent = ok;
      btn.className = 'btn ' + (danger ? 'btn-danger' : 'btn-primary');
      this._wire();
      Modal.open('confirmOverlay');
    });
  },

  _done(val) {
    Modal.close('confirmOverlay');
    const r = this._resolve;
    this._resolve = null;
    if (r) r(val);
  },

  _wire() {
    if (this._wired) return;
    this._wired = true;
    $('confirmOk').addEventListener('click', () => this._done(true));
    $('confirmCancel').addEventListener('click', () => this._done(false));
    $('confirmOverlay').addEventListener('mousedown', (e) => {
      if (e.target.id === 'confirmOverlay') this._done(false);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && $('confirmOverlay').classList.contains('open')) this._done(false);
    });
  },
};

// ── Плавающий индикатор задач: правый нижний угол, виден на всех вкладках ──
// Жёлтая мигающая точка = выполняется, зелёная = готово, красная = ошибка.
// Клик по плашке открывает вкладку с результатом.
const Activity = {
  _el: null, _text: null, _pct: null, _cancelBtn: null,
  _page: '', _hideTimer: null, _cancelling: false,

  _ensure() {
    if (this._el) return;
    const el = document.createElement('div');
    el.className = 'activity-chip';
    el.hidden = true;
    el.setAttribute('role', 'button');
    el.setAttribute('tabindex', '0');
    el.innerHTML = '<span class="activity-dot"></span>' +
      '<span class="activity-text"></span>' +
      '<span class="activity-pct mono"></span>' +
      '<span class="activity-go" aria-hidden="true">→</span>';
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'activity-cancel';
    cancel.textContent = 'Отменить';
    cancel.hidden = true;
    cancel.addEventListener('click', (e) => { e.stopPropagation(); this._cancel(); });
    el.appendChild(cancel);
    const go = () => { if (this._page) location.hash = '#' + this._page; };
    el.addEventListener('click', go);
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); }
    });
    document.body.appendChild(el);
    this._el = el;
    this._text = el.querySelector('.activity-text');
    this._pct = el.querySelector('.activity-pct');
    this._cancelBtn = cancel;
  },

  _cancel() {
    if (this._cancelling) return;
    this._cancelling = true;
    this._cancelBtn.disabled = true;
    this._cancelBtn.textContent = 'Отменяем…';
    apiPost('/tester/action', { action: 'cancel' }).catch(() => {});
  },

  set(page, label, pct, cancelable) {
    this._ensure();
    clearTimeout(this._hideTimer);
    this._page = page || '';
    this._el.hidden = false;
    this._el.classList.remove('done', 'fail');
    this._el.classList.add('running');
    this._text.textContent = label || 'Выполняется…';
    this._pct.textContent = (pct != null) ? Math.round(pct) + '%' : '';
    this._cancelling = false;
    this._cancelBtn.hidden = !cancelable;
    this._cancelBtn.disabled = false;
    this._cancelBtn.textContent = 'Отменить';
  },

  done(label) {
    if (!this._el || this._el.hidden) return;
    clearTimeout(this._hideTimer);
    this._el.classList.remove('running', 'fail');
    this._el.classList.add('done');
    this._text.textContent = label || 'Готово';
    this._pct.textContent = '';
    this._hideTimer = setTimeout(() => this.hide(), 3500);
  },

  fail(label) {
    if (!this._el) return;
    this._ensure();
    clearTimeout(this._hideTimer);
    this._el.hidden = false;
    this._el.classList.remove('running', 'done');
    this._el.classList.add('fail');
    this._text.textContent = label || 'Ошибка';
    this._pct.textContent = '';
    this._hideTimer = setTimeout(() => this.hide(), 6000);
  },

  hide() {
    clearTimeout(this._hideTimer);
    if (this._el) this._el.hidden = true;
  },
};

document.addEventListener('DOMContentLoaded', () => App.init());