from __future__ import annotations

import ctypes
import os
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

# Embeddable Python (portable-сборка) с ._pth не добавляет папку скрипта
# в sys.path - без этого импорт core на portable-сборке падает.
if not getattr(sys, "frozen", False):
    _app_dir = os.path.dirname(os.path.abspath(__file__))
    if _app_dir not in sys.path:
        sys.path.insert(0, _app_dir)

from core.admin import is_admin, relaunch_as_admin
from core.applog import log as _applog
from core.config import VERSION
from core.utils import known_desktop_dir, short_path


_DATA_DIRS = ["bin", "blobs", "lua", "presets", "lists", "windivert", "frontend"]


def _cleanup_stale_mei() -> None:
    """Убирает брошенные распаковки PyInstaller (%TEMP%\\_MEI*, старше 24ч):
    после аварийного выхода onefile оставляет их (живой webview или AV держит
    файл). Текущий _MEIPASS и свежие папки (чужие запуски) не трогаем."""
    if not getattr(sys, "frozen", False):
        return
    current = getattr(sys, "_MEIPASS", "")
    now = time.time()
    try:
        for d in Path(tempfile.gettempdir()).glob("_MEI*"):
            if str(d) == current:
                continue
            try:
                if now - d.stat().st_mtime > 24 * 3600:
                    shutil.rmtree(d, ignore_errors=True)
            except OSError:
                continue
    except OSError:
        pass


def _strip_portable_motw() -> None:
    """Portable из скачанного браузером zip: Explorer помечает файлы
    Mark-of-the-Web, и .NET Framework отказывается грузить такие сборки -
    pythonnet падает, интерфейс сообщает про «нет WebView2» (репро:
    Downloads + распакованный zip, 2026-10). Снимаем метку со всего дерева
    portable при первом запуске. Обычная проверка - два сентинела
    (pythonnet/webview); если метки нет, дальше двух `exists` дело не идёт.
    Системный Python и exe-сборка не затрагиваются."""
    try:
        exe_dir = Path(sys.executable).resolve().parent
        if exe_dir.name.lower() != "python":
            return  # интерпретатор не наш embeddable-рантайм
        root = exe_dir.parent
        site = exe_dir / "Lib" / "site-packages"
        sentinels = (
            site / "pythonnet" / "runtime" / "Python.Runtime.dll",
            site / "webview" / "lib" / "Microsoft.Web.WebView2.Core.dll",
        )
        if not any(os.path.exists(str(s) + ":Zone.Identifier")
                   for s in sentinels):
            return
        removed = 0
        for p in root.rglob("*"):
            try:
                if p.is_file():
                    os.remove(str(p) + ":Zone.Identifier")
                    removed += 1
            except OSError:
                pass
        _applog("motw", f"portable: снят Mark-of-the-Web "
                        f"(файлов: {removed}, root={root})")
    except Exception as e:  # noqa: BLE001 - диагностика не роняет старт
        try:
            _applog("motw", f"strip не удался: {e!r}")
        except Exception:
            pass


def _warn_if_bad_path(exe_dir: Path) -> bool:
    """True, если путь установки приемлем (больше НЕ блокируем запуск).

    ASCII-путь (с пробелами) безопасен - лаунчеры квотируют. Не-ASCII:
    основной запуск идёт через @conf (длинные пути; Cygwin раскрывает @file
    до main), а bat-фолбэк при отсутствии 8.3 пишется UTF-8+chcp - поэтому
    не пугаем MessageBox'ом, только пишем в лог (ревью 18.10)."""
    s = str(exe_dir)
    if all(ord(c) < 128 for c in s):
        return True
    if str(short_path(exe_dir)) != s:
        return True  # 8.3-имена есть (нужны только bat-фолбэку)
    try:
        from core.applog import log as _applog
        _applog("launch", f"WARN: не-ASCII путь без 8.3: {exe_dir} - "
                          "основной запуск через @conf; bat-фолбэк UTF-8+chcp")
    except Exception:
        pass
    return True


def _copy_data_dir(src_dir: Path, dst_dir: Path, top: str) -> None:
    """Копирует каталог данных сборки, НЕ затирая существующие user-файлы.

    Юзер-файл (core.updater.is_user_file) копируется только если его ещё
    нет: чистая установка получает шаблон, обновление версии сохраняет
    пользовательские списки/пресеты/игры. Раньше copytree(dirs_exist_ok)
    перезаписывал list-*-user/ipset-*-user пустышками из стейджинга сборки -
    списки пользователя молча исчезали при каждом обновлении (аудит 2026-10).
    """
    from core.updater import is_user_file
    failures = 0
    for root_, _dirs, files in os.walk(src_dir):
        rel_dir = Path(root_).relative_to(src_dir)
        for fn in files:
            rel = rel_dir / fn
            target = dst_dir / rel
            if target.exists() and is_user_file(f"{top}/{rel.as_posix()}"):
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(Path(root_) / fn, target)
            except OSError as e:
                # Файл занят живым winws2/AV/OneDrive (WinError 32). Не
                # валим весь запуск GUI: кладём рядом .new и помечаем провал,
                # чтобы маркер data_version не записался и копирование
                # повторилось на следующем старте (аудит 2026-11-14, P0).
                failures += 1
                _applog("layout", f"data copy FAIL {top}/{rel.as_posix()}: {e!r}")
                try:
                    shutil.copy2(Path(root_) / fn,
                                 target.with_name(target.name + ".new"))
                    _applog("layout", f"  отложено в {target.name}.new")
                except OSError:
                    pass
    return failures


def _stop_local_bypass_for_update(exe_dir: Path) -> bool:
    """Остановить НАШ текущий обход перед заменой bin/*.exe (P0 2026-11-14).

    Иначе копирование нового bin/winws2.exe поверх работающего даёт WinError
    32, MessageBox «не удалось подготовить данные» и GUI не стартует -
    повторяется на каждом запуске, пока служба жива. Останавливаем только
    свою службу/свои winws2 (path-фильтр по каталогу). Возвращает True, если
    служба была запущена (её надо вернуть после копирования)."""
    svc_was = False
    try:
        from core.service_manager import path_status, status as svc_status
        from core.service_manager import stop as svc_stop
        ps, _detail = path_status()
        if ps in ("ok", "orphaned") and svc_status() == "running":
            ok, msg = svc_stop()
            _applog("layout", f"update: служба остановлена перед копированием "
                              f"bin (ok={ok}, {msg})")
            svc_was = bool(ok)
    except Exception as e:  # noqa: BLE001 - диагностика не роняет старт
        _applog("layout", f"update: stop service перед копированием: {e!r}")
    try:
        from core import tester_proc
        candidates = [exe_dir / "bin" / "winws2.exe", exe_dir / "winws2.exe"]
        tester_proc.taskkill_safe("winws2.exe", allowed_paths=candidates)
    except Exception as e:  # noqa: BLE001
        _applog("layout", f"update: pathkill winws2: {e!r}")
    return svc_was


def _restore_local_bypass_after_update() -> None:
    try:
        from core.service_manager import start as svc_start
        ok, msg = svc_start(None)
        _applog("layout", f"update: служба возвращена после копирования "
                          f"(ok={ok}, {msg})")
    except Exception as e:  # noqa: BLE001
        _applog("layout", f"update: восстановление службы: {e!r}")


def _ensure_data_dir() -> Path:
    if not getattr(sys, "frozen", False):
        return Path(__file__).resolve().parent

    exe_dir = Path(sys.executable).resolve().parent
    src = Path(sys._MEIPASS)

    # Обновляем данные только при смене версии. user-файлы (списки/пресеты/
    # игры) НЕ затираются: из бандла копируются только отсутствующие (см.
    # _copy_data_dir; аудит 2026-10).
    marker = exe_dir / "data_version.txt"
    try:
        current = marker.read_text(encoding="utf-8").strip() if marker.exists() else ""
    except OSError:
        current = ""
    if current != VERSION:
        _applog("layout", f"data copy: marker={current!r} -> {VERSION!r} "
                          f"exe_dir={exe_dir}")
        # P0 2026-11-14: живая служба/winws2 держат bin/winws2.exe - копия
        # нового движка падала WinError 32 и GUI вообще не запускался
        # (на каждом старте, пока служба жива). Останавливаем свой обход,
        # копируем, возвращаем службу (если она была запущена).
        svc_was = _stop_local_bypass_for_update(exe_dir)
        failures = 0
        for d in _DATA_DIRS:
            target = exe_dir / d
            try:
                failures += _copy_data_dir(src / d, target, d)
            except OSError as e:
                failures += 1
                _applog("layout", f"data copy FAIL {d}: {e!r}")
        if failures:
            _applog("layout", f"data copy: {failures} файл(ов) не обновлены - "
                              "маркер не пишем, повторим на следующем старте")
            try:
                ctypes.windll.user32.MessageBoxW(
                    0,
                    "Часть файлов программы не удалось обновить (заняты):\n\n"
                    f"{failures} файл(ов). Программа запустится на старых "
                    "данных. Закройте антивирус/OneDrive, остановите обход и "
                    "перезапустите программу - обновление повторится.",
                    "Zapret2 - предупреждение", 0x30)
            except Exception:  # noqa: BLE001
                pass
        else:
            try:
                marker.write_text(VERSION, encoding="utf-8")
            except OSError as e:
                _applog("layout", f"marker write FAIL: {e!r}")
        if svc_was:
            _restore_local_bypass_after_update()

    _heal_missing_data(exe_dir, src)
    return exe_dir


def _heal_missing_data(exe_dir: Path, src: Path) -> None:
    """Привести SYSTEM-файлы к эталону из _MEIPASS (нет/обрезан/изменён).

    Маркер data_version.txt пишется ПОСЛЕ копирования, но AV/OneDrive могут
    забрать файл уже потом (или копия была частичной/обрезанной) - тогда смена
    версии не наступит и файл пропадёт навсегда. Поэтому сверяем на каждом
    запуске: нет файла / размер не совпал / при совпавшем размере не совпал
    sha256 -> перекопировать из _MEIPASS.

    Эталон - именно копия в _MEIPASS (тот же источник, из которого ставилась
    программа): update_manifest.json живёт в контуре апдейта и при обычном
    запуске рядом может не лежать, а mtime ломают AV/OneDrive/распаковка.
    user-файлы не участвуют (см. комментарий к key_files).
    """
    # ТОЛЬКО SYSTEM-файлы: user-контракт (lists/*-user.txt, lists/games/,
    # presets/custom.txt, не-релизные пресеты, games.json, конфиг, логи) heal
    # не трогает никогда. Если он попадёт сюда - пользовательские правки будут
    # откатываться на каждом запуске (решение автора, исторический аудит §2.8).
    key_files = [
        "bin/winws2.exe", "bin/cygwin1.dll", "bin/WinDivert.dll",
        "bin/WinDivert64.sys",
        "lua/zapret-lib.lua", "lua/zapret-antidpi.lua",
        "lists/list-general.txt", "presets/default.txt",
    ]
    for rel in key_files:
        target = exe_dir / rel
        source = src / rel
        if not source.exists():
            continue
        reason = ""
        try:
            if not target.exists():
                reason = "нет файла"
            elif target.stat().st_size != source.stat().st_size:
                reason = (f"размер {target.stat().st_size} != "
                          f"источника {source.stat().st_size}")
            elif _file_hash(target) != _file_hash(source):
                # Тот же размер, другие байты: подмена или правка SYSTEM-файла.
                # Правки тут не в контракте (своё держится в user-файлах), а
                # молчаливый подменённый winws2.exe опаснее всего.
                reason = "хеш не совпал с эталоном"
        except OSError as e:
            reason = f"stat: {e}"
        if not reason:
            continue
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            _applog("layout", f"self-heal: восстановлен {rel} "
                              f"({reason}; стало {target.stat().st_size} байт)")
        except OSError as e:
            _applog("layout", f"self-heal FAIL {rel}: {e!r}")


def _file_hash(path: Path) -> str:
    """sha256 файла (чанками). Только когда размер уже совпал."""
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _log_layout(root_dir: Path) -> None:
    """Раскладка путей и ресурсов в лог: frozen/MEIPASS/exe (разбор сбоев у юзеров)."""
    import sys as _sys
    checks = [
        "bin/winws2.exe", "bin/cygwin1.dll", "bin/WinDivert.dll",
        "bin/WinDivert64.sys", "lua/zapret-lib.lua", "lua/zapret-antidpi.lua",
        "blobs/tls_clienthello_www_google_com.bin",
        "blobs/quic_initial_www_google_com.bin",
        "lists/list-general.txt", "presets/default.txt", "frontend/index.html",
    ]
    parts: list[str] = []
    miss: list[str] = []
    for c in checks:
        f = root_dir / c
        if not f.exists():
            miss.append(c)
            continue
        try:
            parts.append(f"{c}={f.stat().st_size}B")
        except OSError:
            parts.append(f"{c}=?")
    _applog("layout", f"frozen={bool(getattr(_sys, 'frozen', False))} "
                      f"exe={_sys.executable} file={__file__} "
                      f"meipass={getattr(_sys, '_MEIPASS', None)} "
                      f"cwd={Path.cwd()} root={root_dir}")
    _applog("layout", "resources: " + " ".join(parts) +
                      (f" | MISSING: {'; '.join(miss)}" if miss else ""))
    m = root_dir / "data_version.txt"
    try:
        marker = m.read_text(encoding="utf-8").strip() if m.exists() else ""
    except OSError:
        marker = "?"
    _applog("layout", f"data_version: marker={marker!r} app={VERSION!r}")


def _check_launch_location(exe_dir: Path) -> None:
    """Предупреждения о «болевых» местах запуска (0.8): архив/временная папка
    и рабочий стол напрямую - важные; Загрузки/Документы - некритичные
    (есть чек в «Проверке системы»)."""
    def show(msg: str) -> None:
        ctypes.windll.user32.MessageBoxW(
            0, msg, "Zapret2 - предупреждение", 0x30)

    s = str(exe_dir)
    low = s.lower() + "\\"
    try:
        in_temp = exe_dir.resolve().is_relative_to(
            Path(tempfile.gettempdir()).resolve())
    except OSError:
        in_temp = False
    if in_temp:
        show(
            "Программа запущена из архива (временная папка):\n\n"
            f"{s}\n\n"
            "При запуске из архива Windows распаковывает программу во временную "
            "папку - списки, пресеты и настройки будут потеряны при её очистке.\n\n"
            "Распакуйте ZIP в отдельную папку (например C:\\Zapret2GUI\\) "
            "и запускайте программу оттуда.")
        return
    desktop = known_desktop_dir()
    if desktop and exe_dir == desktop:
        show(
            "Программа запущена прямо с рабочего стола.\n\n"
            "При первом обновлении данных рядом с программой появятся папки "
            "и файлы (bin, lua, presets...) - рабочий стол замусорится.\n\n"
            "Создайте папку (например C:\\Zapret2GUI\\), перенесите программу "
            "туда и запускайте из подпапки.")
        return
    if "\\downloads\\" in low or low.rstrip("\\").endswith("\\downloads"):
        show(
            "Программа запущена из папки Загрузки.\n\n"
            "Файлы из браузера несут пометку «из интернета» - антивирус проверяет "
            "их агрессивнее, а папка часто чистится. Рекомендую перенести "
            "программу в отдельную папку (например C:\\Zapret2GUI\\).")
        return
    if "\\documents\\" in low or low.rstrip("\\").endswith("\\documents"):
        show(
            "Программа запущена из папки Документы.\n\n"
            "Папка может синхронизироваться (OneDrive) и блокировать файлы "
            "программы во время записи. Рекомендую отдельную папку вне "
            "синхронизации (например C:\\Zapret2GUI\\).")
        return


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def _acquire_single_instance() -> bool:
    """Один экземпляр GUI на машину. False - уже запущен, выходим.

    Мьютекс нужен по существу, а не для вежливости: два окна получают
    два разных порта и два независимых состояния, оба считают себя
    владельцами обхода и службы. Отсюда взаимные убийства процессов
    winws2 (у каждого свой _find_pids по всем winws2), гонки установки
    и удаления службы и два конфликтующих редактора одних и тех же
    user-списков.

    Имя включает канонический путь: portable-копия в другой папке и
    обычный запуск из Program Files не должны считаться одним и тем же
    экземпляром - у них разные data-каталоги.
    """
    import ctypes
    from ctypes import wintypes
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateMutexW.argtypes = (ctypes.c_void_p, wintypes.BOOL,
                                      wintypes.LPCWSTR)
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    try:
        root = Path(sys.executable if getattr(sys, "frozen", False)
                    else __file__).resolve().parent
    except OSError:
        root = Path.cwd()
    # Имя мьютекса: путь без символов, которые WinAPI считает разделителями
    # (\\ и /), иначе «Local\X-C:\...» превратится в имя в другом
    # пространстве имён. PID сюда НЕ входит - иначе имя у каждого процесса
    # своё и второй экземпляр никогда не увидит занятый мьютекс.
    key = "".join(c if c.isalnum() else "_" for c in str(root).lower())
    handle = kernel32.CreateMutexW(None, True, f"Local\\Zapret2GUI_{key}")
    # CreateMutexW при уже существующем мьютексе возвращает НЕ NULL, а
    # ERROR_ALREADY_EXISTS в GetLastError - судить только по handle нельзя,
    # второй экземпляр так считал бы себя первым.
    err = ctypes.get_last_error()
    if err == 183:  # ERROR_ALREADY_EXISTS
        if handle:
            kernel32.CloseHandle(handle)
        return False
    if handle:
        # Дескриптор держим в глобальной перемене: иначе CPython закроет
        # его сборщиком мусора и мьютекс отпустится преждевременно.
        global _SINGLE_INSTANCE_MUTEX
        _SINGLE_INSTANCE_MUTEX = handle
        return True
    # Не смогли создать/открыть мьютекс (нет прав на Local\ и т.п.) -
    # не блокируем запуск из-за диагностической мелочи.
    _applog("single-instance", f"CreateMutexW не сработал (err={err}), "
                              "продолжаем без защиты от второго окна")
    return True


_SINGLE_INSTANCE_MUTEX = None

_WEBVIEW2_CLIENT = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"


def _webview2_runtime_version() -> str:
    """Версия Evergreen/Fixed WebView2 или пустая строка.

    pywebview при отсутствии Runtime уходит в MSHTML/IE и даёт белый экран,
    поэтому проверяем установку до импорта webview. Registry - основной
    признак; env/Program Files - Fixed Version Runtime.
    """
    try:
        import winreg
        paths = (
            (winreg.HKEY_LOCAL_MACHINE,
             rf"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{_WEBVIEW2_CLIENT}"),
            (winreg.HKEY_LOCAL_MACHINE,
             rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{_WEBVIEW2_CLIENT}"),
            (winreg.HKEY_CURRENT_USER,
             rf"Software\Microsoft\EdgeUpdate\Clients\{_WEBVIEW2_CLIENT}"),
        )
        for hive, sub in paths:
            try:
                with winreg.OpenKey(hive, sub) as key:
                    pv, _ = winreg.QueryValueEx(key, "pv")
                    if pv and str(pv) not in ("0.0.0.0", "0.0.0"):
                        return str(pv)
            except OSError:
                continue
    except Exception:  # noqa: BLE001 - preflight не должен ронять запуск
        pass
    runtime_dir = os.environ.get("WEBVIEW2_BROWSER_EXECUTABLE_FOLDER", "")
    if runtime_dir and Path(runtime_dir).is_dir():
        return "env"
    for base in (os.environ.get("ProgramFiles(x86)"),
                 os.environ.get("ProgramFiles")):
        if base and (Path(base) / "Microsoft" / "EdgeWebView" /
                     "Application").is_dir():
            return "dir"
    return ""


def _find_modern_browser() -> Path | None:
    """Edge/Chrome для запасного режима; IE и старый Edge не подходят."""
    names = ("msedge.exe", "chrome.exe")
    roots = (os.environ.get("ProgramFiles(x86)"),
             os.environ.get("ProgramFiles"),
             os.environ.get("LOCALAPPDATA"))
    candidates: list[Path] = []
    for root in roots:
        if not root:
            continue
        candidates += [
            Path(root) / "Microsoft" / "Edge" / "Application" / "msedge.exe",
            Path(root) / "Google" / "Chrome" / "Application" / "chrome.exe",
        ]
    for name in names:
        found = shutil.which(name)
        if found:
            candidates.append(Path(found))
    for path in candidates:
        try:
            if path.is_file():
                return path
        except OSError:
            continue
    return None


def _browser_mode_requested() -> bool:
    return ("--browser" in sys.argv[1:]
            or os.environ.get("ZAPRET2_BROWSER", "").strip().lower()
            in ("1", "true", "yes", "on"))


def _show_webview2_missing() -> None:
    ctypes.windll.user32.MessageBoxW(
        0,
        "WebView2 Runtime не найден, а современный Edge/Chrome не обнаружен.\n\n"
        "Установите Evergreen WebView2 Runtime:\n"
        "https://go.microsoft.com/fwlink/p/?LinkId=2124703\n\n"
        "Либо установите Edge/Chrome и запустите программу с параметром "
        "--browser.",
        "Zapret2 - нужен WebView2 или браузер", 0x30)


def _browser_fallback(url: str, on_closing) -> None:
    """Открыть UI в отдельном окне Edge/Chrome (app mode).

    Браузер запускается с отдельным временным профилем: не мешает обычному
    профилю и его расширениям. Процесс браузера держит сервер живым; после
    закрытия окна вызывается on_closing.
    """
    exe = _find_modern_browser()
    if exe is None:
        _show_webview2_missing()
        on_closing()
        return
    profile = Path(tempfile.mkdtemp(prefix="zapret2_browser_"))
    try:
        proc = subprocess.Popen(
            [str(exe), f"--app={url}", f"--user-data-dir={profile}",
             "--no-first-run", "--no-default-browser-check", "--disable-sync"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        proc.wait()
    except OSError as e:
        _applog("webview", f"browser fallback failed: {e!r}")
        _show_webview2_missing()
    finally:
        shutil.rmtree(profile, ignore_errors=True)
    on_closing()


def main_gui() -> None:
    if not is_admin():
        relaunch_as_admin()
        return

    # Проверка после повышения прав: перезапуск идёт отдельным процессом,
    # и если бы мьютекс брался до него, новый экземпляр увидел бы
    # «занято» от того, кто только что перезапустился.
    if not _acquire_single_instance():
        ctypes.windll.user32.MessageBoxW(
            0,
            "Zapret 2 уже запущена.\n\n"
            "Второе окно не нужно: оба экземпляра управляли бы одним "
            "обходом и службой и мешали друг другу.\n"
            "Закройте уже открытое окно и запустите программу ещё раз.",
            "Zapret2 — уже запущена", 0x40)
        return

    _cleanup_stale_mei()
    _strip_portable_motw()

    use_browser = _browser_mode_requested()
    browser_available = _find_modern_browser() is not None
    if use_browser and not browser_available:
        _show_webview2_missing()
        return
    if not use_browser and not _webview2_runtime_version():
        if browser_available:
            use_browser = True
            _applog("webview", "WebView2 Runtime не найден - browser fallback")
        else:
            _show_webview2_missing()
            return

    from server.server import init, create_server, stop_server

    print(f"[Zapret2 {VERSION}] Starting GUI...")

    root_dir = _ensure_data_dir()
    if root_dir is None:
        return
    _log_layout(root_dir)

    if getattr(sys, "frozen", False):
        if not _warn_if_bad_path(root_dir):
            return
        _check_launch_location(root_dir)

    app_token = secrets.token_hex(16)
    init(root_dir, app_token)

    port = _find_free_port()
    base_url = f"http://127.0.0.1:{port}"

    httpd = create_server("127.0.0.1", port)

    def run_server() -> None:
        httpd.serve_forever()

    t = threading.Thread(target=run_server, daemon=True)
    t.start()

    import urllib.request
    for _ in range(50):
        try:
            urllib.request.urlopen(f"{base_url}/?token={app_token}", timeout=1)
            break
        except Exception:
            time.sleep(0.1)

    def on_closing() -> None:
        print("[zapret2] Window closing, shutting down...")
        stop_server()
        try:
            from server.app_state import get_tester
            tester = get_tester()
            if tester:
                tester.signal_shutdown()
        except Exception:
            pass
        try:
            from core.utils import run_quiet
            run_quiet(["pktmon", "stop"])
            run_quiet(["pktmon", "filter", "remove"])
        except Exception:
            pass

    if use_browser:
        _browser_fallback(f"{base_url}/?token={app_token}", on_closing)
        print("[zapret2] Goodbye.")
        return

    try:
        import webview
    except Exception as e:
        _applog("webview", f"import failed: {e!r}")
        if browser_available:
            _browser_fallback(f"{base_url}/?token={app_token}", on_closing)
        else:
            _show_webview2_missing()
            on_closing()
        print("[zapret2] Goodbye.")
        return

    try:
        window = webview.create_window(
            "Zapret2 Manager",
            f"{base_url}/?token={app_token}",
            width=1280, height=840, min_size=(900, 600),
        )
        window.events.closing += on_closing
        webview.start(gui="edgechromium")
    except Exception as e:
        # у pythonw нет консоли - молча падать нельзя. Если Edge/Chrome есть,
        # уходим в браузерный режим вместо белого окна/MSHTML.
        _applog("webview", f"start failed: {e!r}")
        if browser_available:
            _browser_fallback(f"{base_url}/?token={app_token}", on_closing)
        else:
            ctypes.windll.user32.MessageBoxW(
                0,
                "Ошибка запуска интерфейса (WebView2).\n\n"
                "Установите WebView2 Runtime:"
                " https://go.microsoft.com/fwlink/p/?LinkId=2124703",
                "Zapret2 - ошибка", 0x30)
            on_closing()
    print("[zapret2] Goodbye.")


if __name__ == "__main__":
    if "--discord-fix-helper" in sys.argv[1:]:
        from core.discord_fix import run_helper
        run_helper()
    else:
        main_gui()