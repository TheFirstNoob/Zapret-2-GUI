from __future__ import annotations

import ctypes
import os
import secrets
import shutil
import socket
import sys
import tempfile
import threading
import time
from pathlib import Path

# Embeddable Python (portable build) uses a ._pth file that disables
# auto-adding the script dir to sys.path — without this, imports of core
# would fail on the portable build.
if not getattr(sys, "frozen", False):
    _app_dir = os.path.dirname(os.path.abspath(__file__))
    if _app_dir not in sys.path:
        sys.path.insert(0, _app_dir)

from core.admin import is_admin, relaunch_as_admin
from core.config import VERSION
from core.utils import known_desktop_dir, short_path


_DATA_DIRS = ["bin", "blobs", "lua", "presets", "lists", "windivert", "frontend"]


def _cleanup_stale_mei() -> None:
    """PyInstaller onefile unpacks into %TEMP%\\_MEIxxxxx on EVERY run; on
    abnormal exit the unpack dir stays behind (webview child still alive /
    antivirus holds a file).  Remove stale ones (older than 24h) — never our
    current _MEIPASS, never non-stale dirs (other apps' PyInstaller runs)."""
    if not getattr(sys, "frozen", False):
        return
    current = getattr(sys, "_MEIPASS", "")
    now = time.time()
    try:
        for d in Path(tempfile.gettempdir()).glob("_MEI*"):
            if str(d) == current:
                continue
            try:
                if now - d.stat().st_mtime > 24 * 3600:
                    shutil.rmtree(d, ignore_errors=True)
            except OSError:
                continue
    except OSError:
        pass


def _warn_if_bad_path(exe_dir: Path) -> bool:
    """True when the install path is safe for winws2.

    ASCII paths (spaces included) are safe — launchers quote them correctly.
    Non-ASCII paths only work while 8.3 short names are available (the .bat
    launchers are written in ASCII via short paths).  Warn only for the real
    failure class: non-ASCII path with no short form.
    """
    s = str(exe_dir)
    if all(ord(c) < 128 for c in s):
        return True
    if str(short_path(exe_dir)) != s:
        return True  # short form exists — launcher handles it

    title = "Zapret2 \u2014 \u041f\u0440\u0435\u0434\u0443\u043f\u0440\u0435\u0436\u0434\u0435\u043d\u0438\u0435"
    msg = (
        "\u041f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0430 \u0440\u0430\u0441\u043f\u0430\u043a\u043e\u0432\u0430\u043d\u0430 \u0432 \u043f\u0430\u043f\u043a\u0443 \u0441 \u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0446\u0435\u0439 \u0438 \u0431\u0435\u0437 \u043a\u043e\u0440\u043e\u0442\u043a\u0438\u0445 \u0438\u043c\u0451\u043d (8.3):\n\n"
        f"{exe_dir}\n\n"
        "\u0417\u0430\u043f\u0443\u0441\u043a winws2 \u0431\u0443\u0434\u0435\u0442 \u0441\u043b\u043e\u043c\u0430\u043d.\n"
        "\u041f\u0435\u0440\u0435\u043c\u0435\u0441\u0442\u0438\u0442\u0435 Zapret2GUI.exe \u0432 \u043f\u0430\u043f\u043a\u0443 \u0431\u0435\u0437 \u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0446\u044b,\n"
        "\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: C:\\Zapret2GUI\\"
    )
    ctypes.windll.user32.MessageBoxW(0, msg, title, 0x30)
    return False


def _ensure_data_dir() -> Path:
    if not getattr(sys, "frozen", False):
        return Path(__file__).resolve().parent

    exe_dir = Path(sys.executable).resolve().parent
    src = Path(sys._MEIPASS)

    # Refresh bundled data only when the version changes, so user edits to
    # bundled presets/lists survive regular launches; copytree never deletes
    # extra files — user presets and *-user.txt lists are safe.
    marker = exe_dir / "data_version.txt"
    try:
        current = marker.read_text(encoding="utf-8").strip() if marker.exists() else ""
    except OSError:
        current = ""
    if current != VERSION:
        for d in _DATA_DIRS:
            target = exe_dir / d
            try:
                shutil.copytree(src / d, target, dirs_exist_ok=True)
            except OSError as e:
                # файл под локом AV/OneDrive — молчаливая смерть pythonw
                # недопустима (M3): показываем причину и выходим чисто
                ctypes.windll.user32.MessageBoxW(
                    0,
                    "Не удалось подготовить данные программы:\n\n"
                    f"{e}\n\nЗакройте антивирус/OneDrive, снимите залоченные "
                    "файлы и запустите снова.",
                    "Zapret2 — ошибка", 0x30)
                return
        try:
            marker.write_text(VERSION, encoding="utf-8")
        except OSError:
            pass

    return exe_dir


def _check_launch_location(exe_dir: Path) -> None:
    """Проверка «болевых» мест запуска (0.8): из архива, Загрузки, Документы,
    рабочий стол напрямую. Временная папка и рабочий стол — важные
    предупреждения; Загрузки/Документы — некритичные (есть чек в
    «Проверке системы»)."""
    def show(msg: str) -> None:
        ctypes.windll.user32.MessageBoxW(
            0, msg, "Zapret2 — предупреждение", 0x30)

    s = str(exe_dir)
    low = s.lower() + "\\"
    try:
        in_temp = exe_dir.resolve().is_relative_to(
            Path(tempfile.gettempdir()).resolve())
    except OSError:
        in_temp = False
    if in_temp:
        show(
            "Программа запущена из архива (временная папка):\n\n"
            f"{s}\n\n"
            "При запуске из архива Windows распаковывает программу во временную "
            "папку — списки, пресеты и настройки будут потеряны при её очистке.\n\n"
            "Распакуйте ZIP в отдельную папку (например C:\\Zapret2GUI\\) "
            "и запускайте программу оттуда.")
        return
    desktop = known_desktop_dir()
    if desktop and exe_dir == desktop:
        show(
            "Программа запущена прямо с рабочего стола.\n\n"
            "При первом обновлении данных рядом с программой появятся папки "
            "и файлы (bin, lua, presets...) — рабочий стол замусорится.\n\n"
            "Создайте папку (например C:\\Zapret2GUI\\), перенесите программу "
            "туда и запускайте из подпапки.")
        return
    if "\\downloads\\" in low or low.rstrip("\\").endswith("\\downloads"):
        show(
            "Программа запущена из папки Загрузки.\n\n"
            "Файлы из браузера несут пометку «из интернета» — антивирус проверяет "
            "их агрессивнее, а папка часто чистится. Рекомендуем перенести "
            "программу в отдельную папку (например C:\\Zapret2GUI\\).")
        return
    if "\\documents\\" in low or low.rstrip("\\").endswith("\\documents"):
        show(
            "Программа запущена из папки Документы.\n\n"
            "Папка может синхронизироваться (OneDrive) и блокировать файлы "
            "программы во время записи. Рекомендуем отдельную папку вне "
            "синхронизации (например C:\\Zapret2GUI\\).")
        return


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def main_gui() -> None:
    if not is_admin():
        relaunch_as_admin()
        return

    _cleanup_stale_mei()

    try:
        import webview
    except Exception:
        ctypes.windll.user32.MessageBoxW(
            0,
            "Не удалось загрузить интерфейс (webview).\n\n"
            "Убедитесь, что установлен WebView2 Runtime:\n"
            "https://developer.microsoft.com/microsoft-edge/webview2/",
            "Zapret2 — ошибка", 0x30)
        return

    from server.server import init, create_server, stop_server

    print(f"[Zapret2 {VERSION}] Starting GUI...")

    root_dir = _ensure_data_dir()

    if getattr(sys, "frozen", False):
        if not _warn_if_bad_path(root_dir):
            return
        _check_launch_location(root_dir)

    app_token = secrets.token_hex(16)
    init(root_dir, app_token)

    port = _find_free_port()
    base_url = f"http://127.0.0.1:{port}"

    httpd = create_server("127.0.0.1", port)

    def run_server() -> None:
        httpd.serve_forever()

    t = threading.Thread(target=run_server, daemon=True)
    t.start()

    import urllib.request
    for _ in range(50):
        try:
            urllib.request.urlopen(f"{base_url}/?token={app_token}", timeout=1)
            break
        except Exception:
            time.sleep(0.1)

    def on_closing() -> None:
        print("[zapret2] Window closing, shutting down...")
        stop_server()
        try:
            from server.server import _tester
            if _tester:
                _tester.signal_shutdown()
        except Exception:
            pass
        try:
            from core.utils import run_quiet
            run_quiet(["pktmon", "stop"])
            run_quiet(["pktmon", "filter", "remove"])
        except Exception:
            pass

    window = webview.create_window(
        "Zapret2 Manager",
        f"{base_url}/?token={app_token}",
        width=1280, height=840, min_size=(900, 600),
    )
    try:
        window.events.closing += on_closing
        webview.start()
    except Exception:
        # pythonw has no console — never fail silently.
        ctypes.windll.user32.MessageBoxW(
            0,
            "Ошибка запуска интерфейса (WebView2).\n\n"
            "Убедитесь, что установлен WebView2 Runtime:"
            " https://developer.microsoft.com/microsoft-edge/webview2/",
            "Zapret2 — ошибка", 0x30)
    print("[zapret2] Goodbye.")


if __name__ == "__main__":
    main_gui()