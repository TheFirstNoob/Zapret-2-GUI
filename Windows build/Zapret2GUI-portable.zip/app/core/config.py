from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional


@dataclass
class AppConfig:
    root_dir: str = ""
    last_profile: str = "default"
    zapret1_dir: str = ""
    zapret1_last_strategy: str = ""
    game_filter_mode: str = "off"
    discord_voice: bool = False
    discord_voice_mode: str = "off"  # off | fake | udplen
    fake_blob: str = ""                # ключ tls_clienthello_<key>.bin; пусто = как в пресете (google)
    winws2_debug: bool = False
    autohostlist: bool = False
    ipset_catchall: bool = False
    tour_done: bool = False
    notice_done: bool = False


DEFAULT_PROFILE = "default"

VERSION = "Pre-Release 0.8"


class ConfigManager:
    def __init__(self, root_dir: Path) -> None:
        self.root_dir = Path(root_dir)
        self.config_path = self.root_dir / "zapret2_config.json"
        self._config: Optional[AppConfig] = None

    def load(self) -> AppConfig:
        if self._config is not None:
            return self._config
        known = {}
        if self.config_path.exists():
            try:
                data = json.loads(self.config_path.read_text(encoding="utf-8"))
                # Отбрасываем ключи вне AppConfig (старые/чужие поля),
                # иначе TypeError валит загрузку и теряется last_profile.
                known = {k: v for k, v in data.items()
                         if k in AppConfig.__dataclass_fields__}
                self._config = AppConfig(**known)
            except (OSError, json.JSONDecodeError, TypeError):
                self._config = AppConfig(root_dir=str(self.root_dir))
        else:
            self._config = AppConfig(root_dir=str(self.root_dir))
        # Миграция старых конфигов (bool discord_voice без discord_voice_mode).
        if "discord_voice_mode" not in known and self._config.discord_voice:
            self._config.discord_voice_mode = "fake"
        return self._config

    def save(self, config: AppConfig) -> bool:
        try:
            # атомарная запись (L5): обрыв посреди write_text делал конфиг
            # битым json — сбрасывался в дефолт
            tmp = self.config_path.with_suffix(".tmp")
            tmp.write_text(
                json.dumps(asdict(config), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            os.replace(tmp, self.config_path)
            self._config = config
            return True
        except OSError:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
            return False