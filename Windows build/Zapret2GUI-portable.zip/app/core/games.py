"""Игровые блокировки: домены (авторизация) + UDP-правила (сессия) по играм.

Данные - ``games.json`` в корне программы (USER-файл, обновления не трогают).
Домены включённых игр собираются в ``lists/list-games.txt`` (рефкаунт: домен
держится, пока нужен хотя бы одной включённой игре) и инжектятся лаунчером.
UDP-правила превращаются в профили winws2 (fake + payload=all - иначе lua не
трогает unknown-UDP - только старт соединения, 1 фейк).
"""
from __future__ import annotations

import ipaddress
import json
import os
import re
import threading
from contextlib import contextmanager
from pathlib import Path

from core.applog import log as _applog
from core.list_health import atomic_write_text, list_lock

GAMES_FILE = "games.json"
DOMAIN_LIST = "list-games.txt"      # внутри lists/
CIDR_DIR = "games"                   # внутри lists/games/<id>.txt
INCLUDE_ALL = "list-include-all.txt"  # внутри lists/ (user+games union)
DEFAULT_REPEATS = 1
DEFAULT_CUTOFF = 4

# Свои игры (custom): лимиты ручного ввода - строки уходят в аргументы
# winws2, поэтому валидируем строго, а не доверяем фронтенду.
CUSTOM_LIMITS = {"games": 20, "domains": 50, "ports": 10, "cidrs": 64}
_DOMAIN_RE = re.compile(
    r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?"
    r"(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$")
_PORT_RE = re.compile(r"^(\d{1,5})(?:-(\d{1,5}))?$")

# Транзакции games.json (аудит 2026-11-14, T21): HTTP-сервер потоковый, два
# конкурентных mutating-запроса (save/custom/add-domain) читали один снимок
# файла и последний молча затирал чужую правку. RLock: хендлер может держать
# его на всю транзакцию, вложенные вызовы (mutate_games) не блокируются.
# Порядок локов в проекте: games_lock -> list_lock (sync_include_list берёт
# list_lock сам); обратного порядка (list_lock -> games_lock) нигде нет,
# поэтому дедлока нет.
_GAMES_LOCK = threading.RLock()


@contextmanager
def games_lock():
    """Lock транзакций games.json (RLock: вложенный вызов безопасен)."""
    with _GAMES_LOCK:
        yield


def mutate_games(root: Path, mutator) -> tuple[bool, str, dict]:
    """Атомарный read-modify-write games.json под games_lock.

    mutator(data) -> (ok, message, data): при ok=False правка отклонена и
    файл НЕ пишется. Возвращает (ok, message, данные-после-правки).
    """
    with _GAMES_LOCK:
        current = load_games(root)
        ok, message, updated = mutator(current)
        if not ok:
            return False, message, updated
        valid, err = validate_games(updated)
        if not valid:
            return False, err, updated
        if not save_games(root, updated):
            return False, "Не удалось сохранить games.json", updated
        return True, message, updated


def default_games() -> dict:
    """Предзаполненный набор (Wardogs проверен на SkyNet, 2026-09-22).

    UDP-порты Wardogs: диапазон 4192-4194 закрывает региональные варианты
    (уточнено 2026-10-23).
    """
    return {"games": [{
        "id": "wardogs",
        "name": "Wardogs",
        "enabled": True,
        "process": "WardogsClient.exe",
        "domains": [
            {"domain": "live.wardogs.bulkhead.pragmaengine.com",
             "on": True, "warn": False, "tag": "Основной бэкенд",
             "note": "сервер лобби и поиска матча (без него нет сессии)"},
            {"domain": "firstlook.gg", "on": True, "warn": False,
             "tag": "Авторизация",
             "note": "вход в профиль и токен сессии"},
            {"domain": "api.epicgames.dev", "on": True, "warn": True,
             "tag": "Общий сервис",
             "note": "Epic Online Services - нужен всем играм Epic, "
                     "не только этой"},
        ],
        "udp": [{
            "ports": "4192-4194",
            "cidrs": ["54.115.0.0/16", "54.228.0.0/16",
                      "54.216.0.0/16", "3.218.0.0/16"],
            "on": True,
            "repeats": DEFAULT_REPEATS,
            "cutoff": DEFAULT_CUTOFF,
            "tag": "Сетевой бой",
            "note": "fake на старте коннекта, без флуда; региональные порты "
                    "в диапазоне 4192-4194",
        }],
    }, {
        "id": "valorant",
        "name": "Valorant",
        "enabled": True,
        "process": "VALORANT.exe",
        "domains": [
            {"domain": "valorant.com", "on": True, "warn": False,
             "tag": "Игра и лончер",
             "note": "в реестре РКН - домену нужен обход"},
            {"domain": "playvalorant.com", "on": True, "warn": False,
             "tag": "Лончер", "note": "клиент и обновления"},
            {"domain": "riotgames.com", "on": True, "warn": False,
             "tag": "Аккаунт", "note": "вход в аккаунт Riot"},
            {"domain": "riotcdn.net", "on": True, "warn": False,
             "tag": "CDN", "note": "файлы игры и патчи"},
        ],
        # UDP-фикс пока не подобран (Riot использует UDP 5000-5500) - как с
        # Wardogs: сначала проба через «Анализ приложения», потом правило.
        "udp": [],
    }, {
        "id": "fortnite",
        "name": "Fortnite",
        "enabled": True,
        "process": "FortniteClient-Win64-Shipping.exe",
        "domains": [
            {"domain": "fortnite.com", "on": True, "warn": False,
             "tag": "Игра", "note": "сервисы игры"},
            {"domain": "epicgames.com", "on": True, "warn": False,
             "tag": "Аккаунт", "note": "Epic Games: вход и лончер"},
            {"domain": "epicgames.dev", "on": True, "warn": True,
             "tag": "Общий сервис",
             "note": "Epic Online Services - нужен всем играм Epic"},
            {"domain": "epicgamescdn.com", "on": True, "warn": False,
             "tag": "CDN", "note": "загрузки и патчи"},
        ],
        # Симптом у друзей: «бесконечный поиск сессии» - похоже на блок
        # первого UDP-коннекта (кейс Wardogs). План: «Анализ приложения» ->
        # цели (IP/порты) -> правило fake:payload=all на этих портах
        # (Epic обычно UDP 5222, 5795-5847) -> проверка, что сессия стартует.
        "udp": [],
    }, {
        "id": "warp",
        "name": "WARP (стабилизация)",
        "enabled": False,  # эксперимент: включать, только если WARP рвёт
        "process": "",
        "domains": [],
        "udp": [{
            "ports": "443,500,1701,2408,4443,4500,8443,8095",
            "cidrs": ["162.159.192.0/24", "162.159.193.0/24",
                      "162.159.195.0/24", "162.159.196.0/24",
                      "162.159.197.0/24", "162.159.198.0/24",
                      "162.159.199.0/24"],
            "on": True,
            "repeats": 1,
            "cutoff": 6,
            "tag": "Эксперимент",
            "note": "fake на старте UDP-коннектов WARP (MASQUE/WireGuard); "
                    "проверено 2026-10-10: существующий WARP не ломает; "
                    "включать при обрывах CF_HAPPYFAIL",
        }],
    }]}


def _games_path(root: Path) -> Path:
    return Path(root) / GAMES_FILE


def load_games(root: Path) -> dict:
    """Читает games.json; при отсутствии/нечитаемости - дефолты.

    Нечитаемый/битый файл (BOM от «Блокнота», частичная запись OneDrive/AV,
    обрыв при выключении) НЕ перезаписывается на месте: он откладывается в
    games.json.bad, а games.json создаётся заново чистым. Раньше дефолты
    писались поверх, и все пользовательские игры с галочками исчезали молча и
    безвозвратно (исторический аудит §2.6). Теперь оригинал лежит рядом —
    вернуть его можно вручную, ничего не теряется.
    """
    path = _games_path(root)
    if path.exists():
        try:
            # utf-8-sig: BOM не должен ронять разбор (кейс 2026-09-14).
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            if isinstance(data, dict) and isinstance(data.get("games"), list):
                _sanitize_games(data)
                _backfill_process(data)
                _ensure_builtin_games(data)
                return data
            saved = _quarantine_games(path, "не dict или нет списка games")
        except (OSError, ValueError) as e:
            # json.JSONDecodeError и UnicodeDecodeError — оба ValueError
            saved = _quarantine_games(path, type(e).__name__)
        if not saved:
            # Отложить не вышло (файл держит AV/OneDrive). Перезаписывать его
            # дефолтами нельзя — это единственная копия пользовательских игр,
            # пусть битая. Работаем на дефолтах в памяти и попробуем снова на
            # следующем запуске.
            return default_games()
    data = default_games()
    # Файла нет (первый запуск) либо он отложен в .bad: создаём чистый валидный
    # games.json - лаунчер и тестер читают его напрямую с диска.
    save_games(root, data)
    return data


def _quarantine_games(path: Path, reason: str) -> bool:
    """Отложить нечитаемый games.json в .bad, чтобы каталог остался рабочим.

    True - исходник сохранён в .bad (можно писать чистый games.json).
    False - отложить не вышло, оригинал на месте и его нельзя трогать.
    """
    bak = path.with_suffix(path.suffix + ".bad")
    try:
        if bak.exists():
            bak.unlink()
        path.replace(bak)
        _applog("games", f"games.json не прочитан ({reason}) - исходник сохранён "
                         f"как {bak.name}, работаем на встроенных играх. "
                         f"Верните файл на место, если он важен")
        return True
    except OSError as e:
        _applog("games", f"games.json не прочитан ({reason}) и не отложен: {e!r}")
        return False


def _sanitize_games(data: dict) -> None:
    """Не даёт одному битому элементу уронить чтение/старт.

    JSON может быть валидным, но с null/строкой вместо игры, domains или
    udp. Такие элементы отбрасываем, остальные сохраняем.
    """
    games = data.get("games")
    if not isinstance(games, list):
        data["games"] = []
        return
    clean: list[dict] = []
    for game in games:
        if not isinstance(game, dict):
            continue
        for key in ("domains", "udp"):
            items = game.get(key)
            if items is None:
                game[key] = []
            elif not isinstance(items, list):
                game[key] = []
            else:
                game[key] = [x for x in items if isinstance(x, dict)]
        clean.append(game)
    data["games"] = clean


def validate_games(data: dict) -> tuple[bool, str]:
    """Структурная проверка перед записью games.json.

    Семантику (порты/CIDR/лимиты) проверяют clean_custom_*; здесь важно не
    пустить в файл null/строки, которые потом валят enabled_*.
    """
    if not isinstance(data, dict) or not isinstance(data.get("games"), list):
        return False, "games должен быть объектом со списком games"
    for game in data["games"]:
        if not isinstance(game, dict):
            return False, "элемент games должен быть объектом"
        for key in ("domains", "udp"):
            items = game.get(key)
            if items is None:
                continue
            if not isinstance(items, list) or any(
                    not isinstance(x, dict) for x in items):
                return False, f"{key} должен быть списком объектов"
        for rule in game.get("udp") or []:
            ports, err = _valid_udp_rule_values(rule)
            if err:
                return False, err
            if rule.get("on") and not ports:
                return False, "У включённого UDP-правила нет портов"
    return True, ""


def _backfill_process(data: dict) -> None:
    """Дополняет записи старых games.json полем process из дефолтов."""
    try:
        defaults = {g.get("id"): g for g in default_games().get("games", [])}
        for g in data.get("games", []):
            if not isinstance(g, dict) or "process" in g:
                continue
            src = defaults.get(g.get("id")) or {}
            if src.get("process"):
                g["process"] = src["process"]
    except Exception:
        pass


def _ensure_builtin_games(data: dict) -> None:
    """Добавляет недостающие ВСТРОЕННЫЕ игры (новые фичи) в старый games.json.

    Запись создаётся ВЫКЛЮЧЕННОЙ и только в памяти (сохранится при следующей
    обычной записи) - существующие игры не трогаем (аудит-фича 2026-10:
    так раздаётся «WARP (стабилизация)» без переустановки)."""
    import copy
    try:
        known = {str(g.get("id")) for g in data.get("games", [])
                 if isinstance(g, dict)}
        for g in default_games().get("games", []):
            if str(g.get("id")) not in known:
                data.setdefault("games", []).append(
                    copy.deepcopy({**g, "enabled": False}))
    except Exception:
        pass


def save_games(root: Path, data: dict) -> bool:
    """Атомарная запись games.json (уникальное temp-имя - аудит 2026-10)."""
    ok, _err = validate_games(data)
    if not ok:
        return False
    path = _games_path(root)
    try:
        atomic_write_text(path, json.dumps(data, indent=2, ensure_ascii=False))
        return True
    except OSError:
        return False


def enabled_domains(data: dict) -> list[str]:
    """Домены включённых игр (on=true), без дублей - рефкаунт через union."""
    out: list[str] = []
    for game in data.get("games", []):
        if not isinstance(game, dict) or not game.get("enabled"):
            continue
        domains = game.get("domains")
        if not isinstance(domains, list):
            continue
        for item in domains:
            if not isinstance(item, dict):
                continue
            dom = str(item.get("domain") or "").strip().lower()
            if dom and item.get("on") and dom not in out:
                out.append(dom)
    return out


def _normalize_udp_ports(text: object, max_parts: int = 64) -> str:
    """Строгий UDP-порт-лист: только N или N-M, 1..65535, без аргументов.

    Значение из games.json уходит прямо в --filter-udp и --wf-udp-out;
    перенос строки/пробел/``--new`` здесь недопустимы.
    """
    parts: list[str] = []
    for raw in str(text or "").split(","):
        p = raw.strip()
        if not p:
            continue
        m = _PORT_RE.fullmatch(p)
        if not m:
            return ""
        a = int(m.group(1))
        b = int(m.group(2)) if m.group(2) else a
        if not (1 <= a <= b <= 65535):
            return ""
        tok = str(a) if a == b else f"{a}-{b}"
        if tok not in parts:
            parts.append(tok)
        if len(parts) > max_parts:
            return ""
    return ",".join(parts)


def _valid_udp_rule_values(rule: dict) -> tuple[str, str]:
    """(ports, error) для сохранения правила; пустой ports допустим."""
    ports_raw = rule.get("ports")
    if ports_raw in (None, ""):
        ports = ""
    else:
        ports = _normalize_udp_ports(ports_raw)
        if not ports:
            return "", f"Некорректные UDP-порты: {ports_raw!r}"
    for field, low, high in (("repeats", 1, 64), ("cutoff", 0, 128)):
        raw = rule.get(field)
        if raw in (None, ""):
            continue
        try:
            value = int(raw)
        except (TypeError, ValueError):
            return "", f"{field} должен быть целым числом"
        if value < low or value > high:
            return "", f"{field} вне диапазона {low}..{high}"
    cidrs = rule.get("cidrs")
    if cidrs not in (None, ""):
        if isinstance(cidrs, str):
            cidrs = [c for c in re.split(r"[\s,;]+", cidrs) if c]
        if not isinstance(cidrs, list):
            return "", "cidrs должен быть списком"
        for c in cidrs:
            try:
                ipaddress.ip_network(str(c).strip(), strict=False)
            except ValueError:
                return "", f"Некорректная сеть: {c}"
    return ports, ""


def enabled_udp_rules(data: dict) -> list[dict]:
    """Активные UDP-правила включённых игр (с валидацией портов/CIDR).

    games.json - пользовательский файл: мусор от ручной правки (repeats
    строкой, cidrs строкой) не должен ронять старт обхода ValueError'ом
    (аудит 2026-10: /api/start падал с 500 на int('abc'))."""
    out: list[dict] = []
    for game in data.get("games", []):
        if not isinstance(game, dict) or not game.get("enabled"):
            continue
        udp_rules = game.get("udp")
        if not isinstance(udp_rules, list):
            continue
        for rule in udp_rules:
            if not isinstance(rule, dict) or not rule.get("on"):
                continue
            ports = _normalize_udp_ports(rule.get("ports"))
            if not ports:
                _applog("games", f"UDP-правило {game.get('id')!r} пропущено: "
                                  f"некорректные порты")
                continue
            raw_cidrs = rule.get("cidrs") or []
            if isinstance(raw_cidrs, str):
                # ручная правка строкой: "10.0.0.0/24, 10.0.1.0/24"
                raw_cidrs = [c for c in re.split(r"[\s,;]+", raw_cidrs) if c]
            cidrs: list[str] = []
            for c in raw_cidrs:
                c = str(c).strip()
                if not c:
                    continue
                try:
                    ipaddress.ip_network(c, strict=False)
                except ValueError:
                    continue  # не-CIDR из правленого руками файла - пропуск
                cidrs.append(c)
            # подсети могут быть пустыми: правило «широкое» (весь порт)
            if not ports:
                continue
            try:
                repeats = int(rule.get("repeats") or DEFAULT_REPEATS)
            except (TypeError, ValueError):
                repeats = DEFAULT_REPEATS
            if not (1 <= repeats <= 64):
                repeats = DEFAULT_REPEATS
            try:
                cutoff = int(rule.get("cutoff") or DEFAULT_CUTOFF)
            except (TypeError, ValueError):
                cutoff = DEFAULT_CUTOFF
            if not (0 <= cutoff <= 128):
                cutoff = DEFAULT_CUTOFF
            out.append({
                "id": str(game.get("id") or "game"),
                "game": str(game.get("name") or game.get("id") or ""),
                "ports": ports,
                "cidrs": cidrs,
                "repeats": repeats,
                "cutoff": cutoff,
            })
    return out


def clean_custom_domains(text: str) -> tuple[list[str], str]:
    """Домены из ручного ввода: нормализация (схема/путь/регистр) + проверка."""
    out: list[str] = []
    for raw in re.split(r"[\s,;]+", str(text or "")):
        d = raw.strip().lower()
        d = re.sub(r"^[a-z][a-z0-9+.-]*://", "", d)
        d = d.split("/", 1)[0].split(":", 1)[0].rstrip(".")
        if not d:
            continue
        if not _DOMAIN_RE.match(d):
            return [], f"Некорректный домен: {raw.strip()}"
        if d not in out:
            out.append(d)
    if len(out) > CUSTOM_LIMITS["domains"]:
        return [], f"Слишком много доменов (макс. {CUSTOM_LIMITS['domains']})"
    return out, ""


def clean_custom_ports(text: str) -> tuple[str, str]:
    """UDP-порты: '7777', '5000-5010', через запятую; нормализация и лимит."""
    parts: list[str] = []
    for raw in str(text or "").split(","):
        p = raw.strip()
        if not p:
            continue
        m = _PORT_RE.match(p)
        if not m:
            return "", f"Некорректный порт: {p}"
        a = int(m.group(1))
        b = int(m.group(2)) if m.group(2) else a
        if not (1 <= a <= b <= 65535):
            return "", f"Порт вне диапазона: {p}"
        tok = str(a) if a == b else f"{a}-{b}"
        if tok not in parts:
            parts.append(tok)
    if len(parts) > CUSTOM_LIMITS["ports"]:
        return "", f"Слишком много портов (макс. {CUSTOM_LIMITS['ports']})"
    return ",".join(parts), ""


def clean_custom_cidrs(text: str) -> tuple[list[str], str]:
    """Подсети из ручного ввода: ipaddress(strict=False) + дедуп и лимит."""
    out: list[str] = []
    for raw in re.split(r"[\s,;]+", str(text or "")):
        c = raw.strip()
        if not c:
            continue
        try:
            net = str(ipaddress.ip_network(c, strict=False))
        except ValueError:
            return [], f"Некорректная сеть: {c}"
        if net not in out:
            out.append(net)
    if len(out) > CUSTOM_LIMITS["cidrs"]:
        return [], f"Слишком много подсетей (макс. {CUSTOM_LIMITS['cidrs']})"
    return out, ""


def upsert_custom_game(data: dict, game: dict) -> tuple[bool, str, dict]:
    """Добавить/изменить СВОЮ игру. Встроенные игры не редактируются.

    Возвращает (ok, сообщение, данные) - данные уже с изменением.
    """
    gid = str(game.get("id") or "").strip()
    name = str(game.get("name") or "").strip()[:60]
    if not name:
        return False, "Укажите имя игры", data
    domains, err = clean_custom_domains(game.get("domains_text", ""))
    if err:
        return False, err, data
    ports, err = clean_custom_ports(game.get("ports", ""))
    if err:
        return False, err, data
    cidrs, err = clean_custom_cidrs(game.get("cidrs_text", ""))
    if err:
        return False, err, data
    process = str(game.get("process") or "").strip()[:80]
    games = data.setdefault("games", [])
    found = None
    if gid:
        found = next((g for g in games if str(g.get("id")) == gid), None)
        if found is not None and not found.get("custom"):
            return False, "Встроенную игру редактировать нельзя", data
    if found is None:
        if sum(1 for g in games if g.get("custom")) >= CUSTOM_LIMITS["games"]:
            return False, (f"Своих игр уже максимум "
                           f"({CUSTOM_LIMITS['games']})"), data
        used = {str(g.get("id")) for g in games}
        n = 1
        while f"custom-{n}" in used:
            n += 1
        gid = f"custom-{n}"
        found = {"id": gid, "custom": True, "enabled": True,
                 "domains": [], "udp": []}
        games.append(found)
    found["name"] = name
    found["process"] = process
    old_dom = {str(d.get("domain")): bool(d.get("on"))
               for d in (found.get("domains") or [])}
    found["domains"] = [{"domain": d, "on": old_dom.get(d, True)}
                        for d in domains]
    if ports:
        old_udp = (found.get("udp") or [{}])[0]
        found["udp"] = [{
            "ports": ports,
            "on": bool(old_udp.get("on", True)),
            "cidrs": cidrs,
            "repeats": DEFAULT_REPEATS,
            "cutoff": DEFAULT_CUTOFF,
            "note": "добавлено вручную",
        }]
    else:
        found["udp"] = []
    return True, "", data


def delete_custom_game(data: dict, gid: str) -> tuple[bool, str, dict]:
    """Удалить СВОЮ игру (встроенные защищены)."""
    games = data.get("games", [])
    g = next((x for x in games if str(x.get("id")) == str(gid)), None)
    if g is None:
        return False, "Игра не найдена", data
    if not g.get("custom"):
        return False, "Встроенную игру удалить нельзя", data
    games.remove(g)
    return True, "", data


def sync_domain_list(root: Path, data: dict | None = None) -> Path:
    """lists/list-games.txt = домены включённых игр (пустой файл, если нет)."""
    root = Path(root)
    if data is None:
        data = load_games(root)
    path = root / "lists" / DOMAIN_LIST
    path.parent.mkdir(parents=True, exist_ok=True)
    text = "\n".join(enabled_domains(data))
    atomic_write_text(path, text + ("\n" if text else ""))
    return path


def _read_domain_lines(path: Path) -> list[str]:
    """Домены из файла-списка: без пустых строк, комментариев и дублей."""
    out: list[str] = []
    seen: set[str] = set()
    try:
        text = Path(path).read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return out
    for line in text.splitlines():
        d = line.strip().lower().rstrip(".")
        if not d or d.startswith("#") or d.startswith("//"):
            continue
        if d not in seen:
            seen.add(d)
            out.append(d)
    return out


def sync_include_list(root: Path, user_file: Path | None = None,
                      data: dict | None = None) -> Path | None:
    """lists/list-include-all.txt = домены user-списка + включённых игр.

    Один --hostlist-токен в args вместо двух (файлы-владельцы не смешиваются:
    list-include-user.txt остаётся юзерским, list-games.txt - генерируемым).
    None - если юзерского файла нет И игр нет: инжектить нечего.
    """
    with list_lock():
        return _sync_include_list_unlocked(root, user_file, data)


def _sync_include_list_unlocked(root: Path, user_file: Path | None,
                                data: dict | None) -> Path | None:
    root = Path(root)
    lists = root / "lists"
    if user_file is None:
        user_file = lists / "list-include-user.txt"
    user_file = Path(user_file)
    games_path = sync_domain_list(root, data)
    merged: list[str] = []
    seen: set[str] = set()
    for src in (user_file, games_path):
        for d in _read_domain_lines(src):
            if d not in seen:
                seen.add(d)
                merged.append(d)
    if not merged and not user_file.exists():
        return None
    out = lists / INCLUDE_ALL
    out.parent.mkdir(parents=True, exist_ok=True)
    # Этот файл указан прямо в аргументах ЖИВОГО winws2 (--hostlist), поэтому
    # обрыв посреди записи обнулил бы весь обход на этом hostlist. Атомарно.
    atomic_write_text(out, "\n".join(merged) + ("\n" if merged else ""))
    return out


def write_cidr_pool_file(root: Path, key: str, cidrs: list[str]) -> Path:
    """lists/games/_pool_<key>.txt - общий CIDR-файл пула UDP-правил.

    Пул: один --new-сегмент на группу правил с одинаковыми repeats/cutoff,
    CIDR всех правил группы сливаются сюда (дедуп) - args не растут от числа
    игр (раньше ~150 симв. на каждую игру с UDP).
    """
    root = Path(root)
    folder = root / "lists" / CIDR_DIR
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"_pool_{key}.txt"
    seen: set[str] = set()
    out: list[str] = []
    for c in cidrs:
        c = str(c).strip()
        if c and c not in seen:
            seen.add(c)
            out.append(c)
    atomic_write_text(path, "\n".join(out) + "\n")
    return path


def write_cidr_file(root: Path, rule: dict) -> Path:
    """lists/games/<id>.txt - CIDR-файл для --ipset одного UDP-правила."""
    root = Path(root)
    folder = root / "lists" / CIDR_DIR
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{rule.get('id') or 'game'}.txt"
    atomic_write_text(path, "\n".join(rule["cidrs"]) + "\n")
    return path


def add_game_domain(root: Path, game_id: str, domain: str) -> tuple[bool, str, bool]:
    """Добавить домен в игру (включённым) - например, из анализа приложения.

    Дубли не добавляются. Возвращает (ok, сообщение, реально добавлено).
    load->save->sync идёт под games_lock: параллельный save/custom не затрёт
    только что добавленный домен (аудит 2026-11-14, T21).
    """
    dom = (domain or "").strip().lower().rstrip(".")
    if not dom:
        return False, "Пустой домен", False
    state = {"added": False}

    def _mutate(data: dict) -> tuple[bool, str, dict]:
        game = next((g for g in (data.get("games") or [])
                     if isinstance(g, dict)
                     and str(g.get("id")) == str(game_id)), None)
        if game is None:
            return False, "Игра не найдена", data
        for d in (game.get("domains") or []):
            if not isinstance(d, dict):
                continue
            if str(d.get("domain", "")).strip().lower() == dom:
                return True, "Домен уже в списке игры", data
        game.setdefault("domains", []).append({
            "domain": dom, "on": True, "warn": False, "tag": "",
            "note": "добавлен из анализа приложения"})
        state["added"] = True
        return True, "Домен добавлен в игру - применяется к новым подключениям", data

    with _GAMES_LOCK:
        ok, message, _data = mutate_games(root, _mutate)  # RLock - вложенный
        if not ok:
            return False, message, False
        if state["added"]:
            try:
                sync_include_list(root)
            except Exception:  # noqa: BLE001 - домен уже сохранён, как раньше
                pass
    return True, message, state["added"]
