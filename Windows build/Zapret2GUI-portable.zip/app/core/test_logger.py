from __future__ import annotations

import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

from core.config import VERSION


class TestLogger:
    """Потокобезопасный логгер тестовой сессии. Пишет человекочитаемый лог в root_dir.

    Лог относится к ОДНОЙ сессии: каждая новая сессия сдвигает прошлый файл
    в test_session.old.log и начинает test_session.log заново. Без этого файл
    рос бесконечно (он открыт на append), а в отчёт попадал весь хвост за все
    прошлые прогоны - тот отчёт, что сдают на разбор, содержал строки
    вчерашних тестов вперемешку с сегодняшними.
    """

    def __init__(self, root_dir: Path, mode: str = "lite"):
        self.root_dir = Path(root_dir)
        self.mode = mode
        self.log_path = self.root_dir / "test_session.log"
        self._lock = threading.Lock()
        self._fh = None
        self._rotate()
        try:
            self._fh = open(self.log_path, "a", encoding="utf-8", errors="replace")
        except OSError:
            self._fh = None
        self._write("=" * 60)
        self._write(f"Zapret2 {VERSION} test session started at {datetime.now().isoformat()}")
        self._write(f"Mode: {mode}")
        self._write("=" * 60)

    def _rotate(self) -> None:
        """Сдвинуть прошлую сессию в .old.log. Молча, логирование не блокируем."""
        try:
            if not self.log_path.exists() or self.log_path.stat().st_size == 0:
                return
            old = self.log_path.with_name("test_session.old.log")
            # Файл может быть занят (зависший прошлый процесс) - тогда
            # дописываем в текущий, лучше лишние строки, чем потеря лог.
            if old.exists():
                old.unlink()
            self.log_path.replace(old)
        except OSError:
            pass

    def _write(self, line: str) -> None:
        if self._fh is None:
            return
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            try:
                self._fh.write(f"[{ts}] {line}\n")
                self._fh.flush()
            except OSError:
                pass

    def progress(self, profile: str, message: str) -> None:
        self._write(f"[{profile}] {message}")

    def log(self, message: str) -> None:
        """Обычная строка лога (служебные шаги вроде остановки службы)."""
        self._write(message)

    def result(self, profile: str, ok_count: int, fail_count: int, success_rate: float,
               provider_hop: Optional[int] = None, provider_ip: str = "") -> None:
        total = ok_count + fail_count
        hop_info = f" hop={provider_hop} ip={provider_ip}" if provider_hop else ""
        self._write(
            f"[{profile}] RESULT {ok_count}/{total} OK ({success_rate:.0f}%){hop_info}"
        )

    def summary(self, current_score: float, naked_score: float, best_score: float,
                best_profile: str = "") -> None:
        self._write("-" * 60)
        self._write("SUMMARY")
        self._write(f"  Current Zapret score: {current_score:.2f}")
        self._write(f"  Naked score:          {naked_score:.2f}")
        self._write(f"  Best Zapret2 score:   {best_score:.2f} ({best_profile})")
        self._write("-" * 60)

    def close(self) -> None:
        self._write(f"Session finished at {datetime.now().isoformat()}")
        self._write("=" * 60)
        with self._lock:
            if self._fh is not None:
                try:
                    self._fh.close()
                except OSError:
                    pass
                self._fh = None