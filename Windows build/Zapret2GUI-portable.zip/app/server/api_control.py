"""api_control.py - запуск/остановка обхода (кнопки «Запустить»/«Стоп»).

Переехало из server.py (аудит #1, Inc C). Соглашение: (ctx, ...) -> dict.
Если служба установлена, «Запустить»/«Стоп» работают через неё (её binPath
с актуальными аргументами), а не голым процессом winws2.

T12 (2026-11-14): кнопка «Перезапустить» на фронтенде - это ДВА запроса
(/api/stop -> пауза 1.2 c -> /api/start). Если stop службы занимает больше
1.2 c, start приходил, пока operation-lock ещё занят, получал «Уже
выполняется» и обход оставался СНЯТЫМ. Теперь stop/start обхода
сериализованы как одна цепочка перезапуска: вторая половина ждёт первую
(до _GATE_WAIT), а повторный start того же профиля, когда обход уже поднят
этим же запуском (<_DEDUPE_WINDOW), не крутит второй stop/start.
"""
from __future__ import annotations

import functools
import threading
import time

from core.proc import kill_image_filtered
from core.service_manager import (is_installed as svc_installed,
                                  start as svc_start, status as svc_status,
                                  stop as svc_stop)
from server import api_service
from server.app_state import (AppContext, checkers_busy, get_config_manager,
                              get_controller, operation_guard, scan_winws_exe,
                              ui_debug)

# Сколько ждать «вторую половину» перезапуска (stop->start). Stop службы
# штатно укладывается в единицы секунд; 12 c - с запасом на медленный SCM.
_GATE_WAIT = 12.0
# Окно дедупликации повторного start (двойной клик/две цепочки restart).
_DEDUPE_WINDOW = 2.5

_bypass_gate = threading.Lock()
_start_guard = threading.Lock()
_last_start_fp = ""
_last_start_at = 0.0


def _bypass_serialized(fn):
    """Провести stop/start обхода через единый gate перезапуска.

    operation_guard внутри остаётся: чужие mutating-операции (тестер, служба,
    обновление) по-прежнему получают ошибку «Уже выполняется», а не ждут."""
    @functools.wraps(fn)
    def wrapper(ctx, *args, **kwargs):
        if not _bypass_gate.acquire(timeout=_GATE_WAIT):
            return {"status": "error",
                    "message": "Перезапуск обхода уже выполняется. "
                               "Дождитесь завершения."}
        try:
            return fn(ctx, *args, **kwargs)
        finally:
            _bypass_gate.release()
    return wrapper


def _start_fingerprint(data: dict) -> str:
    """Отпечаток start-запроса: профиль + переключатели (порядок стабилен)."""
    if not isinstance(data, dict):
        return ""
    keys = ("profile", "game_filter", "discord_voice_mode", "discord_voice",
            "debug", "autohostlist", "ipset_catchall", "fake_blob",
            "discord_alt")
    parts = []
    for key in keys:
        value = data.get(key)
        if isinstance(value, (dict, list)):
            value = repr(value)
        parts.append(f"{key}={value!r}")
    return "|".join(parts)


def _bypass_running() -> bool:
    """Обход уже поднят? (служба/процесс) - для дедупликации restart-кликов."""
    try:
        if svc_installed():
            return svc_status() == "running"
        return bool(get_controller().is_running())
    except Exception:  # noqa: BLE001
        return False


def _is_duplicate_start(fingerprint: str) -> bool:
    """Повторный start того же профиля, когда обход уже поднят (T12)."""
    if not fingerprint:
        return False
    with _start_guard:
        recent = (fingerprint == _last_start_fp
                  and (time.monotonic() - _last_start_at) < _DEDUPE_WINDOW)
    return recent and _bypass_running()


def _remember_start(fingerprint: str) -> None:
    global _last_start_fp, _last_start_at
    with _start_guard:
        _last_start_fp = fingerprint
        _last_start_at = time.monotonic()


@_bypass_serialized
@operation_guard("bypass")
def start_zapret(ctx: AppContext, data: dict) -> dict:
    busy = checkers_busy()
    if busy:
        return {"status": "error", "message": busy}
    payload = data if isinstance(data, dict) else {}
    fingerprint = _start_fingerprint(payload)
    if _is_duplicate_start(fingerprint):
        # Двойной клик «Перезапустить»: вторая цепочка stop->start уже не
        # нужна, обход поднят первой. Не крутим второй stop/start.
        return {"status": "ok",
                "message": "Перезапуск уже выполнен - повторный запрос пропущен"}
    result = _start_zapret_impl(ctx, payload)
    if isinstance(result, dict) and result.get("status") == "ok":
        _remember_start(fingerprint)
    return result


def _start_zapret_impl(ctx: AppContext, data: dict) -> dict:
    z1 = scan_winws_exe()
    if z1["running"]:
        return {"status": "error", "message": "Zapret 1 (winws.exe) запущен. Остановите его перед запуском Zapret 2."}
    if svc_installed():
        # Служба установлена - «Запустить» поднимает службу (её же
        # binPath с актуальными аргументами), а не голый winws2: иначе
        # после сервис-осведомлённого «Стоп» обход оставался ручным.
        from core.service_manager import path_status as svc_path_status
        try:
            ps, ps_msg = svc_path_status()
            if ps == "mismatch":
                return {"status": "error",
                        "message": ("Служба zapret2 принадлежит другой копии "
                                    f"программы: {ps_msg}. Удалите/переустановите "
                                    "службу из той копии, затем повторите.")}
            args, err = api_service.prepare_service_args(
                data if isinstance(data, dict) else {})
            if err:
                return {"status": "error",
                        "message": f"Не удалось собрать аргументы службы: {err}"}
            ok, msg = svc_start(args)
            if ok:
                # Статус отдаёт controller.current_strategy; после сервисного
                # старта он раньше оставался старым, и UI показывал «Запущена
                # «default»», провоцируя лишний restart (F-05, 2026-11-15).
                try:
                    cfg = get_config_manager().load()
                    profile = str((data or {}).get("profile")
                                  or getattr(cfg, "last_profile", "") or "default")
                    get_controller().current_strategy = profile
                except Exception as e:  # noqa: BLE001
                    ui_debug(f"start: strategy update failed: {e}")
            return {"status": "ok" if ok else "error", "message": msg}
        except Exception as e:  # noqa: BLE001
            return {"status": "error",
                    "message": f"Ошибка запуска службы: {type(e).__name__}: {e}"}
    try:
        controller = get_controller()
        profile_name = data.get("profile", "") if isinstance(data, dict) else ""
        cfg = get_config_manager().load()
        ok, msg = controller.start(
            profile_name,
            game_filter_mode=cfg.game_filter_mode,
            discord_voice=cfg.discord_voice,
            discord_voice_mode=cfg.discord_voice_mode,
            fake_blob=cfg.fake_blob,
            winws2_debug=cfg.winws2_debug,
            autohostlist=cfg.autohostlist,
            ipset_catchall=cfg.ipset_catchall,
            discord_alt=cfg.discord_alt,
        )
        return {"status": "ok" if ok else "error", "message": msg}
    except Exception as e:  # noqa: BLE001
        return {"status": "error",
                "message": f"Ошибка запуска: {type(e).__name__}: {e}"}


def _my_winws2_paths() -> set[str]:
    """Пути winws2 ТОЛЬКО этой установки (ревью 18.10: не гасим движок
    второй копии GUI в другом каталоге)."""
    from server.app_state import get_root_dir
    root = get_root_dir()
    return {str(root / "bin" / "winws2.exe"), str(root / "winws2.exe")}


@_bypass_serialized
@operation_guard("bypass")
def stop_zapret(ctx: AppContext) -> dict:
    busy = checkers_busy()
    if busy:
        return {"status": "error", "message": busy}
    try:
        if svc_installed():
            from core.service_manager import path_status as svc_path_status
            ps, ps_msg = svc_path_status()
            if ps == "mismatch":
                return {"status": "error",
                        "message": ("Служба zapret2 принадлежит другой копии "
                                    f"программы: {ps_msg}. Не трогаю её.")}
            # Служба установлена - «Стоп» обязан гасить именно её (sc stop),
            # иначе SCM-recovery поднимет winws2 обратно через ~60 с, а
            # рестарт с /start даст двойной захват (аудит 2026-10).
            ok_s, msg_s = svc_stop()
            if not ok_s:
                return {"status": "error",
                        "message": f"Не удалось остановить службу: {msg_s}"}
            get_controller().stop()
            # Не оставлять «активную стратегию» после остановки службы:
            # иначе /api/status врёт и главная кнопка снова «Применить»
            # (F-04, recheck 2026-11-15).
            try:
                get_controller().current_strategy = None
            except Exception:
                pass
            kill_image_filtered("winws2.exe", _my_winws2_paths(), timeout=6)
            return {"status": "ok",
                    "message": "Обход остановлен (служба zapret2 "
                               "остановлена до следующего запуска)"}
        get_controller().stop()
        kill_image_filtered("winws2.exe", _my_winws2_paths(), timeout=6)
        return {"status": "ok", "message": "Все процессы zapret остановлены"}
    except Exception as e:  # noqa: BLE001
        return {"status": "error",
                "message": f"Ошибка остановки: {type(e).__name__}: {e}"}
