from __future__ import annotations

import base64
import ipaddress
import json
import subprocess
import threading
import time
import winsound
from http import HTTPStatus
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import urlparse, parse_qs

from core.config import ConfigManager, DEFAULT_PROFILE, VERSION
from core.zapret_controller import ZapretController
from core.tester import Zapret2Tester, CDN_PROVIDERS, NAKED_BASELINE_HOSTS, RATED_HOSTS
from core.service_manager import SERVICE_NAME, is_installed as svc_installed, status as svc_status, install as svc_install, remove as svc_remove, start as svc_start, stop as svc_stop
from core.collector import export_data_package
from core.launcher import build_args_from_preset, validate_args
from core.test_logger import TestLogger


CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js":  "application/javascript; charset=utf-8",
    ".json":"application/json; charset=utf-8",
    ".ico": "image/x-icon",
    ".png": "image/png",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".woff2":"font/woff2",
}


# ── Global state ─────────────────────────────────────────────

_root_dir: Optional[Path] = None
_controller: Optional[ZapretController] = None
_tester: Optional[Zapret2Tester] = None
_config_manager: Optional[ConfigManager] = None
_app_token: str = ""
_tester_lock = threading.Lock()

# Streaming diagnostics state (like the tester): running / progress / report.
_diag_lock = threading.Lock()
_diag_state = {"running": False, "progress": "", "report": None, "error": None,
               "started": 0.0}
_server: Optional[HTTPServer] = None


# ── Tester shared state (polling replacement for WebSocket) ──

class TesterState:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.progress_pct = 0
        self.progress_msg = ""
        self.results: list[dict] = []
        self.final_result: Optional[dict] = None
        self.all_results: Optional[list[dict]] = None
        self.error: Optional[str] = None
        self.cancelled = False
        self.action_type: Optional[str] = None
        self.logger: Optional[TestLogger] = None

    def reset(self):
        self.progress_pct = 0
        self.progress_msg = ""
        self.results = []
        self.final_result = None
        self.all_results = None
        self.error = None
        self.cancelled = False
        self.action_type = None
        self.logger = None

    def to_dict(self) -> dict:
        with self.lock:
            return {
                "running": self.running,
                "progress": {"percent": self.progress_pct, "message": self.progress_msg},
                "results": list(self.results),
                "final_result": self.final_result,
                "all_results": self.all_results,
                "error": self.error,
                "cancelled": self.cancelled,
                "action": self.action_type,
            }

    def set_progress(self, pct: int, msg: str) -> None:
        with self.lock:
            self.progress_pct = pct
            self.progress_msg = msg

    def add_result(self, data: dict) -> None:
        with self.lock:
            self.results.append(data)

    def set_final(self, result: dict, all_results: Optional[list[dict]] = None) -> None:
        with self.lock:
            self.final_result = result
            self.all_results = all_results
            self.running = False


_tester_state = TesterState()

# Update-check result cache: one check per application session.
_update_check_cache: Optional[dict] = None


# ── Helpers ──────────────────────────────────────────────────

def get_root_dir() -> Path:
    if _root_dir is None:
        raise RuntimeError("Service not initialised")
    return _root_dir


def _ui_presets() -> list[str]:
    """Профили для GUI: exp-/test-/cand- префиксы — стенды экспериментов и
    кандидатов, пользователь не должен видеть их в интерфейсе."""
    presets_dir = get_root_dir() / "presets"
    if not presets_dir.is_dir():
        return []
    return sorted(
        f.stem for f in presets_dir.glob("*.txt")
        if not f.stem.startswith(("exp-", "test-", "cand-", "_probe"))
    )

def get_controller() -> ZapretController:
    if _controller is None:
        raise RuntimeError("Service not initialised")
    return _controller

def get_config_manager() -> ConfigManager:
    if _config_manager is None:
        raise RuntimeError("Service not initialised")
    return _config_manager

def get_tester() -> Zapret2Tester:
    if _tester is None:
        raise RuntimeError("Service not initialised")
    return _tester


def init(root_dir: Path, token: str = "") -> None:
    global _root_dir, _controller, _tester, _config_manager, _app_token
    _root_dir = root_dir
    _app_token = token
    _config_manager = ConfigManager(root_dir)
    _controller = ZapretController(root_dir, config_manager=_config_manager)
    _tester = Zapret2Tester(root_dir)


def _play_completion_sound() -> None:
    try:
        winsound.PlaySound("SystemNotification", winsound.SND_ALIAS | winsound.SND_ASYNC)
    except Exception:
        pass


def _serialize_result(res) -> dict:
    return {
        "profile": res.profile_name,
        "ok_count": res.ok_count,
        "fail_count": res.fail_count,
        "success_rate": res.success_rate,
        "net_ok_count": res.net_ok_count,
        "net_fail_count": res.net_fail_count,
        "net_total": res.net_total,
        "network_rate": res.network_rate,
        "ping_ok_count": res.ping_ok_count,
        "ping_total": res.ping_total,
        "total_time_ms": res.total_time,
        "provider_hop": res.provider_hop,
        "provider_ip": res.provider_ip,
        "results": [
            {"domain": r.domain, "test_type": r.test_type, "status": r.status,
             "time_ms": r.time_ms, "error": r.error}
            for r in res.results
        ],
    }


def _make_progress_cb(state: TesterState) -> Callable:
    def cb(pct: int, msg: str) -> None:
        with state.lock:
            state.progress_pct = pct
            state.progress_msg = msg
    return cb


def _make_result_cb(state: TesterState, profile: Optional[str] = None) -> Callable:
    def cb(r) -> None:
        is_cdn = r.domain in CDN_PROVIDERS
        payload = {
            "type": "test_result",
            "domain": r.domain,
            "test_type": r.test_type,
            "status": r.status,
            "status_code": r.status_code,
            "time_ms": r.time_ms,
            "error": r.error,
            "cdn_provider": CDN_PROVIDERS.get(r.domain, "") if is_cdn else "",
        }
        if profile:
            payload["profile"] = profile
        state.add_result(payload)
    return cb


def _run_tester(fn):
    with _tester_lock:
        return fn()


def _check_vpn() -> dict:
    result = {"vpn_active": False, "warp_installed": False, "details": ""}
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "$a=Get-NetAdapter -Name 'CloudflareWARP' -ErrorAction SilentlyContinue;"
             "$s=Get-Service 'CloudflareWARP' -ErrorAction SilentlyContinue;"
             "if($a){$as=$a.Status}else{$as='NotFound'};"
             "if($s){$ss=$s.Status}else{$ss='NotFound'};"
             "Write-Output ('ADAPTER='+$as); Write-Output ('SERVICE='+$ss)"],
            capture_output=True, text=True, encoding="oem", errors="replace",
            timeout=8,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        for line in r.stdout.splitlines():
            line = line.strip()
            if line.startswith("ADAPTER="):
                status = line.split("=", 1)[1]
                if status == "Up":
                    result["vpn_active"] = True
                    result["details"] = "CloudflareWARP adapter is Up (активен)"
                elif status != "NotFound":
                    result["warp_installed"] = True
                    result["details"] = "WARP adapter найден, статус: " + status
            elif line.startswith("SERVICE="):
                status = line.split("=", 1)[1]
                if status != "NotFound":
                    result["warp_installed"] = True
                    if not result["details"]:
                        result["details"] = "WARP service найден (" + status + "), адаптер неактивен"
        if result["vpn_active"]:
            result["warp_installed"] = True
    except Exception:
        pass
    return result


def _kill_never_hang(image_names: list[str]) -> None:
    for name in image_names:
        _run_with_timeout_quiet(["taskkill", "/F", "/IM", name], timeout=6.0)


def _svc_was_running() -> bool:
    try:
        from core.service_manager import status as svc_status
        return svc_status() == "running"
    except Exception:
        return False


def _restore_protection_after_naked(z2_was: bool, z1_was: bool, state, svc_was: bool = False) -> str:
    """Restart the protection that was active before the naked test.

    The naked test kills winws/winws2 — leaving the user silently
    unprotected afterwards was a long-standing footgun.  Best effort:
    failures are reported, never raised.
    """
    try:
        if z2_was:
            # Если обход жил в службе — поднимаем службу (sc start с её же
            # binPath), а не голый процесс: иначе после скана служба остаётся
            # «остановлена», хотя winws2 работает вручную.
            if svc_was:
                try:
                    from core.service_manager import start as svc_start
                    ok_s, msg_s = svc_start(None)
                    if ok_s:
                        state.set_progress(99, "Восстанавливаем Zapret 2 (через службу)...")
                        return "Zapret 2 восстановлен через службу"
                except Exception:
                    pass
            cfg = get_config_manager().load()
            profile = cfg.last_profile or DEFAULT_PROFILE
            state.set_progress(99, f"Восстанавливаем Zapret 2 ({profile})...")
            ok, msg = get_controller().start(
                profile,
                game_filter_mode=cfg.game_filter_mode,
                discord_voice=cfg.discord_voice,
                discord_voice_mode=cfg.discord_voice_mode,
                fake_blob=cfg.fake_blob,
                winws2_debug=cfg.winws2_debug,
                autohostlist=cfg.autohostlist,
                ipset_catchall=cfg.ipset_catchall,
            )
            return (f"Zapret 2 восстановлен (пресет {profile})" if ok
                    else f"Не удалось восстановить Zapret 2: {msg}")
        if z1_was:
            cfg = get_config_manager().load()
            strat = cfg.zapret1_last_strategy
            if cfg.zapret1_dir and strat:
                bat = Path(cfg.zapret1_dir) / f"{strat}.bat"
                if bat.exists():
                    state.set_progress(99, f"Восстанавливаем Zapret 1 ({strat})...")
                    subprocess.Popen([str(bat)], cwd=str(bat.parent),
                                     creationflags=subprocess.CREATE_NO_WINDOW)
                    return f"Zapret 1 восстановлен ({strat})"
            return "Zapret 1 не восстановлен (стратегия не настроена)"
    except Exception as e:
        return f"Не удалось восстановить защиту: {e}"


def _run_with_timeout(args: list[str], timeout: float = 8.0) -> subprocess.CompletedProcess:
    try:
        proc = subprocess.Popen(
            args,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True,
            encoding="oem",
            errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        stdout, stderr = proc.communicate(timeout=timeout)
        return subprocess.CompletedProcess(args, proc.returncode, stdout, stderr)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
            proc.wait(timeout=3)
        except (OSError, subprocess.TimeoutExpired):
            pass
        raise


def _run_with_timeout_quiet(args: list[str], timeout: float = 5.0) -> None:
    try:
        _run_with_timeout(args, timeout)
    except Exception:
        pass


def _scan_winws_exe() -> dict:
    pid = 0
    try:
        r = _run_with_timeout(
            ["tasklist", "/FI", "IMAGENAME eq winws.exe", "/FO", "CSV", "/NH"],
            timeout=6.0,
        )
        for line in r.stdout.splitlines():
            parts = [p.strip(' "') for p in line.split(",")]
            if len(parts) >= 2 and parts[0].lower() == "winws.exe":
                pid = int(parts[1])
                break
    except (OSError, subprocess.TimeoutExpired):
        pass
    return {"running": bool(pid), "pid": pid}


# ── Tester action runner (background thread) ─────────────────

# Hosts the user cares about most — shown prominently in the final verdict.
KEY_HOST_LABELS: list[tuple[str, str]] = [
    ("discord.com", "Discord"),
    ("gateway.discord.gg", "Discord (шлюз)"),
    ("www.youtube.com", "YouTube"),
    ("i.ytimg.com", "YouTube CDN"),
]


def _build_recommendation(all_results, naked, sanity: dict) -> dict:
    """Build the final verdict: best strategy by network rate, key-host
    status (Discord/YouTube), and diagnosis when nothing works."""
    if not all_results:
        return {"verdict": "no_data", "message": "Нет результатов тестов", "best_profile": ""}

    best = max(all_results, key=lambda r: (r.network_rate, r.ok_count))
    # «Не пробито» — провалы ЛУЧШЕЙ стратегии, а не объединение по всем
    # пресетам: домен, который пробила другая стратегия, не должен выглядеть
    # нерабочим (union по всем профилям вводил в заблуждение).
    blocked = sorted({r.domain for r in best.results
                      if r.test_type != "ping" and r.status != "OK"})
    net_rate = best.network_rate
    blocked_set = set(blocked)

    same_as_naked = False
    if naked is not None and naked.results:
        naked_ok = {r.domain for r in naked.results if r.status == "OK"}
        prof_ok = {r.domain for r in best.results
                   if r.test_type != "ping" and r.status == "OK"
                   and r.domain in NAKED_BASELINE_HOSTS}
        same_as_naked = (naked_ok == prof_ok)

    dry = sanity.get("dry_run", {})
    profiles_loaded = dry.get("profiles_loaded")
    engine_broken = (not dry.get("ok", True)
                     or (profiles_loaded is not None and profiles_loaded <= 1))
    misses = [c for c in sanity.get("list_coverage", []) if not c.get("covered")]
    # Coverage gaps are NOT a block: the bypass works, but those domains are
    # outside the preset's lists (e.g. random CDN probe hosts).  Report them
    # as a note — never as "не пробито".
    miss_note = ""
    if misses:
        doms = ", ".join(c["domain"] for c in misses[:6])
        if len(misses) > 6:
            doms += f" и ещё {len(misses) - 6}"
        miss_note = (f" (не покрыты списками: {doms} — стратегия к ним не применяется, "
                     "доступность может быть нестабильна)")

    # YouTube over TCP fails on every tested setup due to a known TLS quirk
    # (§17) — the browser reaches it via QUIC, so it is not a real outage.
    # Verdicts are computed ONLY from the complete per-profile results
    # (all domain tests finished), never from streaming rows — no async race.
    youtube_tcp_quirk = blocked_set <= {"www.youtube.com", "redirector.googlevideo.com",
                                        "i.ytimg.com", "youtu.be"}

    # "YouTube works" inference: TCP page blocked, but the YouTube infra
    # (i.ytimg.com thumbnails / youtu.be) is reachable through TLS on the
    # SAME profile run.  On every working setup i.ytimg.com passed; on
    # "nothing got through" setups it is blocked as well.
    yt_tcp_blocked = any(r.domain == "www.youtube.com" and r.test_type != "ping" and r.status != "OK"
                         for r in best.results)
    yt_infra_ok = any(r.domain in ("i.ytimg.com", "youtu.be") and r.test_type != "ping" and r.status == "OK"
                      for r in best.results)
    youtube_quirk_ok = yt_tcp_blocked and yt_infra_ok

    if engine_broken:
        verdict = "engine_broken"
        if profiles_loaded is not None and profiles_loaded <= 1:
            message = (f"⚠ winws2 загрузил только {profiles_loaded} профиль(-я) вместо ожидаемых 4-7 — "
                       "сигнатура старого бага с короткими путями (@lua/@blobs). "
                       "Результаты стратегий недостоверны. Обновите программу и повторите тест.")
        else:
            message = ("⚠ winws2 --dry-run отклонил аргументы: "
                       + ("; ".join(dry.get("errors", [])) or "неизвестная ошибка")
                       + ". Результаты стратегий недостоверны.")
    elif same_as_naked and net_rate < 100:
        verdict = "no_bypass"
        message = ("❌ Все стратегии дали тот же результат, что и голый тест (без защиты). "
                   "Обход не применяется: либо winws2 не перехватывает трафик "
                   "(WinDivert/драйвер, антивирус, Killer NIC), либо DPI блокирует любые попытки. "
                   "Запустите «Диагностику» и сохраните отчёт.")
    elif net_rate >= 100 or (youtube_tcp_quirk and net_rate >= 60):
        verdict = "ok"
        extra = (" YouTube по TCP не доходит — известный TLS-прикол: в браузере "
                 "YouTube работает через QUIC." if youtube_tcp_quirk else "")
        message = f"✅ Лучшая стратегия: {best.profile_name} — {best.net_ok_count}/{best.net_total} доступно.{extra}{miss_note}"
    elif net_rate > 0:
        verdict = "partial"
        message = (f"⚠ Лучшая стратегия: {best.profile_name} — {best.net_ok_count}/{best.net_total} "
                   f"({net_rate:.0f}%). Не пробито: {', '.join(blocked) or '—'}{miss_note}")
    else:
        verdict = "no_bypass"
        message = "❌ Ни одна стратегия не пробила блокировку."

    key_hosts = []
    for domain, label in KEY_HOST_LABELS:
        trs = [r for r in best.results if r.test_type != "ping" and r.domain == domain]
        if trs:
            tr = min(trs, key=lambda r: r.time_ms or 0)
            status = tr.status
            note = ""
            # YouTube TCP is a known false negative — mark it working via QUIC
            # only when the inference holds on the FULL results of this profile.
            if domain == "www.youtube.com" and status != "OK" and youtube_quirk_ok:
                status = "QUIC_OK"
                note = "TCP-проверка неприменима — работает через QUIC"
            key_hosts.append({"domain": domain, "label": label,
                              "status": status, "time_ms": tr.time_ms, "note": note})
        else:
            key_hosts.append({"domain": domain, "label": label,
                              "status": "N/A", "time_ms": 0, "note": ""})

    return {
        "verdict": verdict,
        "message": message,
        "best_profile": best.profile_name,
        "best_network_rate": net_rate,
        "best_ok": best.net_ok_count,
        "best_total": best.net_total,
        "same_as_naked": same_as_naked,
        "blocked_domains": blocked,
        # Домены, чей 000 — известный «прикол», а не блок (YouTube TCP/QUIC):
        # речек спорных доменов (§29) их не перепроверяет и не помечает «заблокирован».
        "quirk_skip": (["www.youtube.com", "redirector.googlevideo.com",
                        "i.ytimg.com", "youtu.be"] if youtube_quirk_ok else []),
        "key_hosts": key_hosts,
        "naked_network_rate": naked.network_rate if naked else None,
        "provider_hop": best.provider_hop,
        "provider_ip": best.provider_ip,
    }


def _recheck_contested(tester, best, rec: dict, progress) -> dict:
    """Речек спорных доменов (§29): вердикт «заблокирован» vs «временно недоступен».

    Пер-хостовых ретраев в _curl_test нет — 000 фиксируется как есть. Спорно то,
    что RATED-домен («популярный, должен работать») не пробился ЛУЧШЕЙ
    стратегией: один общий повтор в конце прогона (naked) отличает транзиентный
    спайк/флак от реального блока. Ожившие на речеке уходят из «не пробито»
    и помечаются «временно недоступен — ретест»; стабильные 000 — «заблокирован».
    """
    best_failed = {r.domain for r in best.results
                   if r.test_type != "ping" and r.status != "OK"}
    # Домены с известным «приколом» (YouTube TCP/QUIC) не спорны — их 000
    # ожидаем, вердикт уже объясняет QUIC-путь (§17).
    skip = set(rec.get("quirk_skip") or [])
    contested = [d for d in RATED_HOSTS if d in best_failed and d not in skip]
    if not contested or tester.shutdown_event.is_set():
        return rec
    progress(98, "Речек спорных доменов...")
    recheck: dict[str, bool] = {}
    try:
        tester._ensure_winws2_dead()
        for r in tester._run_domain_tests(contested, concurrency=8, expand_www=False):
            recheck[r.domain] = (r.status == "OK")
    except Exception:
        recheck = {}
    if not recheck:
        return rec
    temporary = [d for d in contested if recheck.get(d)]
    confirmed = [d for d in contested if not recheck.get(d)]
    note = []
    if temporary:
        note.append("временно недоступен (ретест): " + ", ".join(temporary))
    if confirmed:
        note.append("заблокирован: " + ", ".join(confirmed))
    rec = dict(rec)
    rec["recheck"] = {"temporary": temporary, "blocked": confirmed}
    # Ожившие на речеке уходят из чипов «не пробито».
    rec["blocked_domains"] = [d for d in (rec.get("blocked_domains") or [])
                              if d not in temporary]
    if note:
        rec["message"] = ((rec.get("message") or "").rstrip() + " — " + "; ".join(note))
    return rec


def _run_asn_scan() -> None:
    """ASN-пробы (110 IP): мериют ТСПУ напрямую, БЕЗ нашего десинка в пути.

    Обязателен чистый путь: под десинком замер показывает смесь «ТСПУ +
    наш обман» — SYN DROP могли вызывать мы сами. Защита останавливается
    на время скана и восстанавливается (сервис-осведомлённо)."""
    state = _tester_state
    tester = get_tester()
    svc_was = _svc_was_running()
    z2_was = tester.is_running()
    z1_was = tester._any_winws_running()
    try:
        with state.lock:
            state.reset()
            state.action_type = "asn_scan"
        if z2_was or z1_was:
            state.set_progress(2, "Останавливаем обход (замер чистого пути к ТСПУ)...")
            _kill_never_hang(["winws.exe", "winws2.exe"])
        results = _run_tester(lambda: tester.asn_scan(_make_progress_cb(state)))
        note = ""
        if z2_was or svc_was:
            note = _restore_protection_after_naked(z2_was, z1_was, state, svc_was)
        with state.lock:
            state.final_result = {"type": "asn_scan", "probes": results, "restored": note}
            state.running = False
    except Exception as e:
        with state.lock:
            state.error = str(e)
    finally:
        with state.lock:
            state.running = False


def _run_blob_probe(data: dict) -> None:
    """Перебор TLS-фейк-блобов на короткой батарее. Защита на время прогона
    перезапускается по одному разу на блоб — восстановление сервис-осведомлённое."""
    state = _tester_state
    tester = get_tester()
    try:
        with state.lock:
            state.reset()
            state.action_type = "blob_probe"
        cfg = get_config_manager().load()
        from core.service_manager import is_installed as svc_installed, status as svc_status
        svc_was = svc_installed() and svc_status() == "running"
        z2_was = tester.is_running()
        blobs_dir = get_root_dir() / "blobs"
        keys = sorted(f.stem.removeprefix("tls_clienthello_")
                      for f in blobs_dir.glob("tls_clienthello_*.bin")
                      if not f.stem.removeprefix("tls_clienthello_").endswith("_kyber"))
        if not keys:
            with state.lock:
                state.error = "в blobs/ нет tls_clienthello_*.bin"
            return
        results = _run_tester(lambda: tester.probe_blobs(
            _make_progress_cb(state), keys,
            profile_name=cfg.last_profile or DEFAULT_PROFILE))
        note = ""
        if z2_was or svc_was:
            note = _restore_protection_after_naked(True, False, state, svc_was)
        with state.lock:
            state.final_result = {"type": "blob_probe", "results": results,
                                  "restored": note}
            state.running = False
            return
    except Exception as e:
        with state.lock:
            state.error = str(e)
    finally:
        with state.lock:
            state.running = False


def _run_tester_action(data: dict) -> None:
    action = data.get("action", "")
    state = _tester_state
    known = ("test", "test_profiles", "current", "naked", "cdn_scan",
             "check-winws", "check_vpn", "full_analysis")
    if action not in known:
        with state.lock:
            state.error = f"Неизвестное действие тестера: {action!r}"
            state.running = False
        return
    with state.lock:
        state.running = True
        state.reset()
        state.action_type = action

    tester = get_tester()
    logger = None

    try:
        if action in ("test", "test_profiles", "current", "naked", "cdn_scan",
                       "check-winws", "check_vpn", "full_analysis"):

            # short synchronous checks
            if action == "check-winws":
                info = _scan_winws_exe()
                state.set_final({"type": "check_result", "running": info["running"]})
                state.running = False
                return

            if action == "check_vpn":
                result = _check_vpn()
                state.set_final({"type": "vpn_result", **result})
                state.running = False
                return

            if action == "cdn_scan":
                progress = _make_progress_cb(state)
                result_cb = _make_result_cb(state)
                cfg = get_config_manager().load()
                svc_was = _svc_was_running()
                scan = _run_tester(lambda: tester.scan_cdn_recommendations(
                    progress, result_cb=result_cb,
                    ipset_mode=bool(cfg.ipset_catchall),
                    ab_ipset=True,
                    profile_name=cfg.last_profile or DEFAULT_PROFILE))
                note = ""
                # Скан сам перезапускает защиту (A/B-прогон, naked, верификация) —
                # восстанавливаем всегда, причём через службу, если она жила.
                if scan.naked_done or scan.protection_touched:
                    note = _restore_protection_after_naked(scan.z2_was, scan.z1_was, state, svc_was)
                state.set_final({
                    "type": "cdn_scan",
                    "verdicts": [v.__dict__ for v in scan.verdicts],
                    "naked_done": scan.naked_done,
                    "note": note,
                    "error": scan.error,
                    "ipset_mode": scan.ipset_mode,
                })
                state.running = False
                return

            # actions that need a logger
            mode_map = {
                "test":         "test",
                "test_profiles":"quick",
                "current":      "current",
                "naked":        "naked",
                "full_analysis":"full",
            }
            mode = mode_map.get(action, "test")
            logger = TestLogger(get_root_dir(), mode=mode)
            tester.set_logger(logger)

            progress = _make_progress_cb(state)
            result_cb = _make_result_cb(state)

            if action == "test":
                result = _run_tester(lambda: tester.test_profile(
                    data.get("profile", DEFAULT_PROFILE), progress,
                    tier=data.get("tier", "critical"), result_cb=result_cb,
                    ipset_catchall=bool(get_config_manager().load().ipset_catchall),
                ))
                _play_completion_sound()
                state.set_final(_serialize_result(result))

            elif action == "test_profiles":
                profiles = data.get("profiles", None)
                if not profiles:
                    profiles = _ui_presets() or ["default"]
                # ALWAYS order: default first; auto/custom (generated) last —
                # the user expects the proven strategy to be tested first.
                # (The frontend passes its own list from /api/status — order
                # must be enforced here, not only for the glob path.)
                def _order_key(p: str):
                    if p == "default":
                        return (0, "")
                    if p in ("auto", "custom"):
                        return (2, p)
                    return (1, p)
                profiles = sorted(profiles, key=_order_key)
                # custom генерируется ЭТИМ же тестом: стухшая копия из прошлого
                # запуска бессмысленна (и часто битая) — не тратим на неё прогон;
                # свежая сборка получает одну проверочную сессию ниже.
                profiles = [p for p in profiles if p != "custom"]
                all_results = []
                total = len(profiles)
                _tier = data.get("tier", "critical")
                # Галочка «Использовать IPSets для точности» форсирует ipset-режим
                # на весь прогон независимо от глобального тумблера (A/B сравнение).
                # Тестер гоняет стратегии в текущей конфигурации пользователя
                # (глобальный тоггл «Общий IP-обход»); CDN-механика переехала
                # в отдельную вкладку (скан с A/B по ipset).
                ipset_mode = bool(get_config_manager().load().ipset_catchall)

                # Naked baseline first: detects "strategies do nothing" cases.
                naked_baseline = _run_tester(lambda: tester.run_naked_baseline(
                    _make_progress_cb(state),
                    result_cb=_make_result_cb(state, profile="__naked__"),
                ))
                if naked_baseline is not None:
                    progress(5, f"Голый тест: {naked_baseline.net_ok_count}/{naked_baseline.net_total} доступно")

                for idx, profile_name in enumerate(profiles):
                    if tester.shutdown_event.is_set():
                        break
                    base_pct = 6 + int(idx / total * 94)
                    progress(base_pct, f"Тестируем стратегию {profile_name} ({idx + 1}/{total})...")

                    def _inner_progress(pct: int, msg: str):
                        overall = int(6 + (idx + pct / 100) / total * 94)
                        progress(overall, msg)

                    cb_for_profile = _make_result_cb(state, profile=profile_name)
                    res = _run_tester(
                        lambda pn=profile_name, cb=cb_for_profile: tester.test_profile(
                            pn, _inner_progress, tier=_tier,
                            result_cb=cb,
                            ipset_catchall=ipset_mode)
                    )
                    if res is not None:
                        all_results.append(res)
                        progress(int(6 + (idx + 1) / total * 94),
                                 f"Стратегия {profile_name}: {res.success_rate:.0f}%")
                    else:
                        progress(int(6 + (idx + 1) / total * 94),
                                 f"Стратегия {profile_name}: не запустилась")
                if all_results:
                    best = max(all_results, key=lambda r: (r.network_rate, r.ok_count))
                    blocked = sorted({r.domain for r in best.results
                                      if r.test_type != "ping" and r.status != "OK"})
                    sanity = tester.collect_sanity_info(best.profile_name, blocked)
                    rec = _build_recommendation(all_results, naked_baseline, sanity)
                    final = _serialize_result(best)
                    final["recommendation"] = rec
                    final["sanity"] = sanity
                    final["naked"] = _serialize_result(naked_baseline) if naked_baseline else None

                    # Personal strategy: aggregate the best segment per family
                    # (Discord <- P_a, Google <- P_b, General <- P_c).
                    try:
                        from core.strategy_builder import build_custom
                        from core.launcher import build_args_from_preset, validate_args, write_run_bat
                        results_by_profile = {
                            res.profile_name: [
                                {"domain": r.domain, "status": r.status, "test_type": r.test_type}
                                for r in res.results
                            ]
                            for res in all_results if res
                        }
                        custom = build_custom(get_root_dir(), results_by_profile)
                        if not custom.get("error"):
                            args = build_args_from_preset(
                                get_root_dir(), get_root_dir() / "lua", get_root_dir() / "blobs",
                                get_root_dir() / "presets" / "custom.txt")
                            ok, err = validate_args(get_root_dir() / "bin" / "winws2.exe",
                                                    args, cwd=get_root_dir())
                            custom["valid"] = ok
                            custom["error"] = None if ok else err
                            # --dry-run never opens WinDivert: a preset can be
                            # "valid" yet die at launch (e.g. --in-range without
                            # --wf-tcp-in).  Real 1.5s smoke launch.
                            if ok:
                                try:
                                    import time as _time
                                    bat = get_root_dir() / "_zapret_custom_smoke.bat"
                                    write_run_bat(get_root_dir(), bat,
                                                  get_root_dir() / "bin" / "winws2.exe", args)
                                    # Запускаем батник сами, чтобы знать PID и гасить
                                    # только дерево smoke-процесса: blanket taskkill
                                    # по имени убил бы и чужой/сервисный winws2.
                                    proc = subprocess.Popen(
                                        ["cmd", "/c", str(bat)],
                                        cwd=str(get_root_dir()),
                                        creationflags=subprocess.CREATE_NO_WINDOW,
                                    )
                                    _time.sleep(1.5)
                                    alive = tester.is_running()
                                    try:
                                        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                                                       capture_output=True, timeout=5,
                                                       creationflags=subprocess.CREATE_NO_WINDOW)
                                    except (subprocess.TimeoutExpired, OSError):
                                        pass
                                    # Страховка: winws2 мог отцепиться от cmd-дерева —
                                    # в этот момент любой живой winws2 только наш.
                                    if tester.is_running():
                                        tester._ensure_winws2_dead()
                                    if not alive:
                                        custom["valid"] = False
                                        custom["error"] = ("custom не стартует на реальном запуске "
                                                           "(проверьте --wf-tcp-in/--in-range сегментов)")
                                    try:
                                        bat.unlink()
                                    except OSError:
                                        pass
                                except Exception as e:
                                    custom["valid"] = False
                                    custom["error"] = f"smoke-запуск custom не удался: {e}"
                            src = custom["sources"]
                            custom["summary"] = (
                                "Собрана личная стратегия «custom»: "
                                f"Discord ← {src.get('discord')}, Google ← {src.get('google')}, "
                                f"General ← {src.get('general')} (остальное из default).")
                        final["custom"] = custom
                    except Exception as e:
                        final["custom"] = {"error": str(e), "preset": "custom"}

                    # Собранная custom всегда заслуживает одной проверочной сессии,
                    # прежде чем рекомендовать её (в прогоне её не было).
                    if final.get("custom", {}).get("valid") and not tester.shutdown_event.is_set():
                        progress(98, "Тестируем собранную стратегию custom...")
                        res = _run_tester(
                            lambda: tester.test_profile(
                                "custom", _make_progress_cb(state),
                                tier=_tier, result_cb=_make_result_cb(state, profile="custom"),
                                ipset_catchall=ipset_mode)
                        )
                        if res is not None:
                            all_results.append(res)
                            best = max(all_results, key=lambda r: (r.network_rate, r.ok_count))
                            blocked = sorted({r.domain for r in best.results
                                              if r.test_type != "ping" and r.status != "OK"})
                            sanity = tester.collect_sanity_info(best.profile_name, blocked)
                            rec = _build_recommendation(all_results, naked_baseline, sanity)
                            final = _serialize_result(best)
                            final["recommendation"] = rec
                            final["sanity"] = sanity
                            final["naked"] = _serialize_result(naked_baseline) if naked_baseline else None
                            final["custom"] = custom
                            c_rate = getattr(res, "network_rate", 0.0)
                            if c_rate > best.network_rate + 1e-9:
                                custom["relation"] = "better"
                            elif abs(c_rate - best.network_rate) < 1e-9:
                                custom["relation"] = "equal"
                            else:
                                custom["relation"] = "worse"
                            custom["rate"] = round(c_rate, 1)

                    # ── Речек спорных доменов (§29) ──
                    # Пер-хостовых ретраев в _curl_test нет: 000 фиксируется как
                    # есть, а «популярный домен, который должен работать» и не
                    # пробился лучшей стратегией — спорен. Один общий повтор в
                    # конце прогона отличает транзиентный спайк/флак от блока.
                    rec = _recheck_contested(tester, best, rec, progress)
                    final["recommendation"] = rec

                    _play_completion_sound()
                    state.set_final(final, [_serialize_result(r) for r in all_results])
                else:
                    state.running = False

            elif action == "current":
                winws_info = _scan_winws_exe()
                if not winws_info["running"]:
                    state.set_final({"type": "need_zapret1"})
                    state.running = False
                    return

                state.set_progress(0, "Zapret 1 обнаружен. Тестирование...")
                cur_progress = _make_progress_cb(state)
                cur_result_cb = _make_result_cb(state, profile="__current__")
                cur_result = _run_tester(
                    lambda: tester.test_current_setup(
                        cur_progress, tier=data.get("tier", "critical"),
                        result_cb=cur_result_cb)
                )
                state.set_final({
                    "type": "current_result",
                    **_serialize_result(cur_result),
                })

            elif action == "naked":
                # Remember what protected the user so we can restore it after
                z2_was_running = get_controller().status().running
                z1_was_running = _scan_winws_exe()["running"]
                svc_was_running = _svc_was_running()
                state.set_progress(1, "Останавливаем zapret...")
                _kill_never_hang(["winws.exe", "winws2.exe"])
                state.set_progress(3, "Защита остановлена. Запуск голого теста...")
                naked_result = _run_tester(
                    lambda: tester.test_naked(
                        _make_progress_cb(state), tier=data.get("tier", "critical"),
                        result_cb=result_cb)
                )
                restore_note = _restore_protection_after_naked(
                    z2_was_running, z1_was_running, state, svc_was_running)
                final = {"type": "naked_result", **_serialize_result(naked_result)}
                if restore_note:
                    final["restored"] = restore_note
                state.set_final(final)

            elif action == "full_analysis":
                profiles = data.get("profiles", [DEFAULT_PROFILE])
                _kill_never_hang(["winws.exe", "winws2.exe"])
                time.sleep(0.5)

                from core.full_analyzer import run_full_analysis, AnalyzerEvent

                def _on_event(ev: AnalyzerEvent) -> None:
                    with state.lock:
                        ev.payload["type"] = ev.type
                        if ev.type == "progress":
                            state.progress_pct = ev.payload.get("percent", 0)
                            state.progress_msg = ev.payload.get("message", "")
                        elif ev.type == "test_result":
                            state.results.append(ev.payload)
                        elif ev.type == "intermediate":
                            state.results.append(ev.payload)

                # run_full_analysis сам берёт _tester_lock (нереентерабельный
                # Lock — оборачивать в _run_tester = гарантированный дедлок)
                fa_ipset = bool(get_config_manager().load().ipset_catchall)
                final_all = run_full_analysis(tester, profiles, _tester_lock, on_event=_on_event,
                                              ipset_catchall=fa_ipset)
                
                # Reduce intermediate + progress noise from final poll
                with state.lock:
                    # Clear in-flight results (keep only test_result items)
                    state.results = [r for r in state.results
                                     if r.get("domain") and r.get("status")]
                    state.final_result = {"type": "final", "all_results": final_all}
                    state.all_results = final_all

    except Exception as e:
        with state.lock:
            state.error = str(e)
    finally:
        with state.lock:
            state.running = False
        if logger:
            logger.close()
            tester.set_logger(None)


# ── HTTP Handler ────────────────────────────────────────────

class ZapretHandler(BaseHTTPRequestHandler):

    # Silence default logging
    def log_message(self, fmt, *args):
        pass

    # ── Auth ──

    def _check_token(self) -> bool:
        if _app_token:
            token = self.headers.get("x-app-token", "")
            if token != _app_token:
                self._send_json({"detail": "Forbidden"}, HTTPStatus.FORBIDDEN)
                return False
        return True

    # ── JSON helpers ──

    def _send_json(self, obj: Any, status: int = HTTPStatus.OK) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html: str, status: int = HTTPStatus.OK) -> None:
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path) -> None:
        if not path.is_file():
            self._send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
            return
        body = path.read_bytes()
        ext = path.suffix.lower()
        ctype = CONTENT_TYPES.get(ext, "application/octet-stream")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _parse_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {}

    # ── GET ──

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        # Token check for /api/
        if path.startswith("/api/") and not self._check_token():
            return

        try:
            if path == "/":
                self._handle_index(params)
            elif path == "/api/diagnose/status":
                self._handle_diagnose_status()
            elif path == "/api/config":
                self._handle_get_config()
            elif path == "/api/version":
                self._handle_version()
            elif path == "/api/status":
                self._handle_status()
            elif path == "/api/profiles":
                self._handle_list_profiles()
            elif path == "/api/exclude-list":
                self._handle_get_list("list-exclude-user.txt")
            elif path == "/api/include-list":
                self._handle_get_list("list-include-user.txt")
            elif path == "/api/bundled-domains":
                self._handle_bundled_domains()
            elif path == "/api/fake-blobs":
                self._handle_fake_blobs()
            elif path == "/api/ipset-exclude-list":
                self._handle_get_list("ipset-exclude.txt")
            elif path == "/api/ipset-include-list":
                self._handle_get_list("ipset-include-user.txt")
            elif path == "/api/service/status":
                self._handle_service_status()
            elif path == "/api/zapret1/strategies":
                self._handle_zapret1_strategies()
            elif path == "/api/tester/status":
                self._handle_tester_status()
            elif path == "/api/update-check":
                self._handle_update_check()
            else:
                self._handle_static(path)
        except RuntimeError as e:
            self._send_json({"status": "error", "message": str(e)}, HTTPStatus.SERVICE_UNAVAILABLE)
        except Exception as e:
            self._send_json({"status": "error", "message": str(e)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_index(self, params: dict) -> None:
        frontend = get_root_dir() / "frontend"
        index_path = frontend / "index.html"
        if index_path.exists():
            html = index_path.read_text(encoding="utf-8")
            token = params.get("token", [""])[0]
            html = html.replace("__APP_TOKEN__", token)
            self._send_html(html)
        else:
            self._send_html("<html><body><h1>Frontend not found</h1></body></html>")

    def _handle_get_config(self) -> None:
        cfg = get_config_manager().load()
        self._send_json({"status": "ok", "config": {
            "root_dir": cfg.root_dir,
            "last_profile": cfg.last_profile,
            "zapret1_dir": cfg.zapret1_dir,
            "zapret1_last_strategy": cfg.zapret1_last_strategy,
            "game_filter_mode": cfg.game_filter_mode,
            "discord_voice": cfg.discord_voice,
            "discord_voice_mode": cfg.discord_voice_mode,
            "winws2_debug": cfg.winws2_debug,
            "autohostlist": cfg.autohostlist,
            "ipset_catchall": cfg.ipset_catchall,
        }})

    def _handle_version(self) -> None:
        self._send_json({"status": "ok", "version": VERSION})

    def _handle_status(self) -> None:
        controller = get_controller()
        status = controller.status()
        zapret1 = _scan_winws_exe()
        profiles = _ui_presets()
        self._send_json({
            "status": "ok",
            "zapret": {
                "running": status.running, "pid": status.pid,
                "strategy": status.strategy,
            },
            "zapret1": zapret1,
            "profiles": profiles,
        })

    def _handle_list_profiles(self) -> None:
        profiles = [
            {"name": name, "display_name": name, "description": "", "is_valid": True, "parse_error": "", "warnings": []}
            for name in _ui_presets()
        ]
        self._send_json({"status": "ok", "profiles": profiles})

    def _handle_get_list(self, filename: str) -> None:
        path = get_root_dir() / "lists" / filename
        content = ""
        if path.exists():
            content = path.read_text(encoding="utf-8")
        self._send_json({"status": "ok", "content": content})

    def _handle_fake_blobs(self) -> None:
        """Ключи доступных TLS-фейк-блобов (blobs/tls_clienthello_<key>.bin)."""
        blobs_dir = get_root_dir() / "blobs"
        keys = []
        if blobs_dir.is_dir():
            for f in sorted(blobs_dir.glob("tls_clienthello_*.bin")):
                key = f.stem.removeprefix("tls_clienthello_")
                if key and not key.endswith("_kyber"):
                    keys.append(key)
        self._send_json({"status": "ok", "blobs": keys})

    def _handle_bundled_domains(self) -> None:
        """Домены из наших (не пользовательских) включений — для клиентского
        guard'а приоритетов список/исключение на странице «Списки»."""
        domains: set[str] = set()
        for name in ("list-general.txt", "list-google.txt", "list-discord.txt"):
            f = get_root_dir() / "lists" / name
            if not f.exists():
                continue
            try:
                for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
                    line = line.strip().lower()
                    if line and not line.startswith("#"):
                        domains.add(line)
            except OSError:
                pass
        self._send_json({"status": "ok", "domains": sorted(domains)})

    def _handle_service_status(self) -> None:
        self._send_json({
            "status": "ok",
            "service": SERVICE_NAME,
            "installed": svc_installed(),
            "running": svc_status() == "running",
        })

    def _handle_tester_status(self) -> None:
        self._send_json(_tester_state.to_dict())

    def _handle_zapret1_strategies(self) -> None:
        cfg = get_config_manager().load()
        dir_path = cfg.zapret1_dir
        if not dir_path or not Path(dir_path).is_dir():
            self._send_json({"status": "ok", "strategies": []})
            return
        bats = []
        for f in sorted(Path(dir_path).glob("*.bat")):
            name = f.stem.lower()
            if name == "service": continue
            bats.append({"name": f.stem, "path": str(f)})
        self._send_json({"status": "ok", "strategies": bats})

    def _handle_static(self, path: str) -> None:
        frontend = get_root_dir() / "frontend"
        # /static/... or direct paths like /css/..., /js/...
        rel = path.lstrip("/")
        if rel.startswith("static/"):
            rel = rel[7:]
        file_path = frontend / rel
        # Security: prevent path traversal (is_relative_to — не строковый
        # префикс: sibling-папка frontend2/backup не проходит)
        try:
            file_path = file_path.resolve()
            frontend_resolved = frontend.resolve()
            if not file_path.is_relative_to(frontend_resolved):
                self._send_json({"error": "Forbidden"}, HTTPStatus.FORBIDDEN)
                return
        except (ValueError, OSError):
            self._send_json({"error": "Forbidden"}, HTTPStatus.FORBIDDEN)
            return
        self._send_file(file_path)

    # ── POST ──

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if not self._check_token():
            return

        data = self._parse_body()

        try:
            if path == "/api/config":
                self._handle_save_config(data)
            elif path == "/api/zapret1/save-dir":
                self._handle_zapret1_save_dir(data)
            elif path == "/api/zapret1/start":
                self._handle_zapret1_start(data)
            elif path == "/api/zapret1/stop":
                self._handle_zapret1_stop()
            elif path == "/api/start":
                self._handle_start_zapret(data)
            elif path == "/api/stop":
                self._handle_stop_zapret()
            elif path == "/api/exclude-list":
                self._handle_save_list(data, "list-exclude-user.txt")
            elif path == "/api/include-list":
                self._handle_save_list(data, "list-include-user.txt")
            elif path == "/api/ipset-exclude-list":
                self._handle_save_list(data, "ipset-exclude.txt")
            elif path == "/api/ipset-include-list":
                self._handle_save_list(data, "ipset-include-user.txt")
            elif path == "/api/service/install":
                self._handle_service_install(data)
            elif path == "/api/service/remove":
                self._handle_service_remove()
            elif path == "/api/service/start":
                self._handle_service_start()
            elif path == "/api/service/stop":
                self._handle_service_stop()
            elif path == "/api/diagnose/action":
                self._handle_diagnose_action(data)
            elif path == "/api/diagnose/status":
                self._handle_diagnose_status()
            elif path == "/api/export-report":
                self._handle_export_report(data)
            elif path == "/api/asn-scan":
                self._handle_asn_scan(data)
            elif path == "/api/blob-probe":
                self._handle_blob_probe(data)
            elif path == "/api/tester/action":
                self._handle_tester_action(data)
            elif path == "/api/cdn/recommendation":
                self._handle_cdn_recommendation(data)
            else:
                self._send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
        except RuntimeError as e:
            self._send_json({"status": "error", "message": str(e)}, HTTPStatus.SERVICE_UNAVAILABLE)
        except Exception as e:
            self._send_json({"status": "error", "message": str(e)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_save_config(self, data: dict) -> None:
        cfg = get_config_manager().load()
        if "last_profile" in data: cfg.last_profile = data["last_profile"]
        if "zapret1_dir" in data: cfg.zapret1_dir = data["zapret1_dir"]
        if "game_filter_mode" in data: cfg.game_filter_mode = data["game_filter_mode"]
        if "discord_voice" in data: cfg.discord_voice = bool(data["discord_voice"])
        if "discord_voice_mode" in data:
            mode = str(data["discord_voice_mode"]).lower()
            if mode in ("off", "fake", "udplen"):
                cfg.discord_voice_mode = mode
                cfg.discord_voice = mode != "off"  # совместимость со старыми сборками
        if "winws2_debug" in data: cfg.winws2_debug = bool(data["winws2_debug"])
        if "fake_blob" in data:
            fb = str(data["fake_blob"]).strip()
            if fb and not (get_root_dir() / "blobs" / f"tls_clienthello_{fb}.bin").exists():
                self._send_json({"status": "error", "message": f"неизвестный блоб: {fb}"})
                return
            cfg.fake_blob = fb
        if "autohostlist" in data: cfg.autohostlist = bool(data["autohostlist"])
        if "ipset_catchall" in data: cfg.ipset_catchall = bool(data["ipset_catchall"])
        ok = get_config_manager().save(cfg)
        self._send_json({"status": "ok" if ok else "error"})

    def _handle_zapret1_save_dir(self, data: dict) -> None:
        path = data.get("path", "").strip()
        if not path or not Path(path).is_dir():
            self._send_json({"status": "error", "message": "Укажите существующую папку Zapret 1"})
            return
        cfg = get_config_manager().load()
        cfg.zapret1_dir = path
        get_config_manager().save(cfg)
        self._send_json({"status": "ok", "message": "Путь сохранён"})

    def _handle_zapret1_start(self, data: dict) -> None:
        strategy = data.get("strategy", "").strip()
        if not strategy:
            self._send_json({"status": "error", "message": "Стратегия не указана"})
            return
        controller = get_controller()
        z2 = controller.status()
        if z2.running:
            self._send_json({"status": "error", "message": "Zapret 2 (winws2.exe) запущен. Остановите его перед запуском Zapret 1."})
            return
        cfg = get_config_manager().load()
        dir_path = cfg.zapret1_dir
        if not dir_path:
            self._send_json({"status": "error", "message": "Папка Zapret 1 не указана"})
            return
        bat_path = Path(dir_path) / f"{strategy}.bat"
        if not bat_path.exists():
            self._send_json({"status": "error", "message": f"Файл {strategy}.bat не найден"})
            return
        try:
            subprocess.Popen([str(bat_path)], cwd=str(bat_path.parent),
                             creationflags=subprocess.CREATE_NO_WINDOW)
            cfg.zapret1_last_strategy = strategy
            get_config_manager().save(cfg)
            self._send_json({"status": "ok", "message": f"Zapret 1 запущен: {strategy}.bat"})
        except OSError as e:
            self._send_json({"status": "error", "message": str(e)})

    def _handle_zapret1_stop(self) -> None:
        try:
            subprocess.run(["taskkill", "/F", "/IM", "winws.exe"],
                           capture_output=True, timeout=8,
                           creationflags=subprocess.CREATE_NO_WINDOW)
            self._send_json({"status": "ok", "message": "Zapret 1 остановлен"})
        except (subprocess.TimeoutExpired, OSError) as e:
            self._send_json({"status": "error", "message": str(e)})

    def _handle_start_zapret(self, data: dict) -> None:
        z1 = _scan_winws_exe()
        if z1["running"]:
            self._send_json({"status": "error", "message": "Zapret 1 (winws.exe) запущен. Остановите его перед запуском Zapret 2."})
            return
        controller = get_controller()
        profile_name = data.get("profile", "")
        cfg = get_config_manager().load()
        ok, msg = controller.start(
            profile_name,
            game_filter_mode=cfg.game_filter_mode,
            discord_voice=cfg.discord_voice,
            discord_voice_mode=cfg.discord_voice_mode,
            fake_blob=cfg.fake_blob,
            winws2_debug=cfg.winws2_debug,
            autohostlist=cfg.autohostlist,
            ipset_catchall=cfg.ipset_catchall,
        )
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_stop_zapret(self) -> None:
        get_controller().stop()
        _kill_never_hang(["winws2.exe", "winws.exe"])
        self._send_json({"status": "ok", "message": "Все процессы zapret остановлены"})

    def _handle_save_list(self, data: dict, filename: str) -> None:
        content = data.get("content", "").strip()
        path = get_root_dir() / "lists" / filename
        try:
            path.write_text(content, encoding="utf-8")
            self._send_json({"status": "ok", "message": "Список сохранён"})
        except OSError as e:
            self._send_json({"status": "error", "message": str(e)})

    def _prepare_service_args(self, data: dict) -> tuple[Optional[list[str]], str]:
        """Build + validate the winws2 args for the service (direct-exe style).

        The service runs winws2.exe itself (like Zapret 1), so args are baked
        into binPath and refreshed on install/start — no cmd/bat wrapper.
        """
        cfg = get_config_manager().load()
        profile = data.get("profile") or cfg.last_profile or DEFAULT_PROFILE
        game_filter = data.get("game_filter") or cfg.game_filter_mode or "off"
        voice_mode = (str(data.get("discord_voice_mode") or "").strip().lower()
                      or cfg.discord_voice_mode
                      or ("fake" if data.get("discord_voice", cfg.discord_voice) else "off"))
        discord_voice = voice_mode != "off"
        debug = bool(data.get("debug", cfg.winws2_debug))
        autohostlist = bool(data.get("autohostlist", cfg.autohostlist))
        ipset_catchall = bool(data.get("ipset_catchall", cfg.ipset_catchall))
        root = get_root_dir()
        exe = get_controller().winws2_path
        if exe is None:
            return None, "winws2.exe не найден"
        preset = root / "presets" / f"{profile}.txt"
        if not preset.exists():
            return None, f"Пресет '{profile}.txt' не найден"
        args = build_args_from_preset(root, root / "lua", root / "blobs", preset, debug=debug,
                                       game_filter_mode=game_filter,
                                       discord_voice=discord_voice,
                                       discord_voice_mode=voice_mode,
                                       fake_blob=str(data.get("fake_blob") or cfg.fake_blob or ""),
                                       autohostlist=autohostlist,
                                       ipset_catchall=ipset_catchall)
        ok, err = validate_args(exe, args, cwd=root)
        if not ok:
            return None, err
        return args, ""

    def _handle_service_install(self, data: dict) -> None:
        args, err = self._prepare_service_args(data)
        if err:
            self._send_json({"status": "error", "message": f"Установка отменена — {err}"})
            return
        ok, msg = svc_install(root_dir=get_root_dir(), args=args)
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_service_remove(self) -> None:
        ok, msg = svc_remove()
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_service_start(self) -> None:
        # Refresh binPath with the current args: direct-exe services bake
        # them in, a stale cmdline would silently run an old strategy.
        args, err = self._prepare_service_args({})
        if err:
            self._send_json({"status": "error", "message": f"Служба не запущена — {err}"})
            return
        ok, msg = svc_start(args)
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_service_stop(self) -> None:
        ok, msg = svc_stop()
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_diagnose_action(self, data: dict) -> None:
        import threading as _th
        import time as _time
        from core.diagnostics import run_diagnostics, format_report_text
        # Атомарная отметка «занято» — закрывает окно для параллельного POST.
        with _diag_lock:
            if _diag_state.get("running"):
                self._send_json({"status": "error", "message": "Проверка уже выполняется"})
                return
            _diag_state.update({"running": True, "progress": "", "report": None,
                                "error": None, "started": _time.time()})

        def _worker():
            try:
                def _cb(name):
                    with _diag_lock:
                        _diag_state["progress"] = name
                report = run_diagnostics(get_root_dir(), get_config_manager().load(), progress_cb=_cb)
                report["elapsed_sec"] = round(_time.time() - _diag_state["started"], 1)
                report["report_text"] = format_report_text(report)
                with _diag_lock:
                    _diag_state["report"] = report
            except Exception as e:
                with _diag_lock:
                    _diag_state["error"] = str(e)
            finally:
                with _diag_lock:
                    _diag_state["running"] = False

        _th.Thread(target=_worker, daemon=True).start()
        self._send_json({"status": "ok"})

    def _handle_diagnose_status(self) -> None:
        with _diag_lock:
            self._send_json({"status": "ok", **{k: _diag_state[k] for k in
                                                ("running", "progress", "error")},
                             "report": _diag_state["report"]})

    def _handle_update_check(self) -> None:
        global _update_check_cache
        if _update_check_cache is None:
            from core.updates import check_for_updates
            _update_check_cache = check_for_updates()
        self._send_json({"status": "ok", **_update_check_cache})

    def _handle_export_report(self, data: dict) -> None:
        consent = data.get("consent", False)
        city = data.get("city", "")
        isp = data.get("isp", "")
        vpn_active = data.get("vpn_active", False)
        zapret1_strategy = data.get("zapret1_strategy", "")
        zapret1_filename = data.get("zapret1_filename", "")
        zapret1_cmdline = data.get("zapret1_cmdline", "")
        phase0_results = data.get("phase0_results")
        phase1_results = data.get("phase1_results")
        phase2_results = data.get("phase2_results")
        mode = data.get("mode", "lite")
        root = get_root_dir()

        bat_path = None
        if zapret1_filename and zapret1_strategy:
            # Клиент-контролируемое имя: только базовое имя, без разделителей —
            # иначе запись вне корня (path traversal).
            if Path(zapret1_filename).name != zapret1_filename or any(
                    c in zapret1_filename for c in "/\\:?"):
                self._send_json({"status": "error", "message": "Недопустимое имя файла стратегии"})
                return
            try:
                bat_bytes = base64.b64decode(zapret1_strategy)
                bat_path = root / zapret1_filename
                bat_path.write_bytes(bat_bytes)
                zapret1_strategy = str(bat_path)
            except Exception:
                pass

        ok, path_or_err = export_data_package(
            consent=consent, city=city, isp=isp,
            vpn_active=vpn_active,
            zapret1_strategy=zapret1_strategy,
            root_dir=root, result_dir=root,
            bat_path=bat_path,
            zapret1_cmdline=zapret1_cmdline,
            phase0_results=phase0_results,
            phase1_results=phase1_results,
            phase2_results=phase2_results,
            mode=mode,
        )
        if bat_path and bat_path.exists():
            try:
                bat_path.unlink()
            except OSError:
                pass
        if ok:
            self._send_json({"status": "ok", "file": path_or_err})
        else:
            self._send_json({"status": "error", "message": path_or_err})

    def _handle_asn_scan(self, data: dict) -> None:
        with _tester_state.lock:
            if _tester_state.running:
                self._send_json({"status": "error", "message": "Тестер занят"}, HTTPStatus.CONFLICT)
                return
            _tester_state.running = True
        t = threading.Thread(target=_run_asn_scan, daemon=True)
        t.start()
        self._send_json({"status": "ok"})

    def _handle_blob_probe(self, data: dict) -> None:
        with _tester_state.lock:
            if _tester_state.running:
                self._send_json({"status": "error", "message": "Тестер занят"}, HTTPStatus.CONFLICT)
                return
            _tester_state.running = True
        t = threading.Thread(target=_run_blob_probe, args=(data or {},), daemon=True)
        t.start()
        self._send_json({"status": "ok"})

    def _handle_tester_action(self, data: dict) -> None:
        action = data.get("action", "")
        if action == "cancel":
            get_tester().signal_shutdown()
            with _tester_state.lock:
                _tester_state.cancelled = True
            self._send_json({"status": "ok", "action": "cancelled"})
            return
        # Решение «занят/свободен» принимаем атомарно под локом: отметка
        # running=True здесь же закрывает окно для второго параллельного POST.
        with _tester_state.lock:
            if _tester_state.running:
                self._send_json({"status": "error", "message": "Тестер уже занят — дождитесь завершения"},
                                HTTPStatus.CONFLICT)
                return
            _tester_state.running = True
        t = threading.Thread(target=_run_tester_action, args=(data,), daemon=True)
        t.start()
        self._send_json({"status": "ok", "action": "started"})

    def _handle_cdn_recommendation(self, data: dict) -> None:
        """Полу-автономное применение вердикта без наложений.

        Действия по вердиктам CDN-скана:
        general         — hostlist-режим: домен -> list-general.txt;
                          ipset-режим: IP кандидата -> ipset-include-user.txt
                          (с проверкой пересечения с ipset-exclude.txt).
        exclude         — домен -> list-exclude.txt (hostname-исключение
                          работает в обоих режимах).
        ipset-include   — IP кандидата -> ipset-include-user.txt: точечный
                          IP-обход хоста, который чинится только ipset
                          (A/B «чинит» в hostlist-режиме).
        ipset-exclude   — IP кандидата -> ipset-exclude-user.txt: хост, который
                          ipset ломает, остаётся живым при включённом тоггле
                          (A/B «ломает» в ipset-режиме).
        Затем перезапуск текущего пресета, чтобы изменение вступило в силу.
        """
        domain = (data.get("domain") or "").strip().lower().rstrip(".")
        action = data.get("action", "")
        ips = [str(i).strip() for i in (data.get("ips") or []) if str(i).strip()]
        if not domain or action not in ("general", "exclude", "ipset-include", "ipset-exclude"):
            self._send_json({"status": "error",
                             "message": "Нужны domain и action (general|exclude|ipset-include|ipset-exclude)"})
            return
        cfg = get_config_manager().load()
        ipset_mode = bool(cfg.ipset_catchall)
        # IP-действия: домен не обязателен как цель — работаем по адресам.
        if action in ("ipset-include", "ipset-exclude"):
            fname = "ipset-include-user.txt" if action == "ipset-include" else "ipset-exclude-user.txt"
            path = get_root_dir() / "lists" / fname
            if not ips:
                self._send_json({"status": "error",
                                 "message": "у кандидата нет резолвнутых IP — добавьте вручную"})
                return
            try:
                ip_list = [str(ipaddress.ip_address(i)) for i in ips]
            except ValueError:
                self._send_json({"status": "error", "message": "Некорректный IP в запросе"})
                return
            if action == "ipset-include":
                # Не включать то, что пользователь уже исключил.
                excl_path = get_root_dir() / "lists" / "ipset-exclude.txt"
                excl_extra = get_root_dir() / "lists" / "ipset-exclude-user.txt"
                excl_networks = []
                for ep in (excl_path, excl_extra):
                    if ep.exists():
                        for l in ep.read_text(encoding="utf-8").splitlines():
                            l = l.strip()
                            if l and not l.startswith("#"):
                                try:
                                    excl_networks.append(ipaddress.ip_network(l, strict=False))
                                except ValueError:
                                    pass
                blocked = [ip for ip in ip_list
                           if any(ipaddress.ip_address(ip) in n for n in excl_networks)]
                if blocked:
                    self._send_json({"status": "error",
                                     "message": f"Наложение: {domain} ({', '.join(blocked)}) уже в ipset-исключениях — пропускаем"})
                    return
            existing = set()
            if path.exists():
                existing = {l.strip() for l in path.read_text(encoding="utf-8").splitlines() if l.strip()}
            new_ips = [ip for ip in ip_list if ip not in existing]
            if new_ips:
                with path.open("a", encoding="utf-8") as f:
                    f.write("\n".join(new_ips) + "\n")
            profile = cfg.last_profile or DEFAULT_PROFILE
            ok, msg = get_controller().start(
                profile,
                game_filter_mode=cfg.game_filter_mode,
                discord_voice=cfg.discord_voice,
                discord_voice_mode=cfg.discord_voice_mode,
                fake_blob=cfg.fake_blob,
                winws2_debug=cfg.winws2_debug,
                autohostlist=cfg.autohostlist,
                ipset_catchall=cfg.ipset_catchall,
            )
            if ok:
                self._send_json({"status": "ok",
                                 "message": f"{domain}: {len(new_ips) or 'все'} IP -> {fname}, пресет {profile} перезапущен"})
            else:
                self._send_json({"status": "error",
                                 "message": f"{domain}: IP записаны в {fname}, но перезапуск не удался: {msg}"})
            return
        if action == "exclude":
            fname = "list-exclude.txt"
            path = get_root_dir() / "lists" / fname
            existing = [l.strip().lower() for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
            if domain not in existing:
                with path.open("a", encoding="utf-8") as f:
                    f.write(domain + "\n")
        else:
            if ipset_mode:
                # ipset-режим: list-general заменён на ipset-all — пишем IP
                # кандидата в ipset-include-user; проверка наложений
                fname = "ipset-include-user.txt"
                path = get_root_dir() / "lists" / fname
                if not ips:
                    self._send_json({"status": "error",
                                     "message": "ipset-режим: у кандидата нет резолвнутых IP — добавьте вручную"})
                    return
                try:
                    ip_list = [str(ipaddress.ip_address(i)) for i in ips]
                except ValueError:
                    self._send_json({"status": "error", "message": "Некорректный IP в запросе"})
                    return
                excl_path = get_root_dir() / "lists" / "ipset-exclude.txt"
                excl_networks = []
                if excl_path.exists():
                    for l in excl_path.read_text(encoding="utf-8").splitlines():
                        l = l.strip()
                        if l and not l.startswith("#"):
                            try:
                                excl_networks.append(ipaddress.ip_network(l, strict=False))
                            except ValueError:
                                pass
                blocked = [ip for ip in ip_list
                           if any(ipaddress.ip_address(ip) in n for n in excl_networks)]
                if blocked:
                    self._send_json({"status": "error",
                                     "message": f"Наложение: {domain} ({', '.join(blocked)}) уже в ipset-исключениях — пропускаем"})
                    return
                existing = {l.strip() for l in path.read_text(encoding="utf-8").splitlines() if l.strip()}
                new_ips = [ip for ip in ip_list if ip not in existing]
                if new_ips:
                    with path.open("a", encoding="utf-8") as f:
                        f.write("\n".join(new_ips) + "\n")
            else:
                fname = "list-general.txt"
                path = get_root_dir() / "lists" / fname
                existing = [l.strip().lower() for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
                if domain not in existing:
                    with path.open("a", encoding="utf-8") as f:
                        f.write(domain + "\n")
        profile = cfg.last_profile or DEFAULT_PROFILE
        ok, msg = get_controller().start(
            profile,
            game_filter_mode=cfg.game_filter_mode,
            discord_voice=cfg.discord_voice,
            discord_voice_mode=cfg.discord_voice_mode,
            fake_blob=cfg.fake_blob,
            winws2_debug=cfg.winws2_debug,
            autohostlist=cfg.autohostlist,
            ipset_catchall=cfg.ipset_catchall,
        )
        if ok:
            self._send_json({"status": "ok", "message": f"{domain} → {fname}, пресет {profile} перезапущен"})
        else:
            self._send_json({"status": "error", "message": f"{domain} добавлен в {fname}, но перезапуск не удался: {msg}"})


# ── Server lifecycle ────────────────────────────────────────

class ThreadedHTTPServer(HTTPServer):
    allow_reuse_address = True

    def process_request(self, request, client_address):
        t = threading.Thread(target=self.process_request_thread,
                             args=(request, client_address), daemon=True)
        t.start()

    def process_request_thread(self, request, client_address):
        try:
            self.finish_request(request, client_address)
        except Exception:
            self.handle_error(request, client_address)
        finally:
            self.shutdown_request(request)


def create_server(host: str, port: int) -> ThreadedHTTPServer:
    global _server
    srv = ThreadedHTTPServer((host, port), ZapretHandler)
    _server = srv
    return srv


def stop_server() -> None:
    global _server
    if _server:
        _server.shutdown()
        _server = None
