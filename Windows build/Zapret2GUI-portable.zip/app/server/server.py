from __future__ import annotations

import base64
import ipaddress
import json
import subprocess
import sys
import threading
import time
import winsound
from http import HTTPStatus
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import urlparse, parse_qs

from core.config import ConfigManager, DEFAULT_PROFILE, VERSION
from core.zapret_controller import ZapretController
from core.tester import (Zapret2Tester, CDN_PROVIDERS, NAKED_BASELINE_HOSTS,
                          RATED_HOSTS, QUIC_QUIRK_DOMAINS, CONTROL_DOMAINS)
from core.service_manager import (SERVICE_NAME, is_installed as svc_installed,
                                  status as svc_status, install as svc_install,
                                  remove as svc_remove, start as svc_start,
                                  stop as svc_stop, repair as svc_repair,
                                  pause_recovery, resume_recovery)
from core.collector import export_data_package
from core.launcher import build_args_from_preset, validate_args
from core.test_logger import TestLogger


CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js":  "application/javascript; charset=utf-8",
    ".json":"application/json; charset=utf-8",
    ".ico": "image/x-icon",
    ".png": "image/png",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".woff2":"font/woff2",
}


# ── Глобальное состояние ─────────────────────────────────────

_root_dir: Optional[Path] = None
_controller: Optional[ZapretController] = None
_tester: Optional[Zapret2Tester] = None
_config_manager: Optional[ConfigManager] = None
_app_token: str = ""
_tester_lock = threading.Lock()

# Состояние диагностики (как у тестера): running / progress / report.
_diag_lock = threading.Lock()
_diag_state = {"running": False, "progress": "", "report": None, "error": None,
               "started": 0.0}
_server: Optional[HTTPServer] = None


# ── Общее состояние тестера (polling вместо WebSocket) ──

class TesterState:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.progress_pct = 0
        self.progress_msg = ""
        self.results: list[dict] = []
        self.final_result: Optional[dict] = None
        self.all_results: Optional[list[dict]] = None
        self.error: Optional[str] = None
        self.cancelled = False
        self.action_type: Optional[str] = None
        self.logger: Optional[TestLogger] = None
        # ярлыки завершённых стратегий: UI закрывает их строки при каждом
        # опросе (сообщение «Стратегия X: N%» могло перезаписаться следующим)
        self.completed: list[str] = []
    def reset(self):
        self.progress_pct = 0
        self.progress_msg = ""
        self.results = []
        self.final_result = None
        self.all_results = None
        self.error = None
        self.cancelled = False
        self.action_type = None
        self.logger = None
        self.completed = []

    def to_dict(self) -> dict:
        with self.lock:
            return {
                "running": self.running,
                "progress": {"percent": self.progress_pct, "message": self.progress_msg},
                "results": list(self.results),
                "final_result": self.final_result,
                "all_results": self.all_results,
                "error": self.error,
                "cancelled": self.cancelled,
                "action": self.action_type,
                "completed": list(self.completed),
            }

    def set_progress(self, pct: int, msg: str) -> None:
        with self.lock:
            self.progress_pct = pct
            self.progress_msg = msg

    def add_result(self, data: dict) -> None:
        with self.lock:
            self.results.append(data)

    def set_final(self, result: dict, all_results: Optional[list[dict]] = None) -> None:
        with self.lock:
            self.final_result = result
            self.all_results = all_results
            self.running = False


_tester_state = TesterState()

# Probe сетевой активности процесса (анализ игры/приложения) - singleton
_process_probe = None


def get_process_probe():
    global _process_probe
    if _process_probe is None:
        from core.process_probe import ProcessProbe
        _process_probe = ProcessProbe()
    return _process_probe


def _debug_append(file_name: str, msg: str) -> None:
    """Debug-лог с ротацией (L7): >5MB - старый уходит в .old.log."""
    import datetime as _dt
    try:
        from core.utils import get_temp_dir
        p = get_temp_dir() / file_name
        if p.exists() and p.stat().st_size > 5 * 1024 * 1024:
            try:
                p.replace(p.with_suffix(".old.log"))
            except OSError:
                pass
        with open(p, "a", encoding="utf-8") as f:
            f.write(f"{_dt.datetime.now().strftime('%H:%M:%S.%f')[:-3]} {msg}\n")
    except Exception:
        pass


def _probe_debug(msg: str) -> None:
    """Probe-логи: в консоль (если есть) + в файл (GUI без консоли)."""
    print(f"[probe] {msg}", flush=True)
    _debug_append("probe_debug.log", msg)


def _ui_debug(msg: str) -> None:
    """UI/flow-логи (вкладки, кнопки, сбросы тестера) - ui_debug.log.

    Всегда активен: ловит «выкинуло на главный блок посреди теста»."""
    _debug_append("ui_debug.log", msg)

# Кэш проверки обновлений: одна проверка за сессию приложения.
_update_check_cache: Optional[dict] = None
_update_check_at: float = 0.0
_UPDATE_CHECK_TTL = 6 * 3600  # авто-проверка не чаще раза в 6 часов

# ── Состояние апдейтера (0.8) ───────────────────────────────
_updater_state = {
    "running": False,
    "phase": "",
    "percent": 0,
    "error": None,
    "result": None,   # {applied, backup, service_mismatch, restart_required}
}


def _run_update_worker(kind: str, tag: str, info: dict) -> None:
    """Worker обновления: скачать → бэкап → применить (portable) или
    подготовить self-update (exe) → проверить службу (аргументы устарели?)."""
    from core.updater import (apply_portable, fetch_release_manifest,
                              fetch_update, prepare_exe_update,
                              service_args_stale, validate_release)
    from core.update_verify import verify as verify_signature
    from core.config import ConfigManager
    from core.launcher import build_args_from_preset
    from core.service_manager import (_read_stored_binpath, is_installed as
                                      svc_installed)

    def prog(pct, msg):
        _updater_state["percent"] = pct
        _updater_state["phase"] = msg
        _ui_debug(f"update: {pct}% {msg}")

    # Сброс состояния: повторный прогон не должен видеть error/result прошлого
    _updater_state.update({"running": True, "phase": "проверка подписи",
                           "percent": 0, "error": None, "result": None})
    try:
        root_dir = get_root_dir()
        update_dir = root_dir / "updates"
        update_dir = update_dir if update_dir.is_dir() else _mk(update_dir)

        prog(10, "Проверка подписи обновления…")
        # Fail-closed: без валидной подписи офлайн-ключа обновление не ставим
        manifest_bytes, sig_text = fetch_release_manifest(tag, update_dir)
        if not verify_signature(manifest_bytes, sig_text):
            raise RuntimeError(
                "обновление не прошло проверку подлинности - скачайте версию "
                "вручную с GitHub и сверьте SHA256 из описания релиза")
        try:
            manifest = json.loads(manifest_bytes.decode("utf-8"))
        except Exception:
            raise RuntimeError("манифест обновления повреждён")
        manifest_err = validate_release(manifest, tag, VERSION, kind)
        if manifest_err:
            raise RuntimeError(manifest_err)
        expected = str(manifest["artifacts"][kind]["sha256"]).lower()

        prog(25, "Скачивание обновления…")
        zip_path = fetch_update(kind, tag, update_dir,
                                sha256_expected=expected)

        prog(55, "Резервная копия настроек…")
        result: dict = {"applied": 0, "backup": None,
                        "service_mismatch": False,
                        "signature_verified": True,
                        "restart_required": True}

        if kind == "exe":
            prog(70, "Подготовка замены EXE…")
            bat = prepare_exe_update(
                zip_path, root_dir,
                exe_sha256=manifest["artifacts"]["exe"].get("exe_sha256"))
            result["update_bat"] = str(bat)
            result["restart_required"] = True
        else:
            prog(70, "Применение обновления…")
            applied = apply_portable(zip_path, root_dir,
                                     progress_cb=lambda m: prog(80, str(m)))
            result.update(applied=applied["updated"],
                          skipped_user=applied["skipped_user"],
                          backup=applied["backup"])
            result["restart_required"] = True

        # Служба установлена? Сравнить её аргументы с собранными из НОВЫХ
        # файлов - при расхождении предложить переустановку службы
        prog(95, "Проверка конфигурации службы…")
        if svc_installed():
            cfg = ConfigManager(root_dir).load()
            new_args = build_args_from_preset(
                root_dir, root_dir / "lua", root_dir / "blobs",
                root_dir / "presets" / f"{cfg.last_profile or 'default'}.txt",
                lists_dir=root_dir / "lists",
                windivert_dir=root_dir / "windivert",
                debug=cfg.winws2_debug, game_filter_mode=cfg.game_filter_mode,
                discord_voice=cfg.discord_voice,
                discord_voice_mode=cfg.discord_voice_mode,
                autohostlist=cfg.autohostlist,
                ipset_catchall=cfg.ipset_catchall,
                discord_alt=cfg.discord_alt)
            stored = _read_stored_binpath()
            result["service_mismatch"] = service_args_stale(stored, new_args)
            _ui_debug(f"update: service_mismatch={result['service_mismatch']}")
        else:
            result["service_mismatch"] = False

        prog(100, "Обновление готово")
        _updater_state["result"] = result
    except Exception as e:
        _ui_debug(f"update: EXCEPTION {e}")
        _updater_state["error"] = str(e)[:200]
    finally:
        _updater_state["running"] = False


def _mk(dir_path: Path) -> Path:
    dir_path.mkdir(exist_ok=True)
    return dir_path

# ── Состояние апдейтера (0.8) ───────────────────────────────
_updater_state = {
    "running": False,
    "phase": "",
    "percent": 0,
    "error": None,
    "result": None,   # {applied, backup, service_mismatch, restart_required}
}


# ── Хелперы ──────────────────────────────────────────────────

def get_root_dir() -> Path:
    if _root_dir is None:
        raise RuntimeError("Service not initialised")
    return _root_dir


def _ui_presets() -> list[str]:
    """Профили для GUI: exp-/test-/cand- префиксы - стенды экспериментов и
    кандидатов, пользователь не должен видеть их в интерфейсе."""
    presets_dir = get_root_dir() / "presets"
    if not presets_dir.is_dir():
        return []
    return sorted(
        f.stem for f in presets_dir.glob("*.txt")
        if not f.stem.startswith(("exp-", "test-", "cand-", "_probe"))
    )

def get_controller() -> ZapretController:
    if _controller is None:
        raise RuntimeError("Service not initialised")
    return _controller

def get_config_manager() -> ConfigManager:
    if _config_manager is None:
        raise RuntimeError("Service not initialised")
    return _config_manager

def get_tester() -> Zapret2Tester:
    if _tester is None:
        raise RuntimeError("Service not initialised")
    return _tester


def _checkers_busy() -> Optional[str]:
    """Сообщение о занятости проверки, или None, если всё свободно.
    Тестер (стратегии/CDN/ASN/blob) и диагностика взаимоисключающие; запуск/
    остановка обхода и службы во время проверки тоже запрещены."""
    with _tester_state.lock:
        if _tester_state.running:
            return "Тестер занят - завершите текущую проверку"
    with _diag_lock:
        if _diag_state.get("running"):
            return "Диагностика выполняется - дождитесь завершения"
    return None


# Списки, редактируемые через GUI: нормализуются при старте - BOM/zero-width
# в первой строке не даёт движку сматчить домен/подсеть (кейс 2026-09-14).
_USER_LIST_FILES = ("list-include-user.txt", "list-exclude-user.txt",
                    "ipset-include-user.txt", "ipset-exclude.txt")


def _normalize_user_lists() -> None:
    """Разово чистит user-списки от BOM/zero-width (наследие старых файлов и
    вставок из буфера обмена). Идемпотентно: чистые файлы не перезаписываются."""
    try:
        root = get_root_dir()
    except RuntimeError:
        return
    for name in _USER_LIST_FILES:
        path = root / "lists" / name
        try:
            if not path.exists():
                continue
            decoded = path.read_bytes().decode("utf-8", errors="replace")
            cleaned = _clean_list_text(decoded)
            if cleaned != decoded:
                path.write_text(cleaned, encoding="utf-8")
        except OSError:
            continue


def init(root_dir: Path, token: str = "") -> None:
    global _root_dir, _controller, _tester, _config_manager, _app_token
    _root_dir = Path(root_dir)
    _app_token = token
    _config_manager = ConfigManager(root_dir)
    _controller = ZapretController(root_dir, config_manager=_config_manager)
    _tester = Zapret2Tester(root_dir)
    _normalize_user_lists()


def _play_completion_sound() -> None:
    try:
        winsound.PlaySound("SystemNotification", winsound.SND_ALIAS | winsound.SND_ASYNC)
    except Exception:
        pass


def _serialize_result(res) -> dict:
    return {
        "profile": res.profile_name,
        "ok_count": res.ok_count,
        "fail_count": res.fail_count,
        "success_rate": res.success_rate,
        "net_ok_count": res.net_ok_count,
        "net_fail_count": res.net_fail_count,
        "net_total": res.net_total,
        "network_rate": res.network_rate,
        "ping_ok_count": res.ping_ok_count,
        "ping_total": res.ping_total,
        "total_time_ms": res.total_time,
        "provider_hop": res.provider_hop,
        "provider_ip": res.provider_ip,
        "results": [
            {"domain": r.domain, "test_type": r.test_type, "status": r.status,
             "time_ms": r.time_ms, "error": r.error}
            for r in res.results
        ],
    }


def _make_progress_cb(state: TesterState) -> Callable:
    def cb(pct: int, msg: str) -> None:
        with state.lock:
            state.progress_pct = pct
            state.progress_msg = msg
    return cb


def _make_result_cb(state: TesterState, profile: Optional[str] = None) -> Callable:
    def cb(r) -> None:
        is_cdn = r.domain in CDN_PROVIDERS
        payload = {
            "type": "test_result",
            "domain": r.domain,
            "test_type": r.test_type,
            "status": r.status,
            "status_code": r.status_code,
            "time_ms": r.time_ms,
            "error": r.error,
            "cdn_provider": CDN_PROVIDERS.get(r.domain, "") if is_cdn else "",
            # фронт считает live-счётчики «Хосты» только по этим категориям -
            # чтобы не прыгали (17/17 → 8/8) на финальном network_rate
            "rated": (r.domain not in CONTROL_DOMAINS
                      and r.domain not in QUIC_QUIRK_DOMAINS),
            "control": (r.domain in CONTROL_DOMAINS
                        or (r.domain.startswith("www.") and
                            r.domain[4:] in CONTROL_DOMAINS)),
        }
        if profile:
            payload["profile"] = profile
        state.add_result(payload)
    return cb


def _run_tester(fn):
    with _tester_lock:
        return fn()


def _check_vpn() -> dict:
    result = {"vpn_active": False, "warp_installed": False, "details": ""}
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "$a=Get-NetAdapter -Name 'CloudflareWARP' -ErrorAction SilentlyContinue;"
             "$s=Get-Service 'CloudflareWARP' -ErrorAction SilentlyContinue;"
             "if($a){$as=$a.Status}else{$as='NotFound'};"
             "if($s){$ss=$s.Status}else{$ss='NotFound'};"
             "Write-Output ('ADAPTER='+$as); Write-Output ('SERVICE='+$ss)"],
            capture_output=True, text=True, encoding="oem", errors="replace",
            timeout=8,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        for line in r.stdout.splitlines():
            line = line.strip()
            if line.startswith("ADAPTER="):
                status = line.split("=", 1)[1]
                if status == "Up":
                    result["vpn_active"] = True
                    result["details"] = "CloudflareWARP adapter is Up (активен)"
                elif status != "NotFound":
                    result["warp_installed"] = True
                    result["details"] = "WARP adapter найден, статус: " + status
            elif line.startswith("SERVICE="):
                status = line.split("=", 1)[1]
                if status != "NotFound":
                    result["warp_installed"] = True
                    if not result["details"]:
                        result["details"] = "WARP service найден (" + status + "), адаптер неактивен"
        if result["vpn_active"]:
            result["warp_installed"] = True
    except Exception:
        pass
    return result


def _kill_never_hang(image_names: list[str]) -> None:
    for name in image_names:
        _run_with_timeout_quiet(["taskkill", "/F", "/IM", name], timeout=6.0)


def _svc_was_running() -> bool:
    try:
        from core.service_manager import status as svc_status
        return svc_status() == "running"
    except Exception:
        return False


def _resolve_many(domains: list[str], concurrency: int = 8) -> set[str]:
    """Параллельный резолв набора доменов - protection-множество для
    «какой префикс трогать безопасно» при ipset-правках CDN."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    out: set[str] = set()
    try:
        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            futs = [pool.submit(Zapret2Tester._resolve_ips, d) for d in domains]
            for f in as_completed(futs):
                out.update(f.result())
    except Exception:
        pass
    return out


def _clean_list_text(text: str) -> str:
    """Убирает невидимый мусор (BOM/zero-width), который ломает матчинг
    домена/подсети: прилетает из буфера обмена или из старых файлов с BOM."""
    return text.replace("\ufeff", "").replace("\u200b", "")


def _read_lines(fname: str) -> set[str]:
    """Читает строки списка (без комментариев) в set; отсутствующий файл = пусто."""
    path = get_root_dir() / "lists" / fname
    if not path.exists():
        return set()
    text = _clean_list_text(path.read_text(encoding="utf-8-sig"))
    return {l.strip() for l in text.splitlines() if l.strip()}


def _read_networks(fnames: list[str]) -> list:
    """Читает сети/адреса списков в ipaddress.ip_network (strict=False)."""
    nets = []
    for fname in fnames:
        for l in sorted(_read_lines(fname)):
            if l.startswith("#"):
                continue
            try:
                nets.append(ipaddress.ip_network(l, strict=False))
            except ValueError:
                pass
    return nets


def _plan_cdn_action(domain: str, action: str, ips: list[str],
                     protection: set[str], ipset_mode: bool) -> tuple[bool, str, list[tuple[str, list[str]]]]:
    """Чистое планирование одной CDN-правки без записи на диск.

    Возвращает (ok, err_msg, entries), где entries = [(fname, values)] -
    значения, которые НУЖНО дописать в списки (дедуп по текущему
    содержимому выполнен).  Проверки наложений - как в ручном хендлере:
    ipset-include не включает сети из ipset-exclude[-user], general в
    ipset-режиме пишет сырые IP, ipset-include - префиксы _safe_prefixes
    относительно protection.
    """
    values: list[str] = []
    if action in ("ipset-include", "ipset-exclude"):
        fname = "ipset-include-user.txt" if action == "ipset-include" else "ipset-exclude-user.txt"
        if not ips:
            return False, "у кандидата нет резолвнутых IP - добавьте вручную", []
        try:
            ip_list = [str(ipaddress.ip_address(i)) for i in ips]
        except ValueError:
            return False, "Некорректный IP в запросе", []
        prefixes = Zapret2Tester._safe_prefixes(ip_list, protection)
        if not prefixes:
            return False, f"{domain}: все адреса пересекаются с рабочими IP - пропускаем", []
        if action == "ipset-include":
            blocked = [p for p in prefixes
                       if any(ipaddress.ip_network(p, strict=False).overlaps(n)
                              for n in _read_networks(["ipset-exclude.txt", "ipset-exclude-user.txt"]))]
            if blocked:
                return False, f"Наложение: {domain} ({', '.join(blocked)}) уже в ipset-исключениях - пропускаем", []
        existing = _read_lines(fname)
        values = [p for p in prefixes if p not in existing]
        if not values:
            return True, "уже в списке", []
        return True, "", [(fname, values)]
    if action == "exclude":
        fname = "list-exclude.txt"
        from core import list_health
        cov = list_health.coverage(get_root_dir(), [domain]).get(domain, {})
        if cov.get("excludes"):
            return True, f"уже в исключениях ({', '.join(cov['excludes'])})", []
        existing = _read_lines(fname)
        values = [domain] if domain not in existing else []
        if not values:
            return True, "уже в списке", []
        return True, "", [(fname, values)]
    # action == "general"
    if ipset_mode:
        fname = "ipset-include-user.txt"
        if not ips:
            return False, "ipset-режим: у кандидата нет резолвнутых IP - добавьте вручную", []
        try:
            ip_list = [str(ipaddress.ip_address(i)) for i in ips]
        except ValueError:
            return False, "Некорректный IP в запросе", []
        blocked = [ip for ip in ip_list
                   if any(ipaddress.ip_address(ip) in n
                          for n in _read_networks(["ipset-exclude.txt", "ipset-exclude-user.txt"]))]
        if blocked:
            return False, f"Наложение: {domain} ({', '.join(blocked)}) уже в ipset-исключениях - пропускаем", []
        existing = _read_lines(fname)
        values = [ip for ip in ip_list if ip not in existing]
        if not values:
            return True, "уже в списке", []
        return True, "", [(fname, values)]
    fname = "list-general.txt"
    from core import list_health
    cov = list_health.coverage(get_root_dir(), [domain]).get(domain, {})
    if any(n in list_health.DOMAIN_EXCLUDE_BUNDLED for n in cov.get("excludes", [])):
        return False, (f"{domain} уже в стандартных исключениях - исключение "
                       "сильнее, пропускаем"), []
    if cov.get("includes"):
        return True, f"уже в обходе ({', '.join(cov['includes'])})", []
    existing = _read_lines(fname)
    values = [domain] if domain not in existing else []
    if not values:
        return True, "уже в списке", []
    return True, "", [(fname, values)]


def _restore_protection_after_naked(z2_was: bool, z1_was: bool, state, svc_was: bool = False) -> str:
    """Восстановление защиты, активной до голого теста: naked гасит
    winws/winws2, оставлять пользователя без защиты нельзя.
    Best effort - ошибки возвращаем, не бросаем."""
    try:
        if z2_was:
            # Если обход жил в службе - поднимаем службу (sc start с её же
            # binPath), а не голый процесс: иначе после скана служба остаётся
            # «остановлена», хотя winws2 работает вручную.
            if svc_was:
                try:
                    from core.service_manager import start as svc_start
                    ok_s, msg_s = svc_start(None)
                    if ok_s:
                        state.set_progress(99, "Восстанавливаем Zapret 2 (через службу)...")
                        return "Zapret 2 восстановлен через службу"
                except Exception:
                    pass
            cfg = get_config_manager().load()
            profile = cfg.last_profile or DEFAULT_PROFILE
            state.set_progress(99, f"Восстанавливаем Zapret 2 ({profile})...")
            ok, msg = get_controller().start(
                profile,
                game_filter_mode=cfg.game_filter_mode,
                discord_voice=cfg.discord_voice,
                discord_voice_mode=cfg.discord_voice_mode,
                fake_blob=cfg.fake_blob,
                winws2_debug=cfg.winws2_debug,
                autohostlist=cfg.autohostlist,
                ipset_catchall=cfg.ipset_catchall,
                discord_alt=cfg.discord_alt,
            )
            return (f"Zapret 2 восстановлен (пресет {profile})" if ok
                    else f"Не удалось восстановить Zapret 2: {msg}")
        if z1_was:
            cfg = get_config_manager().load()
            strat = cfg.zapret1_last_strategy
            if cfg.zapret1_dir and strat:
                bat = Path(cfg.zapret1_dir) / f"{strat}.bat"
                if bat.exists():
                    state.set_progress(99, f"Восстанавливаем Zapret 1 ({strat})...")
                    subprocess.Popen([str(bat)], cwd=str(bat.parent),
                                     creationflags=subprocess.CREATE_NO_WINDOW)
                    return f"Zapret 1 восстановлен ({strat})"
            return "Zapret 1 не восстановлен (стратегия не настроена)"
    except Exception as e:
        return f"Не удалось восстановить защиту: {e}"


def _run_with_timeout(args: list[str], timeout: float = 8.0) -> subprocess.CompletedProcess:
    try:
        proc = subprocess.Popen(
            args,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True,
            encoding="oem",
            errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        stdout, stderr = proc.communicate(timeout=timeout)
        return subprocess.CompletedProcess(args, proc.returncode, stdout, stderr)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
            proc.wait(timeout=3)
        except (OSError, subprocess.TimeoutExpired):
            pass
        raise


def _run_with_timeout_quiet(args: list[str], timeout: float = 5.0) -> None:
    try:
        _run_with_timeout(args, timeout)
    except Exception:
        pass


def _scan_winws_exe() -> dict:
    pid = 0
    try:
        r = _run_with_timeout(
            ["tasklist", "/FI", "IMAGENAME eq winws.exe", "/FO", "CSV", "/NH"],
            timeout=6.0,
        )
        for line in r.stdout.splitlines():
            parts = [p.strip(' "') for p in line.split(",")]
            if len(parts) >= 2 and parts[0].lower() == "winws.exe":
                try:
                    pid = int(parts[1])
                except ValueError:
                    continue  # нестандартный вывод tasklist (L1)
                break
    except (OSError, subprocess.TimeoutExpired):
        pass
    return {"running": bool(pid), "pid": pid}


_zapret1_installed_cache: Optional[bool] = None


def _zapret1_installed() -> bool:
    """Zapret 1 есть в системе? (настроенная папка или служба zapret).

    Нужно, чтобы не показывать панель «Zapret 1» тем, у кого его нет.
    Кэшируется на сеанс: службы в рамках сеанса не появляются/исчезают.
    """
    global _zapret1_installed_cache
    if _zapret1_installed_cache is not None:
        return _zapret1_installed_cache
    installed = False
    try:
        cfg = get_config_manager().load()
        installed = bool(cfg.zapret1_dir)
    except Exception:
        installed = False
    if not installed:
        try:
            from core.utils import run_sc
            code, _ = run_sc(["query", "zapret"])
            installed = code == 0
        except Exception:
            installed = False
    _zapret1_installed_cache = installed
    return installed


# ── Запуск действий тестера (фоновый поток) ──────────────────

# Самые важные для пользователя хосты - показываются в финальном вердикте.
KEY_HOST_LABELS: list[tuple[str, str]] = [
    ("discord.com", "Discord"),
    ("gateway.discord.gg", "Discord (шлюз)"),
    ("www.youtube.com", "YouTube"),
    ("i.ytimg.com", "YouTube CDN"),
]


def _build_recommendation(all_results, naked, sanity: dict) -> dict:
    """Финальный вердикт: лучшая стратегия по network_rate, статус ключевых
    хостов (Discord/YouTube), диагноз, если не работает ничего."""
    if not all_results:
        return {"verdict": "no_data", "message": "Нет результатов тестов", "best_profile": ""}

    best = max(all_results, key=lambda r: (r.network_rate, r.net_ok_count))
    # «Не пробито» - провалы ЛУЧШЕЙ стратегии, а не объединение по всем
    # пресетам: домен, который пробила другая стратегия, не должен выглядеть
    # нерабочим (union вводил в заблуждение). QUIC-хосты (youtube-класс) и
    # control-канарейки (google/vk/ya/gosuslugi) вне «не пробито»: их 000 -
    # свойство TCP-пробы сторонним клиентом или мёртвая сеть, не стратегия.
    blocked = sorted({r.domain for r in best.results
                      if r.test_type != "ping" and r.status not in ("OK", "QUIC")
                      and r.domain not in QUIC_QUIRK_DOMAINS
                      and r.domain not in CONTROL_DOMAINS
                      and not (r.domain.startswith("www.")
                               and r.domain[4:] in CONTROL_DOMAINS)})
    net_rate = best.network_rate

    same_as_naked = False
    if naked is not None and naked.results:
        naked_ok = {r.domain for r in naked.results if r.status == "OK"}
        prof_ok = {r.domain for r in best.results
                   if r.test_type != "ping" and r.status == "OK"
                   and r.domain in NAKED_BASELINE_HOSTS}
        same_as_naked = (naked_ok == prof_ok)

    dry = sanity.get("dry_run", {})
    profiles_loaded = dry.get("profiles_loaded")
    engine_broken = (not dry.get("ok", True)
                     or (profiles_loaded is not None and profiles_loaded <= 1))
    misses = [c for c in sanity.get("list_coverage", []) if not c.get("covered")]
    # Пробелы покрытия - НЕ блок: обход работает, но домены вне списков
    # пресета (например, случайные CDN-хосты). Пишем заметкой, не «не пробито».
    miss_note = ""
    if misses:
        doms = ", ".join(c["domain"] for c in misses[:6])
        if len(misses) > 6:
            doms += f" и ещё {len(misses) - 6}"
        miss_note = (f" (не покрыты списками: {doms} - стратегия к ним не применяется, "
                     "доступность может быть нестабильна)")

    # QUIC-хосты (youtube-класс) вне network_rate - ютуб-«прикол» не влияет
    # на вердикт и «не пробито»-чипсы.

    # Равные/почти равные проценты (2026-09-13): при 100/100/100 пользователь
    # не понимает, кого выбирает тестер. Прогон детерминирован (default
    # первым), при полном равенстве побеждает первая протестированная - но
    # это НЕ «эталон»: пресеты равнозначны, для разных сетей лучший бывает
    # разный. ПЛЮС погрешность флаков: 8 хостов - один случайный домен
    # двигает рейтинг на ±12.5%, поэтому стратегии в пределах ±1 домена от
    # лучшей считаются «практически равными» и объясняются так же.
    ranked = sorted(all_results,
                    key=lambda r: (r.network_rate, r.net_ok_count), reverse=True)
    eps_pct = 100.0 / max(best.net_total, 1)
    near_best = [r.profile_name for r in ranked
                 if r.network_rate >= net_rate - eps_pct - 1e-9]
    ties = near_best if len(near_best) > 1 else \
        [r.profile_name for r in all_results
         if abs(r.network_rate - net_rate) < 1e-9]
    tie_note = ""
    if len(ties) > 1:
        tie_note = (f" Практически равный результат (с учётом погрешности "
                    f"прогона ±1 домен) у: {', '.join(ties)} - стратегии "
                    f"равнозначны, рекомендуем {best.profile_name} (первая "
                    "протестированная); если начнёт флакать - переключайтесь "
                    "на другую из списка.")

    # Топ-3 для UI (пользователь видит лучших, а не только рекомендацию)
    top3 = [{"name": r.profile_name, "rate": round(r.network_rate, 1),
             "net_ok": r.net_ok_count, "net_total": r.net_total}
            for r in ranked[:3]]

    if engine_broken:
        verdict = "engine_broken"
        if profiles_loaded is not None and profiles_loaded <= 1:
            message = (f"⚠ winws2 загрузил только {profiles_loaded} профиль(-я) вместо ожидаемых 4-7 - "
                       "сигнатура старого бага с короткими путями (@lua/@blobs). "
                       "Результаты стратегий недостоверны. Обновите программу и повторите тест.")
        else:
            message = ("⚠ winws2 --dry-run отклонил аргументы: "
                       + ("; ".join(dry.get("errors", [])) or "неизвестная ошибка")
                       + ". Результаты стратегий недостоверны.")
    elif same_as_naked and net_rate < 100:
        verdict = "no_bypass"
        message = ("❌ Все стратегии дали тот же результат, что и голый тест (без защиты). "
                   "Обход не применяется: либо winws2 не перехватывает трафик "
                   "(WinDivert/драйвер, антивирус, Killer NIC), либо DPI блокирует любые попытки. "
                   "Запустите «Диагностику» и сохраните отчёт.")
    elif net_rate >= 100:
        verdict = "ok"
        message = f"✅ Лучшая стратегия: {best.profile_name} - {best.net_ok_count}/{best.net_total} доступно.{tie_note}{miss_note}"
    elif net_rate > 0:
        verdict = "partial"
        message = (f"⚠ Лучшая стратегия: {best.profile_name} - {best.net_ok_count}/{best.net_total} "
                   f"({net_rate:.0f}%). Не пробито: {', '.join(blocked) or '-'}{tie_note}{miss_note}")
    else:
        verdict = "no_bypass"
        message = "❌ Ни одна стратегия не пробила блокировку."

    key_hosts = []
    for domain, label in KEY_HOST_LABELS:
        trs = [r for r in best.results if r.test_type != "ping" and r.domain == domain]
        if trs:
            tr = min(trs, key=lambda r: r.time_ms or 0)
            status = tr.status
            note = ""
            # QUIC-класс: TCP-проба сторонним клиентом под десинком не
            # показательная - браузер идёт через QUIC; не красный крест.
            if domain in QUIC_QUIRK_DOMAINS and status not in ("OK",):
                status = "QUIC_OK"
                note = "TCP-проверка неприменима - в браузере работает через QUIC"
            key_hosts.append({"domain": domain, "label": label,
                              "status": status, "time_ms": tr.time_ms, "note": note})
        else:
            key_hosts.append({"domain": domain, "label": label,
                              "status": "N/A", "time_ms": 0, "note": ""})

    return {
        "verdict": verdict,
        "message": message,
        "best_profile": best.profile_name,
        "best_network_rate": net_rate,
        "best_ok": best.net_ok_count,
        "best_total": best.net_total,
        "same_as_naked": same_as_naked,
        "blocked_domains": blocked,
        # Домены, чей 000 - свойство QUIC-пробы, а не блок: речек спорных
        # доменов (§29) их не перепроверяет и не помечает «заблокирован».
        "quirk_skip": ["www.youtube.com", "redirector.googlevideo.com",
                       "i.ytimg.com", "youtu.be"],
        "key_hosts": key_hosts,
        "top3": top3,
        "near_best": ties,
        "naked_network_rate": naked.network_rate if naked else None,
        "provider_hop": best.provider_hop,
        "provider_ip": best.provider_ip,
    }


# Ручной приоритет блобов - по живучести на Т2 (STRATEGY_TRIALS батарея
# блобов 2026-09-11, все ниже проверены 6/6 на discord с repeats=7). Ключи =
# имена файлов blobs/tls_clienthello_<key>.bin. www_google_com - эталон
# (пустой fake_blob в конфиге = как в пресете = google). Новые блобы
# добавлять сюда ПОСЛЕ проверки.
_BLOB_PRIORITY = [
    "www_google_com",        # эталон, по умолчанию
    "sochi_park",            # проверен в бою 2026-09-10 (отвалы) - стабилен как google
    "mail_ru",               # реальный браузерный hello
    "vk_com",                # реальный, 18 расширений, SNI pos 4 - работает
    "iana_org",              # реальный, 13 расширений
    "hcaptcha_com",          # реальный
    "alfabank_ru",           # реальный
    "www_cloudflare_com",    # синтетика make_blob, реальный домен
    "max_ru",                # большой (664), работал в general
    "web_max_ru",            # мелкий, работал в general
]
# Проверено НЕ пробивающие (Т2): example_com - RFC-заглушка, нереальный
# домен; sni2gis/snimail - тестовые артефакты скрещиваний.
_BLOB_STOPLIST = {"example_com", "sni2gis", "snimail"}


def _recommended_blob_keys() -> list[str]:
    """Рекомендованные TLS-фейк-блобы: проверенные на Т2 - в РУЧНОМ порядке
    _BLOB_PRIORITY (живучесть на Т2, батарея блобов). Фильтры: размер ≤700,
    без _kyber, без имени с цифры (баг winws2, AGENTS правило 2), без
    стоп-листа. Неизвестные блобы - в конец по алфавиту, не рекомендованы."""
    blobs_dir = get_root_dir() / "blobs"
    known: dict[str, int] = {}
    others: list[str] = []
    if blobs_dir.is_dir():
        for f in blobs_dir.glob("tls_clienthello_*.bin"):
            key = f.stem.removeprefix("tls_clienthello_")
            if not key or key.endswith("_kyber") or key[0].isdigit():
                continue
            if key in _BLOB_STOPLIST:
                continue
            try:
                if f.stat().st_size > 700:
                    continue
            except OSError:
                continue
            if key in _BLOB_PRIORITY:
                known[key] = _BLOB_PRIORITY.index(key)
            else:
                others.append(key)
    keys = [k for k in sorted(known, key=known.get)]
    keys += sorted(others)
    return keys


def _recheck_contested(tester, best, rec: dict, progress) -> dict:
    """Речек спорных доменов (§29): «заблокирован» vs «временно недоступен».

    В _curl_test пер-хостовых ретраев нет - 000 фиксируется как есть.
    RATED-домен, не пробитый лучшей стратегией, один раз перепроверяется в
    конце прогона: ожившие - «временно недоступен», стабильные 000 -
    «заблокирован». Этап 2 (2026-09-11): перепроверка с альтернативными
    блобами (рекомендованный список, ≤3) - блоб влияет на живучесть у разных
    провайдеров (STRATEGY_TRIALS) - «пробит с блобом X».
    """
    best_failed = {r.domain for r in best.results
                   if r.test_type != "ping" and r.status != "OK"}
    # Домены с известным «приколом» (YouTube TCP/QUIC) не спорны - их 000
    # ожидаем, вердикт уже объясняет QUIC-путь (§17).
    skip = set(rec.get("quirk_skip") or [])
    contested = [d for d in RATED_HOSTS if d in best_failed and d not in skip]
    if not contested or tester.shutdown_event.is_set():
        return rec
    progress(98, "Речек спорных доменов...")
    recheck: dict[str, bool] = {}
    try:
        tester._ensure_winws2_dead()
        for r in tester._run_domain_tests(contested, concurrency=8, expand_www=False):
            recheck[r.domain] = (r.status == "OK")
    except Exception:
        recheck = {}
    if not recheck:
        return rec
    temporary = [d for d in contested if recheck.get(d)]
    confirmed = [d for d in contested if not recheck.get(d)]
    note = []
    if temporary:
        note.append("временно недоступен (ретест): " + ", ".join(temporary))
    if confirmed:
        note.append("заблокирован: " + ", ".join(confirmed))
    rec = dict(rec)
    rec["recheck"] = {"temporary": temporary, "blocked": confirmed}
    # Ожившие на речеке уходят из чипов «не пробито».
    rec["blocked_domains"] = [d for d in (rec.get("blocked_domains") or [])
                              if d not in temporary]
    # ── Этап 2: перепроверка подтверждённо заблокированных с другим блобом ──
    blob_saves: dict[str, str] = {}
    if confirmed and not tester.shutdown_event.is_set():
        progress(99, "Пробуем альтернативные блобы для заблокированных...")
        blob_keys = _recommended_blob_keys()
        # текущий блоб пропускаем - он уже не сработал
        cfg = get_config_manager().load()
        current = cfg.fake_blob or ""
        tried = 0
        for key in blob_keys:
            if key == current or tried >= 3 or tester.shutdown_event.is_set():
                continue
            tried += 1
            ok_domains: list[str] = []
            try:
                tester._ensure_winws2_dead()
                if not tester._run_profile(best.profile_name, fake_blob=key) \
                        or not tester._any_winws2_running():
                    continue
                time.sleep(0.8)
                for r in tester._run_domain_tests(confirmed, concurrency=6,
                                                  expand_www=False):
                    if r.status == "OK":
                        ok_domains.append(r.domain)
            except Exception:
                continue
            finally:
                tester._ensure_winws2_dead()
            if ok_domains:
                for d in ok_domains:
                    blob_saves[d] = key
                remaining = [d for d in confirmed if d not in ok_domains]
                if not remaining:
                    break
                confirmed = remaining
    if blob_saves:
        saved = ["%s → блоб «%s»" % (d, k) for d, k in blob_saves.items()]
        note.append("пробит с блобом: " + "; ".join(saved))
        rec["blocked_domains"] = [d for d in (rec.get("blocked_domains") or [])
                                  if d not in blob_saves]
        rec["blob_saves"] = blob_saves
        rec["recheck"]["blocked"] = [d for d in rec["recheck"]["blocked"]
                                     if d not in blob_saves]
    if note:
        rec["message"] = ((rec.get("message") or "").rstrip() + " - " + "; ".join(note))
    return rec


def _run_asn_scan() -> None:
    """ASN-пробы (110 IP): мериют ТСПУ напрямую, БЕЗ нашего десинка в пути.

    Обязателен чистый путь: под десинком замер показывает смесь «ТСПУ + наш
    обман» - SYN DROP могли вызывать мы сами. Защита останавливается на
    время скана и восстанавливается (сервис-осведомлённо)."""
    state = _tester_state
    tester = get_tester()
    svc_was = _svc_was_running()
    z2_was = tester.is_running()
    z1_was = tester._any_winws_running()
    pause_recovery()  # SCM-перезапуск службового winws2 посреди скана (H3)
    try:
        with state.lock:
            state.reset()
            state.action_type = "asn_scan"
        if z2_was or z1_was:
            state.set_progress(2, "Останавливаем обход (замер чистого пути к ТСПУ)...")
            _kill_never_hang(["winws.exe", "winws2.exe"])
        results = _run_tester(lambda: tester.asn_scan(_make_progress_cb(state)))
        note = ""
        if z2_was or svc_was:
            note = _restore_protection_after_naked(z2_was, z1_was, state, svc_was)
        with state.lock:
            state.final_result = {"type": "asn_scan", "probes": results, "restored": note}
            state.running = False
    except Exception as e:
        with state.lock:
            state.error = str(e)
    finally:
        resume_recovery()
        with state.lock:
            state.running = False


def _run_blob_probe(data: dict) -> None:
    """Перебор TLS-фейк-блобов на короткой батарее. Защита на время прогона
    перезапускается по одному разу на блоб - восстановление
    сервис-осведомлённое."""
    state = _tester_state
    tester = get_tester()
    pause_recovery()  # SCM-перезапуск службового winws2 рушит перебор (H3)
    try:
        with state.lock:
            state.reset()
            state.action_type = "blob_probe"
        cfg = get_config_manager().load()
        from core.service_manager import is_installed as svc_installed, status as svc_status
        svc_was = svc_installed() and svc_status() == "running"
        z2_was = tester.is_running()
        blobs_dir = get_root_dir() / "blobs"
        keys = sorted(f.stem.removeprefix("tls_clienthello_")
                      for f in blobs_dir.glob("tls_clienthello_*.bin")
                      if not f.stem.removeprefix("tls_clienthello_").endswith("_kyber"))
        if not keys:
            with state.lock:
                state.error = "в blobs/ нет tls_clienthello_*.bin"
            return
        results = _run_tester(lambda: tester.probe_blobs(
            _make_progress_cb(state), keys,
            profile_name=cfg.last_profile or DEFAULT_PROFILE))
        note = ""
        if z2_was or svc_was:
            note = _restore_protection_after_naked(True, False, state, svc_was)
        with state.lock:
            state.final_result = {"type": "blob_probe", "results": results,
                                  "restored": note}
            state.running = False
            return
    except Exception as e:
        with state.lock:
            state.error = str(e)
    finally:
        resume_recovery()
        with state.lock:
            state.running = False


def _run_tester_action(data: dict) -> None:
    action = data.get("action", "")
    state = _tester_state
    known = ("test", "test_profiles", "current", "naked", "cdn_scan",
             "check-winws", "check_vpn", "full_analysis")
    if action not in known:
        with state.lock:
            state.error = f"Неизвестное действие тестера: {action!r}"
            state.running = False
        return
    with state.lock:
        state.running = True
        state.reset()
        state.action_type = action
        # гонка cancel→start: cancelled остаётся True от прошлого прогона до
        # reset() в потоке - первый poll (350мс) видел «Тест отменён» (M2)
        state.cancelled = False

    tester = get_tester()
    logger = None
    _ui_debug(f"tester worker: start action={action!r} data={dict(data)}")

    try:
        # Длительные фазы гасят winws2 - SCM-recovery на это время выключается
        # (иначе перезапускает службовый winws2 посреди прогона: конфликт
        # WinDivert, обрыв теста - баг 2026-09-12). ВНУТРИ try: зависший
        # sc.exe не должен уронить поток до входа в try и застревать
        # running=True навсегда (H2).
        if action in ("test", "test_profiles", "naked", "full_analysis", "cdn_scan"):
            try:
                pause_recovery()
            except Exception as _pe:
                _ui_debug(f"pause_recovery failed: {_pe}")

        if action in ("test", "test_profiles", "current", "naked", "cdn_scan",
                       "check-winws", "check_vpn", "full_analysis"):

            # короткие синхронные проверки
            if action == "check-winws":
                info = _scan_winws_exe()
                state.set_final({"type": "check_result", "running": info["running"]})
                state.running = False
                return

            if action == "check_vpn":
                result = _check_vpn()
                state.set_final({"type": "vpn_result", **result})
                state.running = False
                return

            if action == "cdn_scan":
                progress = _make_progress_cb(state)
                result_cb = _make_result_cb(state)
                cfg = get_config_manager().load()
                svc_was = _svc_was_running()
                scan = _run_tester(lambda: tester.scan_cdn_recommendations(
                    progress, result_cb=result_cb,
                    ipset_mode=bool(cfg.ipset_catchall),
                    ab_ipset=True,
                    profile_name=cfg.last_profile or DEFAULT_PROFILE))
                note = ""
                # Скан сам перезапускает защиту (A/B-прогон, naked,
                # верификация) - восстанавливаем всегда, через службу, если
                # она жила.
                if scan.naked_done or scan.protection_touched:
                    note = _restore_protection_after_naked(scan.z2_was, scan.z1_was, state, svc_was)
                state.set_final({
                    "type": "cdn_scan",
                    "verdicts": [v.__dict__ for v in scan.verdicts],
                    "naked_done": scan.naked_done,
                    "note": note,
                    "error": scan.error,
                    "ipset_mode": scan.ipset_mode,
                })
                state.running = False
                return

            # действия, которым нужен логгер
            mode_map = {
                "test":         "test",
                "test_profiles":"quick",
                "current":      "current",
                "naked":        "naked",
                "full_analysis":"full",
            }
            mode = mode_map.get(action, "test")
            logger = TestLogger(get_root_dir(), mode=mode)
            tester.set_logger(logger)

            progress = _make_progress_cb(state)
            result_cb = _make_result_cb(state)

            if action == "test":
                result = _run_tester(lambda: tester.test_profile(
                    data.get("profile", DEFAULT_PROFILE), progress,
                    tier=data.get("tier", "critical"), result_cb=result_cb,
                    ipset_catchall=bool(get_config_manager().load().ipset_catchall),
                ))
                _play_completion_sound()
                state.set_final(_serialize_result(result))

            elif action == "test_profiles":
                profiles = data.get("profiles", None)
                if not profiles:
                    profiles = _ui_presets() or ["default"]
                # Порядок ВСЕГДА: default первым, auto/custom последними -
                # проверенная стратегия должна тестироваться первой (порядок
                # задаём здесь, а не только для glob-пути из /api/status).
                def _order_key(p: str):
                    if p == "default":
                        return (0, "")
                    if p in ("auto", "custom"):
                        return (2, p)
                    return (1, p)
                profiles = sorted(profiles, key=_order_key)
                # custom генерируется ЭТИМ же тестом: стухшая копия из
                # прошлого запуска бессмысленна - не тратим на неё прогон;
                # свежая сборка получает одну проверочную сессию ниже.
                profiles = [p for p in profiles if p != "custom"]
                all_results = []
                alt_params = bool(data.get("alt_params", False))
                # Прогоны: база для всех пресетов; с галочкой - ещё и ALT
                # (справочно: в рекомендацию идут только базовые прогоны).
                runs: list[tuple[str, bool]] = []
                for p in profiles:
                    runs.append((p, False))
                    if alt_params:
                        runs.append((p, True))
                total = len(runs)
                _tier = data.get("tier", "critical")
                # Тестер гоняет стратегии в текущей конфигурации пользователя
                # (глобальный тоггл «Общий IP-обход»); CDN-механика переехала
                # в отдельную вкладку (скан с A/B по ipset).
                ipset_mode = bool(get_config_manager().load().ipset_catchall)

                # Защита, которая была у пользователя ДО прогона, захватывается
                # ДО naked-baseline: тот гасит winws2, и чтение после свеепа
                # всегда даёт False (восстановление становилось мёртвым - H1)
                z2_was = get_controller().status().running
                svc_was = _svc_was_running()

                # Сначала naked-baseline: ловит «стратегии ничего не делают».
                naked_baseline = _run_tester(lambda: tester.run_naked_baseline(
                    _make_progress_cb(state),
                    result_cb=_make_result_cb(state, profile="__naked__"),
                ))
                if naked_baseline is not None:
                    progress(5, f"Голый тест: {naked_baseline.net_ok_count}/{naked_baseline.net_total} доступно")

                for idx, (profile_name, is_alt) in enumerate(runs):
                    if tester.shutdown_event.is_set():
                        break
                    label = f"{profile_name} (ALT)" if is_alt else profile_name
                    progress(int(6 + idx / total * 94),
                             f"Тестируем стратегию {label} ({idx + 1}/{total})...")

                    def _inner_progress(pct: int, msg: str):
                        overall = int(6 + (idx + pct / 100) / total * 94)
                        progress(overall, msg)

                    cb_for_profile = _make_result_cb(state, profile=label)
                    res = _run_tester(
                        lambda pn=profile_name, cb=cb_for_profile, alt=is_alt: tester.test_profile(
                            pn, _inner_progress, tier=_tier,
                            result_cb=cb,
                            ipset_catchall=ipset_mode,
                            discord_alt=alt)
                    )
                    if res is not None:
                        if not is_alt:
                            all_results.append(res)
                        progress(int(6 + (idx + 1) / total * 94),
                                 f"Стратегия {label}: {res.success_rate:.0f}%")
                    else:
                        progress(int(6 + (idx + 1) / total * 94),
                                 f"Стратегия {label}: не запустилась")
                    with state.lock:
                        state.completed.append(label)
                if all_results:
                    best = max(all_results, key=lambda r: (r.network_rate, r.net_ok_count))
                    blocked = sorted({r.domain for r in best.results
                                      if r.test_type != "ping" and r.status != "OK"})
                    sanity = tester.collect_sanity_info(best.profile_name, blocked)
                    rec = _build_recommendation(all_results, naked_baseline, sanity)
                    final = _serialize_result(best)
                    final["recommendation"] = rec
                    final["sanity"] = sanity
                    final["naked"] = _serialize_result(naked_baseline) if naked_baseline else None

                    # Личная стратегия: лучший сегмент на семейство
                    # (Discord ← P_a, Google ← P_b, General ← P_c).
                    try:
                        from core.strategy_builder import build_custom
                        from core.launcher import build_args_from_preset, validate_args
                        results_by_profile = {
                            res.profile_name: [
                                {"domain": r.domain, "status": r.status, "test_type": r.test_type}
                                for r in res.results
                            ]
                            for res in all_results if res
                        }
                        custom = build_custom(get_root_dir(), results_by_profile)
                        _ui_debug(f"custom: built sources={custom.get('sources')} "
                                  f"error={custom.get('error')}")
                        if not custom.get("error"):
                            args = build_args_from_preset(
                                get_root_dir(), get_root_dir() / "lua", get_root_dir() / "blobs",
                                get_root_dir() / "presets" / "custom.txt")
                            ok, err = validate_args(get_root_dir() / "bin" / "winws2.exe",
                                                    args, cwd=get_root_dir())
                            custom["valid"] = ok
                            custom["error"] = None if ok else err
                            _ui_debug(f"custom: validate ok={ok} err={err!r}")
                            # --dry-run не открывает WinDivert: пресет может быть
                            # «валидным», но упасть при запуске (--in-range без
                            # --wf-tcp-in). Реальный smoke-запуск на 1.5 с.
                            if ok:
                                try:
                                    import time as _time
                                    from core.launcher import launch_winws2_direct
                                    # Прямой запуск: PID = сам winws2, гасим
                                    # только его дерево (blanket taskkill убил
                                    # бы чужой/сервисный winws2).
                                    proc, perr = launch_winws2_direct(
                                        get_root_dir(),
                                        get_root_dir() / "bin" / "winws2.exe",
                                        args, timeout=1.5)
                                    if proc is None:
                                        _ui_debug(f"custom: smoke start err={perr!r}")
                                    _time.sleep(1.5)
                                    alive = tester.is_running()
                                    _ui_debug(f"custom: smoke alive={alive}")
                                    if proc is not None and proc.poll() is None:
                                        try:
                                            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                                                           capture_output=True, timeout=5,
                                                           creationflags=subprocess.CREATE_NO_WINDOW)
                                        except (subprocess.TimeoutExpired, OSError):
                                            pass
                                    # Страховка: winws2 мог отцепиться от
                                    # дерева - в этот момент любой живой
                                    # winws2 только наш.
                                    if tester.is_running():
                                        tester._ensure_winws2_dead()
                                    if not alive:
                                        custom["valid"] = False
                                        custom["error"] = ("custom не стартует на реальном запуске "
                                                           "(проверьте --wf-tcp-in/--in-range сегментов)")
                                        _ui_debug("custom: smoke FAILED (winws2 did not stay alive)")
                                except Exception as e:
                                    custom["valid"] = False
                                    custom["error"] = f"smoke-запуск custom не удался: {e}"
                            src = custom["sources"]
                            custom["summary"] = (
                                "Собрана личная стратегия «custom»: "
                                f"Discord ← {src.get('discord')}, Google ← {src.get('google')}, "
                                f"General ← {src.get('general')} (остальное из default).")
                        final["custom"] = custom
                    except Exception as e:
                        final["custom"] = {"error": str(e), "preset": "custom"}

                    # Собранная custom всегда заслуживает одной проверочной
                    # сессии, прежде чем рекомендовать её (в прогоне её не было).
                    if final.get("custom", {}).get("valid") and not tester.shutdown_event.is_set():
                        progress(98, "Тестируем собранную стратегию custom...")
                        res = _run_tester(
                            lambda: tester.test_profile(
                                "custom", _make_progress_cb(state),
                                tier=_tier, result_cb=_make_result_cb(state, profile="custom"),
                                ipset_catchall=ipset_mode)
                        )
                        if res is not None:
                            all_results.append(res)
                            best = max(all_results, key=lambda r: (r.network_rate, r.net_ok_count))
                            blocked = sorted({r.domain for r in best.results
                                              if r.test_type != "ping" and r.status != "OK"})
                            sanity = tester.collect_sanity_info(best.profile_name, blocked)
                            rec = _build_recommendation(all_results, naked_baseline, sanity)
                            final = _serialize_result(best)
                            final["recommendation"] = rec
                            final["sanity"] = sanity
                            final["naked"] = _serialize_result(naked_baseline) if naked_baseline else None
                            final["custom"] = custom
                            c_rate = getattr(res, "network_rate", 0.0)
                            if c_rate > best.network_rate + 1e-9:
                                custom["relation"] = "better"
                            elif abs(c_rate - best.network_rate) < 1e-9:
                                custom["relation"] = "equal"
                            else:
                                custom["relation"] = "worse"
                            custom["rate"] = round(c_rate, 1)

                    # ── Речек спорных доменов (§29) ──
                    # Подробности - в докстринге _recheck_contested.
                    rec = _recheck_contested(tester, best, rec, progress)
                    final["recommendation"] = rec
                    _ui_debug(f"tester: sweep done best={best.profile_name} "
                              f"rate={best.network_rate:.1f}")

                    # Вернуть защиту, которая была у пользователя до теста
                    # (было: после basic-прогона обход пропадал молча).
                    # z2_was/svc_was захвачены В НАЧАЛЕ прогона (до naked),
                    # здесь они уже не читаются - winws2 к этому моменту гашен.
                    if not tester.shutdown_event.is_set():
                        final["restored"] = _restore_protection_after_naked(
                            z2_was, False, state, svc_was)

                    _play_completion_sound()
                    state.set_final(final, [_serialize_result(r) for r in all_results])
                else:
                    state.running = False

            elif action == "current":
                winws_info = _scan_winws_exe()
                if not winws_info["running"]:
                    state.set_final({"type": "need_zapret1"})
                    state.running = False
                    return

                state.set_progress(0, "Zapret 1 обнаружен. Тестирование...")
                cur_progress = _make_progress_cb(state)
                cur_result_cb = _make_result_cb(state, profile="__current__")
                cur_result = _run_tester(
                    lambda: tester.test_current_setup(
                        cur_progress, tier=data.get("tier", "critical"),
                        result_cb=cur_result_cb)
                )
                state.set_final({
                    "type": "current_result",
                    **_serialize_result(cur_result),
                })

            elif action == "naked":
                # Запоминаем, чем был защищён пользователь, чтобы вернуть после
                z2_was_running = get_controller().status().running
                z1_was_running = _scan_winws_exe()["running"]
                svc_was_running = _svc_was_running()
                state.set_progress(1, "Останавливаем zapret...")
                _kill_never_hang(["winws.exe", "winws2.exe"])
                state.set_progress(3, "Защита остановлена. Запуск голого теста...")
                naked_result = _run_tester(
                    lambda: tester.test_naked(
                        _make_progress_cb(state), tier=data.get("tier", "critical"),
                        result_cb=result_cb)
                )
                restore_note = _restore_protection_after_naked(
                    z2_was_running, z1_was_running, state, svc_was_running)
                final = {"type": "naked_result", **_serialize_result(naked_result)}
                if restore_note:
                    final["restored"] = restore_note
                state.set_final(final)

            elif action == "full_analysis":
                profiles = data.get("profiles", [DEFAULT_PROFILE])
                _kill_never_hang(["winws.exe", "winws2.exe"])
                time.sleep(0.5)

                from core.full_analyzer import run_full_analysis, AnalyzerEvent

                def _on_event(ev: AnalyzerEvent) -> None:
                    with state.lock:
                        ev.payload["type"] = ev.type
                        if ev.type == "progress":
                            state.progress_pct = ev.payload.get("percent", 0)
                            state.progress_msg = ev.payload.get("message", "")
                        elif ev.type == "test_result":
                            state.results.append(ev.payload)
                        elif ev.type == "intermediate":
                            state.results.append(ev.payload)

                # run_full_analysis сам берёт _tester_lock (нереентерабельный
                # Lock - оборачивать в _run_tester = гарантированный дедлок)
                fa_ipset = bool(get_config_manager().load().ipset_catchall)
                final_all = run_full_analysis(tester, profiles, _tester_lock, on_event=_on_event,
                                              ipset_catchall=fa_ipset)
                
                # Финальный poll: чистим промежуточные результаты -
                # оставляем только test_result (есть домен и статус)
                with state.lock:
                    state.results = [r for r in state.results
                                     if r.get("domain") and r.get("status")]
                    state.final_result = {"type": "final", "all_results": final_all}
                    state.all_results = final_all

    except Exception as e:
        _ui_debug(f"tester worker: EXCEPTION action={action!r}: {e}")
        with state.lock:
            state.error = str(e)
    finally:
        with state.lock:
            st_err = state.error
            has_final = state.final_result is not None
        _ui_debug(f"tester worker: end action={action!r} error={st_err!r} final={has_final}")
        resume_recovery()
        with state.lock:
            state.running = False
        if logger:
            logger.close()
            tester.set_logger(None)


# ── HTTP-хендлер ────────────────────────────────────────────

class ZapretHandler(BaseHTTPRequestHandler):

    # Глушим штатный лог BaseHTTPRequestHandler
    def log_message(self, fmt, *args):
        pass

    # ── Авторизация ──

    def _host_allowed(self) -> bool:
        """Только loopback-хост: защита от DNS-rebinding (см. do_GET)."""
        host = (self.headers.get("Host") or "").strip().lower()
        if not host:
            return False
        if host.startswith("["):
            name = host.split("]")[0] + "]"
        else:
            name = host.rsplit(":", 1)[0]
        return name in ("127.0.0.1", "localhost", "::1", "[::1]")

    def _check_token(self) -> bool:
        if _app_token:
            token = self.headers.get("x-app-token", "")
            if token != _app_token:
                self._send_json({"detail": "Forbidden"}, HTTPStatus.FORBIDDEN)
                return False
        return True

    # ── JSON-хелперы ──

    def _send_json(self, obj: Any, status: int = HTTPStatus.OK) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html: str, status: int = HTTPStatus.OK) -> None:
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path) -> None:
        if not path.is_file():
            self._send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
            return
        body = path.read_bytes()
        ext = path.suffix.lower()
        ctype = CONTENT_TYPES.get(ext, "application/octet-stream")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        # no-store: локальный HTTP - дёшево; иначе WebView2 кэширует и правки
        # фронтенда не доходят до пользователя после обновления
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _parse_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {}

    # ── GET ──

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        # Защита от DNS-rebinding: сервер локальный, принимаем только
        # loopback-хост. Иначе сторонний сайт мог бы обратиться к нашему
        # порту «как к своему» и вычитать токен из стартовой страницы.
        if not self._host_allowed():
            self.send_error(403, "Forbidden")
            return

        # Проверка токена для /api/
        if path.startswith("/api/") and not self._check_token():
            return

        try:
            if path == "/":
                self._handle_index(params)
            elif path == "/api/diagnose/status":
                self._handle_diagnose_status()
            elif path == "/api/config":
                self._handle_get_config()
            elif path == "/api/version":
                self._handle_version()
            elif path == "/api/app-info":
                self._handle_app_info()
            elif path == "/api/status":
                self._handle_status()
            elif path == "/api/profiles":
                self._handle_list_profiles()
            elif path == "/api/exclude-list":
                self._handle_get_list("list-exclude-user.txt")
            elif path == "/api/include-list":
                self._handle_get_list("list-include-user.txt")
            elif path == "/api/bundled-domains":
                self._handle_bundled_domains()
            elif path == "/api/fake-blobs":
                self._handle_fake_blobs()
            elif path == "/api/ipset-exclude-list":
                self._handle_get_list("ipset-exclude.txt")
            elif path == "/api/ipset-include-list":
                self._handle_get_list("ipset-include-user.txt")
            elif path == "/api/lists/health":
                self._handle_lists_health()
            elif path == "/api/contested/status":
                self._handle_contested_status()
            elif path == "/api/service/status":
                self._handle_service_status()
            elif path == "/api/zapret1/strategies":
                self._handle_zapret1_strategies()
            elif path == "/api/tester/status":
                self._handle_tester_status()
            elif path == "/api/update-check":
                self._handle_update_check(params)
            elif path == "/api/update/status":
                self._handle_update_status()
            elif path == "/api/process-probe/status":
                self._handle_probe_status()
            elif path == "/api/games":
                self._handle_games_get()
            else:
                self._handle_static(path)
        except RuntimeError as e:
            self._send_json({"status": "error", "message": str(e)}, HTTPStatus.SERVICE_UNAVAILABLE)
        except Exception as e:
            _probe_debug(f"api 500 GET {path}: {e}")
            self._send_json({"status": "error", "message": str(e)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_index(self, params: dict) -> None:
        frontend = get_root_dir() / "frontend"
        index_path = frontend / "index.html"
        if index_path.exists():
            html = index_path.read_text(encoding="utf-8")
            token = params.get("token", [""])[0]
            html = html.replace("__APP_TOKEN__", token)
            # Кэш-buster: версия по mtime app.js / app.css - WebView2
            # кэширует статику, свежие правки не доходили (случай 2026-09-12)
            try:
                js_mtime = int((frontend / "js" / "app.js").stat().st_mtime)
                html = html.replace("js/app.js", f"js/app.js?v={js_mtime}")
            except OSError:
                pass
            try:
                css_mtime = int((frontend / "css" / "app.css").stat().st_mtime)
                html = html.replace("css/app.css", f"css/app.css?v={css_mtime}")
            except OSError:
                pass
            self._send_html(html)
        else:
            self._send_html("<html><body><h1>Frontend not found</h1></body></html>")

    def _handle_get_config(self) -> None:
        cfg = get_config_manager().load()
        self._send_json({"status": "ok", "config": {
            "root_dir": cfg.root_dir,
            "last_profile": cfg.last_profile,
            "zapret1_dir": cfg.zapret1_dir,
            "zapret1_last_strategy": cfg.zapret1_last_strategy,
            "game_filter_mode": cfg.game_filter_mode,
            "discord_voice": cfg.discord_voice,
            "discord_voice_mode": cfg.discord_voice_mode,
            "winws2_debug": cfg.winws2_debug,
            "autohostlist": cfg.autohostlist,
            "ipset_catchall": cfg.ipset_catchall,
            "discord_alt": cfg.discord_alt,
            "tour_done": cfg.tour_done,
            "notice_done": cfg.notice_done,
        }})

    def _handle_version(self) -> None:
        self._send_json({"status": "ok", "version": VERSION})

    def _handle_app_info(self) -> None:
        """Техническая информация: версия, тип сборки, SHA256 exe, ключ OTA."""
        import hashlib
        from core import update_verify
        from core.utils import app_root
        info = {"version": VERSION,
                "frozen": bool(getattr(sys, "frozen", False)),
                "path": str(app_root()),
                "update_key": update_verify.pubkey_fingerprint(),
                "exe_sha256": ""}
        if info["frozen"]:
            try:
                h = hashlib.sha256()
                with open(sys.executable, "rb") as f:
                    for chunk in iter(lambda: f.read(1 << 20), b""):
                        h.update(chunk)
                info["exe_sha256"] = h.hexdigest()
            except OSError:
                pass
        self._send_json({"status": "ok", "info": info})

    def _handle_status(self) -> None:
        controller = get_controller()
        status = controller.status()
        zapret1 = _scan_winws_exe()
        profiles = _ui_presets()
        self._send_json({
            "status": "ok",
            "zapret": {
                "running": status.running, "pid": status.pid,
                "strategy": status.strategy,
            },
            "zapret1": {**zapret1, "installed": _zapret1_installed()},
            "profiles": profiles,
        })

    def _handle_list_profiles(self) -> None:
        profiles = [
            {"name": name, "display_name": name, "description": "", "is_valid": True, "parse_error": "", "warnings": []}
            for name in _ui_presets()
        ]
        self._send_json({"status": "ok", "profiles": profiles})

    def _handle_get_list(self, filename: str) -> None:
        path = get_root_dir() / "lists" / filename
        content = ""
        if path.exists():
            # utf-8-sig: не тащим BOM (Notepad) в текстовое поле - иначе он
            # станет частью первой строки и сломает матчинг домена/подсети.
            content = path.read_text(encoding="utf-8-sig")
        self._send_json({"status": "ok", "content": content})

    def _handle_fake_blobs(self) -> None:
        """Ключи доступных TLS-фейк-блобов (blobs/tls_clienthello_<key>.bin).

        Порядок - РУЧНОЙ приоритет _BLOB_PRIORITY (живучесть на Т2, батарея
        блобов 2026-09-11); остальные после по алфавиту. Огромные (>700:
        снижают долю google-фейков) - помечаются. Имена с цифры в начале -
        через префикс (баг winws2, AGENTS правило 2)."""
        blobs_dir = get_root_dir() / "blobs"
        items = []
        if blobs_dir.is_dir():
            for f in blobs_dir.glob("tls_clienthello_*.bin"):
                key = f.stem.removeprefix("tls_clienthello_")
                if not key or key.endswith("_kyber") or key in _BLOB_STOPLIST:
                    continue
                size = f.stat().st_size if f.exists() else 0
                safe = key if not key[0].isdigit() else "blob_" + key
                recommended = key in _BLOB_PRIORITY and size <= 700
                items.append({"key": safe, "size": size, "recommended": recommended,
                              "rank": _BLOB_PRIORITY.index(key) if key in _BLOB_PRIORITY else 999})
        # recommended (по ручному приоритету) → остальные по алфавиту
        items.sort(key=lambda it: (it["rank"] if it["recommended"] else 1000, it["key"]))
        self._send_json({"status": "ok",
                         "blobs": [it["key"] for it in items],
                         "sizes": {it["key"]: it["size"] for it in items},
                         "recommended": [it["key"] for it in items if it["recommended"]]})

    def _handle_bundled_domains(self) -> None:
        """Домены из наших (не пользовательских) включений - для клиентского
        guard'а приоритетов список/исключение на странице «Списки»."""
        domains: set[str] = set()
        for name in ("list-general.txt", "list-google.txt", "list-discord.txt"):
            f = get_root_dir() / "lists" / name
            if not f.exists():
                continue
            try:
                for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
                    line = line.strip().lower()
                    if line and not line.startswith("#"):
                        domains.add(line)
            except OSError:
                pass
        self._send_json({"status": "ok", "domains": sorted(domains)})

    def _handle_service_status(self) -> None:
        self._send_json({
            "status": "ok",
            "service": SERVICE_NAME,
            "installed": svc_installed(),
            "running": svc_status() == "running",
        })

    def _handle_tester_status(self) -> None:
        self._send_json(_tester_state.to_dict())

    def _handle_zapret1_strategies(self) -> None:
        cfg = get_config_manager().load()
        dir_path = cfg.zapret1_dir
        if not dir_path or not Path(dir_path).is_dir():
            self._send_json({"status": "ok", "strategies": []})
            return
        bats = []
        for f in sorted(Path(dir_path).glob("*.bat")):
            name = f.stem.lower()
            if name == "service": continue
            bats.append({"name": f.stem, "path": str(f)})
        self._send_json({"status": "ok", "strategies": bats})

    def _handle_static(self, path: str) -> None:
        frontend = get_root_dir() / "frontend"
        # /static/... или прямые пути (/css/..., /js/...)
        rel = path.lstrip("/")
        if rel.startswith("static/"):
            rel = rel[7:]
        file_path = frontend / rel
        # Защита от path traversal (is_relative_to - не строковый
        # префикс: sibling-папка frontend2/backup не проходит)
        try:
            file_path = file_path.resolve()
            frontend_resolved = frontend.resolve()
            if not file_path.is_relative_to(frontend_resolved):
                self._send_json({"error": "Forbidden"}, HTTPStatus.FORBIDDEN)
                return
        except (ValueError, OSError):
            self._send_json({"error": "Forbidden"}, HTTPStatus.FORBIDDEN)
            return
        self._send_file(file_path)

    # ── POST ──

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if not self._host_allowed():
            self.send_error(403, "Forbidden")
            return

        if not self._check_token():
            return

        data = self._parse_body()
        try:
            if path == "/api/config":
                self._handle_save_config(data)
            elif path == "/api/zapret1/save-dir":
                self._handle_zapret1_save_dir(data)
            elif path == "/api/zapret1/start":
                self._handle_zapret1_start(data)
            elif path == "/api/zapret1/stop":
                self._handle_zapret1_stop()
            elif path == "/api/start":
                self._handle_start_zapret(data)
            elif path == "/api/stop":
                self._handle_stop_zapret()
            elif path == "/api/exclude-list":
                self._handle_save_list(data, "list-exclude-user.txt")
            elif path == "/api/include-list":
                self._handle_save_list(data, "list-include-user.txt")
            elif path == "/api/ipset-exclude-list":
                self._handle_save_list(data, "ipset-exclude.txt")
            elif path == "/api/ipset-include-list":
                self._handle_save_list(data, "ipset-include-user.txt")
            elif path == "/api/contested/toggle":
                self._handle_contested_toggle(data)
            elif path == "/api/contested/check":
                self._handle_contested_check(data)
            elif path == "/api/lists/dedupe":
                self._handle_lists_dedupe()
            elif path == "/api/lists/add-domain":
                self._handle_lists_add_domain(data)
            elif path == "/api/service/install":
                self._handle_service_install(data)
            elif path == "/api/service/remove":
                self._handle_service_remove()
            elif path == "/api/service/start":
                self._handle_service_start()
            elif path == "/api/service/stop":
                self._handle_service_stop()
            elif path == "/api/service/repair":
                self._handle_service_repair()
            elif path == "/api/diagnose/action":
                self._handle_diagnose_action(data)
            elif path == "/api/diagnose/status":
                self._handle_diagnose_status()
            elif path == "/api/export-report":
                self._handle_export_report(data)
            elif path == "/api/asn-scan":
                self._handle_asn_scan(data)
            elif path == "/api/blob-probe":
                self._handle_blob_probe(data)
            elif path == "/api/tester/action":
                self._handle_tester_action(data)
            elif path == "/api/update/start":
                self._handle_update_start()
            elif path == "/api/settings/export":
                self._handle_settings_export()
            elif path == "/api/settings/import":
                self._handle_settings_import(data)
            elif path == "/api/cdn/recommendation":
                self._handle_cdn_recommendation(data)
            elif path == "/api/cdn/apply-all":
                self._handle_cdn_apply_all(data)
            elif path == "/api/process-probe/scan":
                self._handle_probe_scan()
            elif path == "/api/process-probe/start":
                self._handle_probe_start(data)
            elif path == "/api/process-probe/stop":
                self._handle_probe_stop()
            elif path == "/api/process-probe/report":
                self._handle_probe_report()
            elif path == "/api/games/save":
                self._handle_games_save(data)
            elif path == "/api/games/check":
                self._handle_games_check(data)
            elif path == "/api/games/add-domain":
                self._handle_games_add_domain(data)
            elif path == "/api/frontend-log":
                self._handle_probe_debug(data)
            else:
                self._send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
        except RuntimeError as e:
            self._send_json({"status": "error", "message": str(e)}, HTTPStatus.SERVICE_UNAVAILABLE)
        except Exception as e:
            _probe_debug(f"api 500 POST {path}: {e}")
            self._send_json({"status": "error", "message": str(e)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    # ── Probe сетевой активности процессов (игра/приложение) ──
    def _handle_probe_scan(self) -> None:
        """Список процессов с сетью - ТОЛЬКО по явной кнопке (AV-safe)."""
        try:
            from core.process_probe import list_processes
            procs = list_processes()
            self._send_json({"status": "ok", "processes": procs})
        except Exception as e:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            _probe_debug(f"scan: ОШИБКА {e}")
            self._send_json({"status": "error", "message": str(e)})

    def _handle_probe_start(self, data: dict) -> None:
        proc = str(data.get("process") or "").strip()
        if not proc:
            self._send_json({"status": "error",
                             "message": "Укажите имя процесса или PID"})
            return
        try:
            duration = max(10, min(int(data.get("duration") or 60), 300))
        except (TypeError, ValueError):
            duration = 60
        ok, msg = get_process_probe().start(proc, duration)
        if not ok:
            _probe_debug(f"start: FAIL - {msg}")
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_probe_stop(self) -> None:
        st = get_process_probe().stop()
        self._send_json({"status": "ok", "state": st})

    def _handle_probe_debug(self, data: dict) -> None:
        """Frontend-логи (вкладки, кнопки, ошибки JS) - в ui_debug.log."""
        msg = str(data.get("msg") or "")
        if msg:
            _ui_debug(f"frontend: {msg}")
        self._send_json({"status": "ok"})

    def _handle_probe_status(self) -> None:
        self._send_json({"status": "ok", "state": get_process_probe().get_status()})

    def _handle_probe_report(self) -> None:
        probe = get_process_probe()
        path = probe.save_report()
        self._send_json({"status": "ok", "report": probe.report_text(),
                         "path": str(path)})

    def _handle_games_get(self) -> None:
        from core import games as games_store
        self._send_json({"status": "ok",
                         "games": games_store.load_games(get_root_dir())})

    def _handle_games_save(self, data: dict) -> None:
        """Сохранение игровых блокировок: домены применяются сразу (hot-reload
        hostlist), UDP-профили - при следующем запуске/переустановке службы."""
        from core import games as games_store
        payload = data.get("games") if isinstance(data, dict) else None
        if not isinstance(payload, dict) or \
                not isinstance(payload.get("games"), list):
            self._send_json({"status": "error",
                             "message": "некорректные данные"})
            return
        if not games_store.save_games(get_root_dir(), payload):
            self._send_json({"status": "error",
                             "message": "не удалось сохранить"})
            return
        games_store.sync_domain_list(get_root_dir(), payload)
        self._send_json({
            "status": "ok",
            "message": "Сохранено. Домены применятся к новым подключениям; "
                       "UDP-фикс - после перезапуска обхода (службу - "
                       "переустановкой)"})

    def _handle_games_check(self, data: dict) -> None:
        """Проба доменов игры: открываются ли они сейчас (сквозь работающий
        обход, если он запущен). Возвращает код по каждому включённому домену."""
        from core import games as games_store
        game_id = str(data.get("id") or "")
        game = next((g for g in (games_store.load_games(get_root_dir())
                                 .get("games") or [])
                     if str(g.get("id")) == game_id), None)
        if game is None:
            self._send_json({"status": "error", "message": "Игра не найдена"})
            return
        results = []
        for d in (game.get("domains") or []):
            if not d.get("on"):
                continue
            host = str(d.get("domain") or "").strip()
            if not host:
                continue
            t0 = time.time()
            try:
                r = _run_with_timeout(
                    ["curl.exe", "-4", "-s", "-o", "NUL", "-m", "8",
                     "-w", "%{http_code}", f"https://{host}/"],
                    timeout=12.0,
                )
                code = (r.stdout or "").strip()
            except Exception:
                code = "000"
            if not code:
                code = "000"
            results.append({"domain": host, "code": code,
                            "ok": code not in ("000", "000000"),
                            "elapsed": round(time.time() - t0, 2)})
        self._send_json({"status": "ok", "results": results})

    def _handle_games_add_domain(self, data: dict) -> None:
        """Добавить найденный в анализе домен прямо в игру."""
        from core import games as games_store
        game_id = str(data.get("game_id") or data.get("id") or "")
        domain = str(data.get("domain") or "")
        ok, message, added = games_store.add_game_domain(
            get_root_dir(), game_id, domain)
        self._send_json({"status": "ok" if ok else "error",
                         "message": message, "added": added})

    def _handle_save_config(self, data: dict) -> None:
        cfg = get_config_manager().load()
        if "last_profile" in data: cfg.last_profile = data["last_profile"]
        if "zapret1_dir" in data: cfg.zapret1_dir = data["zapret1_dir"]
        if "game_filter_mode" in data: cfg.game_filter_mode = data["game_filter_mode"]
        if "discord_voice" in data: cfg.discord_voice = bool(data["discord_voice"])
        if "discord_voice_mode" in data:
            mode = str(data["discord_voice_mode"]).lower()
            if mode in ("off", "fake", "udplen"):
                cfg.discord_voice_mode = mode
                cfg.discord_voice = mode != "off"  # совместимость со старыми сборками
        if "winws2_debug" in data: cfg.winws2_debug = bool(data["winws2_debug"])
        if "fake_blob" in data:
            fb = str(data["fake_blob"]).strip()
            if fb and not (get_root_dir() / "blobs" / f"tls_clienthello_{fb}.bin").exists():
                self._send_json({"status": "error", "message": f"неизвестный блоб: {fb}"})
                return
            cfg.fake_blob = fb
        if "autohostlist" in data: cfg.autohostlist = bool(data["autohostlist"])
        if "ipset_catchall" in data: cfg.ipset_catchall = bool(data["ipset_catchall"])
        if "discord_alt" in data: cfg.discord_alt = bool(data["discord_alt"])
        if "tour_done" in data: cfg.tour_done = bool(data["tour_done"])
        if "notice_done" in data: cfg.notice_done = bool(data["notice_done"])
        ok = get_config_manager().save(cfg)
        self._send_json({"status": "ok" if ok else "error"})

    def _handle_zapret1_save_dir(self, data: dict) -> None:
        path = data.get("path", "").strip()
        if not path or not Path(path).is_dir():
            self._send_json({"status": "error", "message": "Укажите существующую папку Zapret 1"})
            return
        cfg = get_config_manager().load()
        cfg.zapret1_dir = path
        get_config_manager().save(cfg)
        self._send_json({"status": "ok", "message": "Путь сохранён"})

    def _handle_zapret1_start(self, data: dict) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        strategy = data.get("strategy", "").strip()
        if not strategy:
            self._send_json({"status": "error", "message": "Стратегия не указана"})
            return
        # имя файла стратегии строится из клиентского значения (L2):
        # без этой проверки '..'/'../..' запускали .bat вне папки Zapret 1
        if Path(strategy).name != strategy or ".." in strategy or any(
                c in strategy for c in "/\\:*?\"<>|"):
            self._send_json({"status": "error", "message": "Недопустимое имя стратегии"})
            return
        controller = get_controller()
        z2 = controller.status()
        if z2.running:
            self._send_json({"status": "error", "message": "Zapret 2 (winws2.exe) запущен. Остановите его перед запуском Zapret 1."})
            return
        cfg = get_config_manager().load()
        dir_path = cfg.zapret1_dir
        if not dir_path:
            self._send_json({"status": "error", "message": "Папка Zapret 1 не указана"})
            return
        bat_path = Path(dir_path) / f"{strategy}.bat"
        if not bat_path.exists():
            self._send_json({"status": "error", "message": f"Файл {strategy}.bat не найден"})
            return
        try:
            subprocess.Popen([str(bat_path)], cwd=str(bat_path.parent),
                             creationflags=subprocess.CREATE_NO_WINDOW)
            cfg.zapret1_last_strategy = strategy
            get_config_manager().save(cfg)
            self._send_json({"status": "ok", "message": f"Zapret 1 запущен: {strategy}.bat"})
        except OSError as e:
            self._send_json({"status": "error", "message": str(e)})

    def _handle_zapret1_stop(self) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy},
                            HTTPStatus.CONFLICT)
            return
        try:
            subprocess.run(["taskkill", "/F", "/IM", "winws.exe"],
                           capture_output=True, timeout=8,
                           creationflags=subprocess.CREATE_NO_WINDOW)
            self._send_json({"status": "ok", "message": "Zapret 1 остановлен"})
        except (subprocess.TimeoutExpired, OSError) as e:
            self._send_json({"status": "error", "message": str(e)})

    def _handle_start_zapret(self, data: dict) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        z1 = _scan_winws_exe()
        if z1["running"]:
            self._send_json({"status": "error", "message": "Zapret 1 (winws.exe) запущен. Остановите его перед запуском Zapret 2."})
            return
        controller = get_controller()
        profile_name = data.get("profile", "")
        cfg = get_config_manager().load()
        ok, msg = controller.start(
            profile_name,
            game_filter_mode=cfg.game_filter_mode,
            discord_voice=cfg.discord_voice,
            discord_voice_mode=cfg.discord_voice_mode,
            fake_blob=cfg.fake_blob,
            winws2_debug=cfg.winws2_debug,
            autohostlist=cfg.autohostlist,
            ipset_catchall=cfg.ipset_catchall,
            discord_alt=cfg.discord_alt,
        )
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_stop_zapret(self) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        get_controller().stop()
        _kill_never_hang(["winws2.exe", "winws.exe"])
        self._send_json({"status": "ok", "message": "Все процессы zapret остановлены"})

    def _handle_save_list(self, data: dict, filename: str) -> None:
        content = _clean_list_text(data.get("content", "")).strip()
        path = get_root_dir() / "lists" / filename
        try:
            path.write_text(content, encoding="utf-8")
            self._send_json({"status": "ok", "message": "Список сохранён"})
        except OSError as e:
            self._send_json({"status": "error", "message": str(e)})

    # ── Спорные домены (нужен десинк одним, ломается у других - §15) ──
    _CONTESTED = [
        {"id": "aws", "domain": "amazonaws.com", "probe": "s3.amazonaws.com",
         "title": "AWS (S3 / DynamoDB)",
         "why": "Часть провайдеров режет AWS по SNI - нужен десинк. У других "
                "AWS жив в голую, а наш десинк ломает DynamoDB/S3. Проверь "
                "пробой и включай только если без десинка не живёт."},
    ]

    def _include_user_domains(self) -> set:
        path = get_root_dir() / "lists" / "list-include-user.txt"
        if not path.exists():
            return set()
        return {ln.strip().lower() for ln in
                path.read_text(encoding="utf-8").splitlines()
                if ln.strip()}

    def _handle_contested_status(self) -> None:
        items = []
        enabled = self._include_user_domains()
        for item in self._CONTESTED:
            items.append({**item, "enabled": item["domain"] in enabled})
        self._send_json({"status": "ok", "items": items,
                         "protection_running": get_controller().status().running})

    def _handle_contested_toggle(self, data: dict) -> None:
        item_id = str(data.get("id") or "")
        item = next((i for i in self._CONTESTED if i["id"] == item_id), None)
        if not item:
            self._send_json({"status": "error", "message": "Неизвестный домен"})
            return
        # Единый слой list_health: дедуп, переносы из исключений, конфликты
        from core import list_health
        enable = bool(data.get("enabled"))
        if enable:
            r = list_health.add_domain(get_root_dir(), item["domain"], "include")
            if r.get("result") in ("invalid", "blocked"):
                self._send_json({"status": "error",
                                 "message": r.get("message", "ошибка")})
                return
            prefix = {"already": "Уже в обходе",
                      "moved": "Перенесён из Исключений"}.get(
                          r.get("result"), "Добавлено в Включения")
        else:
            removed = list_health.remove_domain(get_root_dir(),
                                                item["domain"], "include")
            prefix = ("Убрано из Включений" if removed
                      else "Домен и так не был включён")
        self._send_json({"status": "ok",
                         "message": prefix + " - применится к новым подключениям "
                                             "(перезапуск не нужен)"})

    def _handle_contested_check(self, data: dict) -> None:
        import subprocess as _sp
        import time as _time
        item_id = str(data.get("id") or "")
        item = next((i for i in self._CONTESTED if i["id"] == item_id), None)
        if not item:
            self._send_json({"status": "error", "message": "Неизвестный домен"})
            return
        engine_running = get_controller().status().running
        # «В обходе» - это про КОНКРЕТНЫЙ домен: движок запущен И домен
        # добавлен в обход (тумблер). Раньше учитывался только статус
        # движка - при выключенном тумблере вердикт врал («оставьте
        # включённым», хотя домен обходом не обрабатывается).
        enabled = item["domain"].lower() in self._include_user_domains()
        with_protection = engine_running and enabled
        t0 = _time.time()
        r = _sp.run(
            ["curl.exe", "-4", "-s", "-o", "NUL", "-m", "10",
             "-w", "%{http_code}", f"https://{item['probe']}/"],
            capture_output=True, text=True, encoding="oem", errors="replace",
            timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
        code = (r.stdout or "").strip()
        self._send_json({"status": "ok", "code": code,
                         "elapsed": round(_time.time() - t0, 2),
                         "with_protection": with_protection,
                         "engine_running": engine_running,
                         "enabled": enabled})

    # ── Здоровье списков: дубли, пересечения, покрытие (list_health) ──

    def _handle_lists_health(self) -> None:
        try:
            from core import list_health
            report = list_health.check_health(get_root_dir())
        except Exception as e:  # noqa: BLE001
            self._send_json({"status": "error", "message": str(e)})
            return
        self._send_json({"status": "ok", **report})

    def _handle_lists_dedupe(self) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        try:
            from core import list_health
            result = list_health.dedupe(get_root_dir())
        except Exception as e:  # noqa: BLE001
            self._send_json({"status": "error", "message": str(e)})
            return
        self._send_json({"status": "ok", **result})

    def _handle_lists_add_domain(self, data: dict) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        mode = "exclude" if data.get("mode") == "exclude" else "include"
        try:
            from core import list_health
            result = list_health.add_domain(
                get_root_dir(), str(data.get("domain") or ""), mode)
        except Exception as e:  # noqa: BLE001
            self._send_json({"status": "error", "message": str(e)})
            return
        ok = result.get("result") in ("added", "moved", "already")
        self._send_json({"status": "ok" if ok else "error", **result})

    def _prepare_service_args(self, data: dict) -> tuple[Optional[list[str]], str]:
        """Сборка и валидация аргументов winws2 для службы (direct-exe):
        служба запускает winws2.exe сама, аргументы вшиты в binPath
        и обновляются при install/start - без cmd/bat-обёртки."""
        cfg = get_config_manager().load()
        profile = data.get("profile") or cfg.last_profile or DEFAULT_PROFILE
        game_filter = data.get("game_filter") or cfg.game_filter_mode or "off"
        voice_mode = (str(data.get("discord_voice_mode") or "").strip().lower()
                      or cfg.discord_voice_mode
                      or ("fake" if data.get("discord_voice", cfg.discord_voice) else "off"))
        discord_voice = voice_mode != "off"
        debug = bool(data.get("debug", cfg.winws2_debug))
        autohostlist = bool(data.get("autohostlist", cfg.autohostlist))
        ipset_catchall = bool(data.get("ipset_catchall", cfg.ipset_catchall))
        root = get_root_dir()
        exe = get_controller().winws2_path
        if exe is None:
            return None, "winws2.exe не найден"
        preset = root / "presets" / f"{profile}.txt"
        if not preset.exists():
            return None, f"Пресет '{profile}.txt' не найден"
        args = build_args_from_preset(root, root / "lua", root / "blobs", preset, debug=debug,
                                       game_filter_mode=game_filter,
                                       discord_voice=discord_voice,
                                       discord_voice_mode=voice_mode,
                                       fake_blob=str(data.get("fake_blob") or cfg.fake_blob or ""),
                                       autohostlist=autohostlist,
                                       ipset_catchall=ipset_catchall,
                                       discord_alt=bool(data.get("discord_alt", cfg.discord_alt)))
        ok, err = validate_args(exe, args, cwd=root)
        if not ok:
            return None, err
        return args, ""

    def _handle_service_install(self, data: dict) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        args, err = self._prepare_service_args(data)
        if err:
            self._send_json({"status": "error", "message": f"Установка отменена - {err}"})
            return
        cleanup = bool(data.get("cleanup_zapret1")) if isinstance(data, dict) else False
        ok, msg = svc_install(root_dir=get_root_dir(), args=args,
                              cleanup_zapret1=cleanup)
        if ok:
            # статус на главной показывал «стратегия «?»» - служба запускается
            # вне controller, и тот не знал профиль
            try:
                profile = str(data.get("profile") or "").strip()
                if profile:
                    get_controller().current_strategy = profile
            except Exception:
                pass
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_service_remove(self) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        ok, msg = svc_remove()
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_service_repair(self) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        try:
            result = svc_repair(root_dir=get_root_dir())
        except Exception as e:
            self._send_json({"status": "error", "message": str(e)})
            return
        self._send_json({"status": "ok", **result})

    def _handle_service_start(self) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        # Обновляем binPath текущими аргументами: у direct-exe службы они
        # вшиты, устаревшая cmdline молча запустит старую стратегию.
        args, err = self._prepare_service_args({})
        if err:
            self._send_json({"status": "error", "message": f"Служба не запущена - {err}"})
            return
        ok, msg = svc_start(args)
        if ok:
            try:
                get_controller().current_strategy = get_config_manager().load().last_profile
            except Exception:
                pass
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_service_stop(self) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        ok, msg = svc_stop()
        if ok:
            try:
                get_controller().current_strategy = None
            except Exception:
                pass
        self._send_json({"status": "ok" if ok else "error", "message": msg})

    def _handle_diagnose_action(self, data: dict) -> None:
        import threading as _th
        import time as _time
        from core.diagnostics import run_diagnostics, format_report_text
        # Диагностика и тестер - взаимно исключающие проверки: во время прогона
        # тестера отчёт был бы смесью «стабильно/перезапускается».
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy})
            return
        # Атомарная отметка «занято» - закрывает окно для параллельного POST.
        with _diag_lock:
            if _diag_state.get("running"):
                self._send_json({"status": "error", "message": "Проверка уже выполняется"})
                return
            _diag_state.update({"running": True, "progress": "", "report": None,
                                "error": None, "started": _time.time()})

        def _worker():
            try:
                def _cb(name):
                    with _diag_lock:
                        _diag_state["progress"] = name
                report = run_diagnostics(get_root_dir(), get_config_manager().load(), progress_cb=_cb)
                report["elapsed_sec"] = round(_time.time() - _diag_state["started"], 1)
                report["report_text"] = format_report_text(report)
                with _diag_lock:
                    _diag_state["report"] = report
            except Exception as e:
                with _diag_lock:
                    _diag_state["error"] = str(e)
            finally:
                with _diag_lock:
                    _diag_state["running"] = False

        _th.Thread(target=_worker, daemon=True).start()
        self._send_json({"status": "ok"})

    def _handle_diagnose_status(self) -> None:
        with _diag_lock:
            self._send_json({"status": "ok", **{k: _diag_state[k] for k in
                                                ("running", "progress", "error")},
                             "report": _diag_state["report"]})

    def _handle_update_check(self, params: Optional[dict] = None) -> None:
        global _update_check_cache, _update_check_at
        force = "1" in (params or {}).get("force", [])
        now = time.time()
        if (force or _update_check_cache is None
                or (now - _update_check_at) > _UPDATE_CHECK_TTL):
            from core.updates import check_for_updates
            _update_check_cache = check_for_updates()
            _update_check_at = now
        self._send_json({"status": "ok", **_update_check_cache})

    def _handle_update_status(self) -> None:
        self._send_json({"status": "ok", **_updater_state})

    def _handle_update_start(self) -> None:
        if _updater_state["running"]:
            self._send_json({"status": "error",
                             "message": "Обновление уже выполняется"})
            return
        info = (_update_check_cache or {}).copy()
        if not info.get("available"):
            self._send_json({"status": "error",
                             "message": "Обновление недоступно или версия уже актуальна"})
            return

        tag = info.get("tag") or info.get("latest", "").replace(" ", "-")
        kind = "portable" if not getattr(sys, "frozen", False) else "exe"
        _updater_state.update({"running": True, "phase": "скачивание",
                               "percent": 5, "error": None, "result": None})
        t = threading.Thread(target=_run_update_worker,
                             args=(kind, tag, info), daemon=True)
        t.start()
        self._send_json({"status": "ok", "action": "started"})

    def _handle_settings_export(self) -> None:
        """Экспорт настроек: config + *-user.txt + юзерские пресеты → один zip."""
        from core.updater import export_settings_zip
        path = export_settings_zip(get_root_dir())
        if not path:
            self._send_json({"status": "error", "message": "Не удалось создать файл экспорта"})
            return
        self._send_json({"status": "ok", "file": str(path),
                         "name": path.name})

    def _handle_settings_import(self, data: dict) -> None:
        """Импорт настроек из zip (base64): только юзер-файлы восстанавливаются."""
        import base64
        try:
            zip_data = base64.b64decode(data.get("data") or "")
        except Exception:
            self._send_json({"status": "error", "message": "Некорректный файл"})
            return
        if not zip_data:
            self._send_json({"status": "error", "message": "Пустой файл"})
            return
        from core.updater import import_settings_zip
        imported, skipped = import_settings_zip(zip_data, get_root_dir())
        self._send_json({"status": "ok", "imported": imported,
                         "skipped": skipped,
                         "message": f"Восстановлено записей: {imported}. "
                                    "Перезапустите программу, чтобы применилось."})

    def _handle_export_report(self, data: dict) -> None:
        consent = data.get("consent", False)
        city = data.get("city", "")
        isp = data.get("isp", "")
        vpn_active = data.get("vpn_active", False)
        zapret1_strategy = data.get("zapret1_strategy", "")
        zapret1_filename = data.get("zapret1_filename", "")
        zapret1_cmdline = data.get("zapret1_cmdline", "")
        phase0_results = data.get("phase0_results")
        phase1_results = data.get("phase1_results")
        phase2_results = data.get("phase2_results")
        mode = data.get("mode", "lite")
        root = get_root_dir()

        bat_path = None
        if zapret1_filename and zapret1_strategy:
            # Клиент-контролируемое имя: только базовое имя, без разделителей -
            # иначе запись вне корня (path traversal).
            if Path(zapret1_filename).name != zapret1_filename or any(
                    c in zapret1_filename for c in "/\\:*?\"<>|") or \
                    ".." in zapret1_filename:
                self._send_json({"status": "error", "message": "Недопустимое имя файла стратегии"})
                return
            try:
                bat_bytes = base64.b64decode(zapret1_strategy)
                bat_path = root / zapret1_filename
                bat_path.write_bytes(bat_bytes)
                zapret1_strategy = str(bat_path)
            except Exception:
                pass

        ok, path_or_err = export_data_package(
            consent=consent, city=city, isp=isp,
            vpn_active=vpn_active,
            zapret1_strategy=zapret1_strategy,
            root_dir=root, result_dir=root,
            bat_path=bat_path,
            zapret1_cmdline=zapret1_cmdline,
            phase0_results=phase0_results,
            phase1_results=phase1_results,
            phase2_results=phase2_results,
            mode=mode,
        )
        if bat_path and bat_path.exists():
            try:
                bat_path.unlink()
            except OSError:
                pass
        if ok:
            self._send_json({"status": "ok", "file": path_or_err})
        else:
            self._send_json({"status": "error", "message": path_or_err})

    def _handle_asn_scan(self, data: dict) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy}, HTTPStatus.CONFLICT)
            return
        with _tester_state.lock:
            if _tester_state.running:
                self._send_json({"status": "error", "message": "Тестер занят"}, HTTPStatus.CONFLICT)
                return
            _tester_state.running = True
        t = threading.Thread(target=_run_asn_scan, daemon=True)
        t.start()
        self._send_json({"status": "ok"})

    def _handle_blob_probe(self, data: dict) -> None:
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy}, HTTPStatus.CONFLICT)
            return
        with _tester_state.lock:
            if _tester_state.running:
                self._send_json({"status": "error", "message": "Тестер занят"}, HTTPStatus.CONFLICT)
                return
            _tester_state.running = True
        t = threading.Thread(target=_run_blob_probe, args=(data or {},), daemon=True)
        t.start()
        self._send_json({"status": "ok"})

    def _handle_tester_action(self, data: dict) -> None:
        action = data.get("action", "")
        if action == "cancel":
            get_tester().signal_shutdown()
            with _tester_state.lock:
                _tester_state.cancelled = True
            self._send_json({"status": "ok", "action": "cancelled"})
            return
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy}, HTTPStatus.CONFLICT)
            return
        # Решение «занят/свободен» принимаем атомарно под локом: отметка
        # running=True здесь же закрывает окно для второго параллельного POST.
        with _tester_state.lock:
            if _tester_state.running:
                self._send_json({"status": "error", "message": "Тестер уже занят - дождитесь завершения"},
                                HTTPStatus.CONFLICT)
                return
            _tester_state.running = True
        t = threading.Thread(target=_run_tester_action, args=(data,), daemon=True)
        t.start()
        self._send_json({"status": "ok", "action": "started"})

    def _handle_cdn_recommendation(self, data: dict) -> None:
        """Полу-автономное применение вердикта CDN-скана без наложений.

        general - домен → list-general.txt (в ipset-режиме IP кандидата →
        ipset-include-user.txt, с проверкой пересечения с ipset-exclude);
        exclude - домен → list-exclude.txt (работает в обоих режимах);
        ipset-include/ipset-exclude - IP → ipset-include-user.txt.
        Применение перезапускает обход - busy-чек не даёт делать это во время
        теста (M1: кнопки строк CDN активны во время прогона).
        """
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy},
                            HTTPStatus.CONFLICT)
            return
        domain = (data.get("domain") or "").strip().lower().rstrip(".")
        action = data.get("action", "")
        ips = [str(i).strip() for i in (data.get("ips") or []) if str(i).strip()]
        if not domain or action not in ("general", "exclude", "ipset-include", "ipset-exclude"):
            self._send_json({"status": "error",
                             "message": "Нужны domain и action (general|exclude|ipset-include|ipset-exclude)"})
            return
        cfg = get_config_manager().load()
        ipset_mode = bool(cfg.ipset_catchall)
        working_domains = [str(d).strip().lower().rstrip(".")
                           for d in (data.get("working_domains") or []) if str(d).strip()]
        protection: set[str] = set()
        if working_domains:
            protection = _resolve_many(working_domains)
        ok, msg, entries = _plan_cdn_action(domain, action, ips, protection, ipset_mode)
        if not ok:
            self._send_json({"status": "error", "message": msg})
            return
        fname = entries[0][0] if entries else ""
        values = entries[0][1] if entries else []
        if values:
            path = get_root_dir() / "lists" / fname
            with path.open("a", encoding="utf-8") as f:
                f.write("\n".join(values) + "\n")
        profile = cfg.last_profile or DEFAULT_PROFILE
        ok, restart_msg = get_controller().start(
            profile,
            game_filter_mode=cfg.game_filter_mode,
            discord_voice=cfg.discord_voice,
            discord_voice_mode=cfg.discord_voice_mode,
            fake_blob=cfg.fake_blob,
            winws2_debug=cfg.winws2_debug,
            autohostlist=cfg.autohostlist,
            ipset_catchall=cfg.ipset_catchall,
            discord_alt=cfg.discord_alt,
        )
        if ok:
            if action in ("ipset-include", "ipset-exclude") or (action == "general" and ipset_mode):
                detail = f"{len(values) or 'все'} сети -> {fname}"
            else:
                detail = f"{domain} -> {fname}"
            self._send_json({"status": "ok",
                             "message": f"{domain}: {detail}, пресет {profile} перезапущен"})
        else:
            self._send_json({"status": "error",
                             "message": f"{domain}: {fname} обновлён, но перезапуск не удался: {restart_msg}"})

    def _handle_cdn_apply_all(self, data: dict) -> None:
        """«Применить всё по матрице»: батч вердиктов CDN-скана за один перезапуск.

        actions = [{domain, action, ips}, ...]; working_domains - живые в основном
        прогоне (protection для safe_prefixes). Каждая правка планируется как в
        ручном хендлере; наложения/ошибки не валят батч, а пропускаются с причиной.
        Записи дедуплицируются по файлам, затем один перезапуск.
        """
        busy = _checkers_busy()
        if busy:
            self._send_json({"status": "error", "message": busy},
                            HTTPStatus.CONFLICT)
            return
        actions = data.get("actions") or []
        if not isinstance(actions, list) or not actions:
            self._send_json({"status": "error", "message": "Нет правок в запросе"})
            return
        clean = []
        for a in actions:
            if not isinstance(a, dict):
                continue
            domain = (a.get("domain") or "").strip().lower().rstrip(".")
            action = a.get("action", "")
            ips = [str(i).strip() for i in (a.get("ips") or []) if str(i).strip()]
            if domain and action in ("general", "exclude", "ipset-include", "ipset-exclude"):
                clean.append((domain, action, ips))
        if not clean:
            self._send_json({"status": "error", "message": "Нет валидных правок в запросе"})
            return
        cfg = get_config_manager().load()
        ipset_mode = bool(cfg.ipset_catchall)
        working_domains = [str(d).strip().lower().rstrip(".")
                           for d in (data.get("working_domains") or []) if str(d).strip()]
        protection: set[str] = set()
        if working_domains:
            protection = _resolve_many(working_domains)
        pending: dict[str, list[str]] = {}
        applied: list[str] = []
        skipped: list[dict] = []
        for domain, action, ips in clean:
            ok, msg, entries = _plan_cdn_action(domain, action, ips, protection, ipset_mode)
            if not ok:
                skipped.append({"domain": domain, "reason": msg})
                continue
            for fname, values in entries:
                pending.setdefault(fname, []).extend(values)
            applied.append(domain)
        written: dict[str, list[str]] = {}
        if pending:
            for fname, values in pending.items():
                existing = _read_lines(fname)
                values = [v for v in values if v not in existing]
                if not values:
                    continue
                path = get_root_dir() / "lists" / fname
                with path.open("a", encoding="utf-8") as f:
                    f.write("\n".join(values) + "\n")
                written[fname] = values
        # После дедупа могло не остаться реальных записей - перезапуск не нужен.
        if not written:
            self._send_json({"status": "ok",
                             "message": "Нечего применять - правки уже в списках",
                             "applied": [], "skipped": skipped})
            return
        profile = cfg.last_profile or DEFAULT_PROFILE
        restart_ok, restart_msg = get_controller().start(
            profile,
            game_filter_mode=cfg.game_filter_mode,
            discord_voice=cfg.discord_voice,
            discord_voice_mode=cfg.discord_voice_mode,
            fake_blob=cfg.fake_blob,
            winws2_debug=cfg.winws2_debug,
            autohostlist=cfg.autohostlist,
            ipset_catchall=cfg.ipset_catchall,
        )
        if not restart_ok and written:
            self._send_json({"status": "error",
                             "message": f"Применено {len(applied)} правок, но перезапуск не удался: {restart_msg}",
                             "applied": applied, "skipped": skipped})
            return
        files_touched = ", ".join(sorted(written)) if written else "-"
        self._send_json({"status": "ok",
                         "message": f"Применено {len(applied)} правок ({files_touched}), пресет {profile} перезапущен",
                         "applied": applied, "skipped": skipped})


# ── Жизненный цикл сервера ───────────────────────────────────

class ThreadedHTTPServer(HTTPServer):
    allow_reuse_address = True

    def process_request(self, request, client_address):
        t = threading.Thread(target=self.process_request_thread,
                             args=(request, client_address), daemon=True)
        t.start()

    def process_request_thread(self, request, client_address):
        try:
            self.finish_request(request, client_address)
        except Exception:
            self.handle_error(request, client_address)
        finally:
            self.shutdown_request(request)


def create_server(host: str, port: int) -> ThreadedHTTPServer:
    global _server
    srv = ThreadedHTTPServer((host, port), ZapretHandler)
    _server = srv
    return srv


def stop_server() -> None:
    global _server
    if _server:
        _server.shutdown()
        _server = None