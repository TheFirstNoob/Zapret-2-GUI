@echo off
cd /d "%~dp0"
tasklist /FI "IMAGENAME eq winws.exe" /NH 2>nul | findstr /I "winws.exe" >nul
if not errorlevel 1 (
    echo ERROR: Zapret 1 is running - stop winws.exe first.
    pause
    exit /b 1
)
tasklist /FI "IMAGENAME eq winws2.exe" /NH 2>nul | findstr /I "winws2.exe" >nul
if not errorlevel 1 (
    echo ERROR: winws2 is already running ^(GUI/lite/service^). Run stop.bat first.
    pause
    exit /b 1
)
start "zapret2" /min "%~dp0bin\winws2.exe" @"%~dp0conf-start-multisplit-pure.conf"
