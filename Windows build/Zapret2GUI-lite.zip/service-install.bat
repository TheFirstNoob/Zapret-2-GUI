@echo off
cd /d "%~dp0"
sc stop zapret2 >nul 2>&1
sc delete zapret2 >nul 2>&1
sc create zapret2 binPath= "\"cmd.exe\" /C \"%~dp0_zapret_service.bat\"" DisplayName= "Zapret 2 DPI Bypass" start= auto
sc start zapret2
echo.
echo Service installed and started. To remove: service-remove.bat
pause
