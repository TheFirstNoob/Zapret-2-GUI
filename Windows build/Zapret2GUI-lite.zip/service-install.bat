@echo off
cd /d "%~dp0"
sc query zapret >nul 2>&1 && (echo ERROR: Zapret 1 service found - remove it first. & pause & exit /b 1)
tasklist /FI "IMAGENAME eq winws.exe" /NH 2>nul | findstr /I "winws.exe" >nul
if not errorlevel 1 (
    echo ERROR: Zapret 1 is running - stop winws.exe first.
    pause
    exit /b 1
)
sc query zapret2 >nul 2>&1 && (
    sc qc zapret2 | findstr /I /C:"%~dp0" >nul
    if errorlevel 1 (
        echo ERROR: service zapret2 is installed from ANOTHER folder ^(GUI/lite^).
        echo Remove it from that copy first. Nothing changed.
        pause
        exit /b 1
    )
)
sc stop zapret2 >nul 2>&1
sc delete zapret2 >nul 2>&1
> "%~dp0service_run.conf" (
    echo "--wf-tcp-out"
    echo "80,443,2053,2083,2087,2096,8443"
    echo "--wf-udp-out"
    echo "443,19294-19344,50000-50100,4192-4194"
    echo "--lua-init=@%~dp0lua\zapret-lib.lua"
    echo "--lua-init=@%~dp0lua\zapret-antidpi.lua"
    echo "--blob"
    echo "google_tls:@%~dp0blobs\tls_clienthello_www_google_com.bin"
    echo "--blob"
    echo "quic_google:@%~dp0blobs\quic_initial_www_google_com.bin"
    echo "--lua-gc"
    echo "60"
    echo "--filter-udp"
    echo "19294-19344,50000-50100"
    echo "--filter-l7"
    echo "discord,stun"
    echo "--payload"
    echo "discord_ip_discovery"
    echo "--out-range"
    echo "-d10"
    echo "--lua-desync=fake:blob=quic_google"
    echo "--new"
    echo "--filter-tcp"
    echo "2053,2083,2087,2096,8443"
    echo "--filter-l7"
    echo "tls"
    echo "--hostlist-exclude=%~dp0lists\list-exclude-user.txt"
    echo "--hostlist=%~dp0lists\list-include-all.txt"
    echo "--hostlist=%~dp0lists\list-discord.txt"
    echo "--out-range"
    echo "-d10"
    echo "--payload"
    echo "tls_client_hello"
    echo "--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=8"
    echo "--lua-desync=multisplit:pos=1,midsld:seqovl=681:seqovl_pattern=google_tls"
    echo "--new"
    echo "--filter-tcp"
    echo "443"
    echo "--filter-l7"
    echo "tls"
    echo "--hostlist-exclude=%~dp0lists\list-exclude-user.txt"
    echo "--hostlist=%~dp0lists\list-include-all.txt"
    echo "--hostlist=%~dp0lists\list-discord.txt"
    echo "--out-range"
    echo "-d10"
    echo "--payload"
    echo "tls_client_hello"
    echo "--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=8"
    echo "--lua-desync=multisplit:pos=1,midsld:seqovl=681:seqovl_pattern=google_tls"
    echo "--new"
    echo "--filter-tcp"
    echo "443"
    echo "--filter-l7"
    echo "tls"
    echo "--hostlist-exclude=%~dp0lists\list-exclude-user.txt"
    echo "--hostlist=%~dp0lists\list-include-all.txt"
    echo "--hostlist=%~dp0lists\list-google.txt"
    echo "--out-range"
    echo "-d10"
    echo "--payload"
    echo "tls_client_hello"
    echo "--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=6"
    echo "--lua-desync=multisplit:pos=1,midsld:seqovl=681:seqovl_pattern=google_tls"
    echo "--new"
    echo "--filter-tcp"
    echo "80,443"
    echo "--filter-l7"
    echo "tls,http"
    echo "--hostlist-exclude=%~dp0lists\list-exclude-user.txt"
    echo "--hostlist=%~dp0lists\list-include-all.txt"
    echo "--hostlist=%~dp0lists\list-general.txt"
    echo "--hostlist-exclude=%~dp0lists\list-exclude.txt"
    echo "--out-range"
    echo "-d10"
    echo "--payload"
    echo "tls_client_hello,http_req"
    echo "--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=8"
    echo "--lua-desync=multisplit:pos=1,midsld:seqovl=681:seqovl_pattern=google_tls"
    echo "--new"
    echo "--filter-udp"
    echo "443"
    echo "--filter-l7"
    echo "quic"
    echo "--payload"
    echo "quic_initial"
    echo "--hostlist-exclude=%~dp0lists\list-exclude-user.txt"
    echo "--hostlist=%~dp0lists\list-include-all.txt"
    echo "--hostlist=%~dp0lists\list-google.txt"
    echo "--out-range"
    echo "-d10"
    echo "--lua-desync=fake:blob=quic_google"
    echo "--new"
    echo "--filter-udp"
    echo "443"
    echo "--filter-l7"
    echo "quic"
    echo "--payload"
    echo "quic_initial"
    echo "--hostlist-exclude=%~dp0lists\list-exclude-user.txt"
    echo "--hostlist=%~dp0lists\list-include-all.txt"
    echo "--hostlist=%~dp0lists\list-general.txt"
    echo "--hostlist-exclude=%~dp0lists\list-exclude.txt"
    echo "--out-range"
    echo "-d10"
    echo "--lua-desync=fake:blob=quic_google"
    echo "--new"
    echo "--filter-udp=4192-4194"
    echo "--ipset=%~dp0lists\games\_pool_d4r1.txt"
    echo "--out-range"
    echo "-d4"
    echo "--lua-desync=fake:blob=quic_google:repeats=1:payload=all"
)
sc create zapret2 binPath= "\"%~dp0bin\winws2.exe\" @\"%~dp0service_run.conf\"" DisplayName= "Zapret 2 DPI Bypass" start= auto
sc description zapret2 "zapret DPI bypass (Zapret 2 lite)" >nul
sc failure zapret2 reset= 86400 actions= restart/60000/restart/60000/restart/60000 >nul
sc start zapret2
echo.
echo Service installed and started. To remove: service-remove.bat
pause
