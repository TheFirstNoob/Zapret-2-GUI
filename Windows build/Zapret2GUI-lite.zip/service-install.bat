@echo off
cd /d "%~dp0"
sc query zapret >nul 2>&1 && (echo ERROR: Zapret 1 service found - remove it first. & pause & exit /b 1)
tasklist /FI "IMAGENAME eq winws.exe" /NH 2>nul | findstr /I "winws.exe" >nul
if not errorlevel 1 (
    echo ERROR: Zapret 1 is running - stop winws.exe first.
    pause
    exit /b 1
)
sc stop zapret2 >nul 2>&1
sc delete zapret2 >nul 2>&1
sc create zapret2 binPath= "\"%~dp0bin\winws2.exe\" \"--wf-tcp-out\" \"80,443,2053,2083,2087,2096,8443\" \"--wf-udp-out\" \"443,19294-19344,50000-50100\" \"--lua-init=@%~dp0lua\zapret-lib.lua\" \"--lua-init=@%~dp0lua\zapret-antidpi.lua\" \"--blob\" \"google_tls:@%~dp0blobs\tls_clienthello_www_google_com.bin\" \"--blob\" \"quic_google:@%~dp0blobs\quic_initial_www_google_com.bin\" \"--lua-gc\" \"60\" \"--filter-udp\" \"19294-19344,50000-50100\" \"--filter-l7\" \"discord,stun\" \"--payload\" \"discord_ip_discovery\" \"--out-range\" \"-d10\" \"--lua-desync=fake:blob=quic_google\" \"--new\" \"--filter-tcp\" \"2053,2083,2087,2096,8443\" \"--filter-l7\" \"tls\" \"--hostlist=%~dp0lists\list-discord.txt\" \"--out-range\" \"-d10\" \"--payload\" \"tls_client_hello\" \"--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=8:nodrop\" \"--lua-desync=multisplit:pos=1:seqovl=681:seqovl_pattern=google_tls:repeats=8:nodrop\" \"--new\" \"--filter-tcp\" \"443\" \"--filter-l7\" \"tls\" \"--hostlist=%~dp0lists\list-discord.txt\" \"--out-range\" \"-d10\" \"--payload\" \"tls_client_hello\" \"--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=8:nodrop\" \"--lua-desync=multisplit:pos=1:seqovl=681:seqovl_pattern=google_tls:repeats=8:nodrop\" \"--new\" \"--filter-tcp\" \"443\" \"--filter-l7\" \"tls\" \"--hostlist=%~dp0lists\list-google.txt\" \"--out-range\" \"-d10\" \"--payload\" \"tls_client_hello\" \"--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=6\" \"--lua-desync=multisplit:pos=1:seqovl=681:seqovl_pattern=google_tls\" \"--new\" \"--filter-tcp\" \"80,443\" \"--filter-l7\" \"tls,http\" \"--hostlist=%~dp0lists\list-general.txt\" \"--hostlist-exclude=%~dp0lists\list-exclude.txt\" \"--out-range\" \"-d10\" \"--payload\" \"tls_client_hello,http_req\" \"--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=8\" \"--lua-desync=multisplit:pos=1:seqovl=681:seqovl_pattern=google_tls\" \"--new\" \"--filter-udp\" \"443\" \"--filter-l7\" \"quic\" \"--payload\" \"quic_initial\" \"--hostlist=%~dp0lists\list-google.txt\" \"--out-range\" \"-d10\" \"--lua-desync=fake:blob=quic_google\" \"--new\" \"--filter-udp\" \"443\" \"--filter-l7\" \"quic\" \"--payload\" \"quic_initial\" \"--hostlist=%~dp0lists\list-general.txt\" \"--hostlist-exclude=%~dp0lists\list-exclude.txt\" \"--out-range\" \"-d10\" \"--lua-desync=fake:blob=quic_google\"" DisplayName= "Zapret 2 DPI Bypass" start= auto
sc start zapret2
echo.
echo Service installed and started. To remove: service-remove.bat
pause
