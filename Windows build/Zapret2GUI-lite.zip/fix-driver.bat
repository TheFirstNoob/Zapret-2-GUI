@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [1/3] Stopping Zapret 2 (service + this copy)...
sc stop zapret2 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%~dp0'; Get-Process winws2 -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($p, [StringComparison]::OrdinalIgnoreCase) } | Stop-Process -Force" >nul 2>&1
echo [2/3] Checking WinDivert driver service...
sc query WinDivert >nul 2>&1
if errorlevel 1 (
    echo   WinDivert service not found - it will be created automatically on next start.
    goto done
)
sc qc WinDivert | findstr /I /C:"%~dp0bin\WinDivert64.sys" >nul
if errorlevel 1 (
    echo   ImagePath is broken or points to another folder - repairing...
    sc config WinDivert binPath= "\??\%~dp0bin\WinDivert64.sys" start= demand
) else (
    echo   ImagePath OK.
)
sc query WinDivert | findstr /I "RUNNING" >nul
if not errorlevel 1 (
    sc stop WinDivert >nul 2>&1
    if errorlevel 1 (
        echo   Driver is busy - it will unload after handles close or reboot.
    ) else (
        echo   Driver unloaded.
    )
)
:done
echo [3/3] Done. Start protection again: start-default.bat or service.bat (item 3).
pause
