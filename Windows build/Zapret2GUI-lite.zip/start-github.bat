@echo off
cd /d "%~dp0"
tasklist /FI "IMAGENAME eq winws.exe" /NH 2>nul | findstr /I "winws.exe" >nul
if not errorlevel 1 (
    echo ERROR: Zapret 1 is running - stop winws.exe first.
    pause
    exit /b 1
)
start "zapret2" /min "%~dp0bin\winws2.exe" "--wf-tcp-out" "80,443" "--wf-udp-out" "443" "--lua-init=@%~dp0lua\zapret-lib.lua" "--lua-init=@%~dp0lua\zapret-antidpi.lua" "--blob" "google_tls:@%~dp0blobs\tls_clienthello_www_google_com.bin" "--blob" "quic_google:@%~dp0blobs\quic_initial_www_google_com.bin" "--lua-gc" "60" "--filter-tcp" "80,443" "--filter-l7" "tls,http" "--hostlist=%~dp0lists\list-github.txt" "--out-range" "-d10" "--payload" "tls_client_hello,http_req" "--lua-desync=fake:blob=google_tls:tcp_ts=-1000:repeats=6" "--lua-desync=multisplit:pos=1:seqovl=681:seqovl_pattern=google_tls" "--new" "--filter-udp" "443" "--filter-l7" "quic" "--payload" "quic_initial" "--hostlist=%~dp0lists\list-github.txt" "--out-range" "-d10" "--lua-desync=fake:blob=quic_google"
