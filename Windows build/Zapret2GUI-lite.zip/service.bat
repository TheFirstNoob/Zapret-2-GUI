@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
:menu
cls
echo ==========================================
echo   Zapret 2 lite - menu
echo ==========================================
echo   1. Select strategy and start
echo   2. Stop
echo   3. Install service (autostart, default preset)
echo   4. Remove service
echo   5. Exit
echo.
set /p c=Choose [1-5]:
if "%c%"=="1" goto pick
if "%c%"=="2" goto stop
if "%c%"=="3" goto svcinstall
if "%c%"=="4" goto svcremove
if "%c%"=="5" exit /b
goto menu
:pick
cls
echo Available strategies:
set n=0
for %%f in (start-*.bat) do (
    set /a n+=1
    set "nm=%%~nf"
    set "opt!n!=%%f"
    echo   !n!. !nm:start-=!
)
echo.
set /p sel=Number:
set "chosen=opt!sel!"
call set "filename=%%!chosen!%%"
if not defined filename goto pick
call "!filename!"
echo Started. Press any key...
pause >nul
goto menu
:stop
taskkill /F /IM winws2.exe >nul 2>&1
echo Stopped.
pause >nul
goto menu
:svcinstall
sc stop zapret2 >nul 2>&1
sc delete zapret2 >nul 2>&1
sc create zapret2 binPath= "\"cmd.exe\" /C \"%~dp0_zapret_service.bat\"" DisplayName= "Zapret 2 DPI Bypass" start= auto
sc start zapret2
echo Service installed and started.
pause >nul
goto menu
:svcremove
sc stop zapret2 >nul 2>&1
sc delete zapret2 >nul 2>&1
taskkill /F /IM winws2.exe >nul 2>&1
echo Service removed.
pause >nul
goto menu
