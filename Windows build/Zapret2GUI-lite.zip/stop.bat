@echo off
taskkill /F /IM winws2.exe >nul 2>&1
