@echo off
taskkill /F /IM winws2.exe >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1
