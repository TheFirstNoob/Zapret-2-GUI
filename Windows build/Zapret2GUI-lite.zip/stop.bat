@echo off
chcp 65001 >nul
cd /d "%~dp0"
sc stop zapret2 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%~dp0'; Get-Process winws2 -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($p, [StringComparison]::OrdinalIgnoreCase) } | Stop-Process -Force" >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1
