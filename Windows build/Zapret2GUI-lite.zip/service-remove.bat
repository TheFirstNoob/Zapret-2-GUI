@echo off
chcp 65001 >nul
cd /d "%~dp0"
sc query zapret2 >nul 2>&1 && (
    sc qc zapret2 | findstr /I /C:"%~dp0" >nul
    if errorlevel 1 (
        echo ERROR: service zapret2 belongs to ANOTHER folder - not removed.
        pause
        exit /b 1
    )
)
sc stop zapret2 >nul 2>&1
sc delete zapret2 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%~dp0'; Get-Process winws2 -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($p, [StringComparison]::OrdinalIgnoreCase) } | Stop-Process -Force" >nul 2>&1
echo Service removed.
pause
