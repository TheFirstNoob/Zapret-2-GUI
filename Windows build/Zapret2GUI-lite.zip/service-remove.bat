@echo off
sc stop zapret2 >nul 2>&1
sc delete zapret2 >nul 2>&1
taskkill /F /IM winws2.exe >nul 2>&1
echo Service removed.
pause
